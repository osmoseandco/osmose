import React, { useState, useEffect } from 'react';
import { ActivePage, Experience, Partner, Article, Booking, UserNotification, CategoryId } from './types';
import { 
  categories, 
  experiences as initialExperiences, 
  partners, 
  articles, 
  mockNotifications, 
  initialBookings 
} from './data/mockData';

// Shared Layout Elements
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { AuthModal } from './components/AuthModal';
import { LucideIcon } from './components/LucideIcon';

// Main Views Module
import { HomeView } from './views/HomeView';
import { ExplorerView } from './views/ExplorerView';
import { EventDetailView } from './views/EventDetailView';
import { PartnerDetailView } from './views/PartnerDetailView';
import { BecomePartnerView } from './views/BecomePartnerView';
import { UserDashboardView } from './views/UserDashboardView';
import { PartnerDashboardView } from './views/PartnerDashboardView';
import { BlogView } from './views/BlogView';

import { auth, db, logout as firebaseLogout, handleFirestoreError, OperationType } from './firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { collection, doc, setDoc, deleteDoc, getDocs, query, where } from 'firebase/firestore';

export default function App() {
  // Global Navigation & Selection state
  const [activePage, setActivePage] = useState<ActivePage>('home');
  const [selectedExperience, setSelectedExperience] = useState<Experience | null>(null);
  const [selectedPartner, setSelectedPartner] = useState<Partner | null>(partners[0]);
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  // Filter pass-over state (Homepage -> Explorer page)
  const [searchFilters, setSearchFilters] = useState<{ city: string; category: string; date: string }>({
    city: '',
    category: '',
    date: ''
  });

  // Stateful databases (with reactive state wrappers for life interactions!)
  const [experiencesList, setExperiencesList] = useState<Experience[]>(initialExperiences);
  const [favorites, setFavorites] = useState<string[]>(['e1', 'e2']); // Presaved bookmarks for demonstration
  const [bookings, setBookings] = useState<Booking[]>(initialBookings);
  const [notifications, setNotifications] = useState<UserNotification[]>(mockNotifications);

  // Identity / Authentication state synced with Firebase
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true); // Logged in by default, updated on status change
  const [userRole, setUserRole] = useState<'user' | 'partner'>('user');
  const [authModal, setAuthModal] = useState<{ isOpen: boolean; initialTab: 'login' | 'signup' }>({
    isOpen: false,
    initialTab: 'login'
  });

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setIsAuthenticated(true);
        const email = user.email || '';
        const isPartner = email.toLowerCase().includes('partner') || email === 'osmoseandco@gmail.com' || email === 'partenaire@osmose.fr';
        setUserRole(isPartner ? 'partner' : 'user');
      } else {
        setIsAuthenticated(false);
      }
    });
    return () => unsubscribe();
  }, []);

  // Sync with Firestore
  useEffect(() => {
    let active = true;
    if (!isAuthenticated || !auth.currentUser) {
      setBookings([]);
      setNotifications(mockNotifications);
      return;
    }

    const userId = auth.currentUser.uid;

    const fetchUserData = async () => {
      try {
        const bookingsQuery = query(collection(db, 'bookings'), where('userId', '==', userId));
        const bookingsSnap = await getDocs(bookingsQuery);
        const fbBookings: Booking[] = [];
        bookingsSnap.forEach((doc) => {
          fbBookings.push(doc.data() as Booking);
        });

        if (active) {
          if (fbBookings.length > 0) {
            setBookings(fbBookings);
          } else {
            const initialSeeds = initialBookings.map(b => ({ ...b, userId }));
            for (const item of initialSeeds) {
              await setDoc(doc(db, 'bookings', item.id), item);
            }
            setBookings(initialSeeds);
          }
        }
      } catch (err) {
        if (active) {
          console.warn("Failed to fetch/seed bookings from Firestore.", err);
        }
      }

      try {
        const notifQuery = query(collection(db, 'notifications'), where('userId', '==', userId));
        const notifSnap = await getDocs(notifQuery);
        const fbNotifs: UserNotification[] = [];
        notifSnap.forEach((doc) => {
          fbNotifs.push(doc.data() as UserNotification);
        });

        if (active) {
          if (fbNotifs.length > 0) {
            setNotifications(fbNotifs);
          } else {
            const seededNotifs = mockNotifications.map(n => ({ ...n, userId }));
            for (const item of seededNotifs) {
              await setDoc(doc(db, 'notifications', item.id), item);
            }
            setNotifications(seededNotifs);
          }
        }
      } catch (err) {
        if (active) {
          console.warn("Failed to fetch/seed notifications from Firestore.", err);
        }
      }
    };

    fetchUserData();

    return () => {
      active = false;
    };
  }, [isAuthenticated]);

  // Handler helpers
  const handleToggleFavorite = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setFavorites(prev => {
      const isFav = prev.includes(id);
      let nextFavs;
      if (isFav) {
        nextFavs = prev.filter(item => item !== id);
      } else {
        nextFavs = [...prev, id];
      }
      
      // Push alert
      const targetExp = experiencesList.find(x => x.id === id);
      if (targetExp) {
        const notif: UserNotification = {
          id: `n-fav-${Date.now()}`,
          title: isFav ? 'Favori retiré 💔' : 'Favori enregistré ! ❤️',
          message: isFav 
            ? `Vous avez retiré "${targetExp.title}" de votre liste d'envies.` 
            : `"${targetExp.title}" est ajoutée à votre liste d'envies. Vous recevrez des alertes en cas de promotions ou places libérées !`,
          date: 'À l\'instant',
          read: false
        };
        setNotifications(nPrev => [notif, ...nPrev]);
      }
      return nextFavs;
    });
  };

  const handleConfirmBooking = async (newBooking: Booking) => {
    setBookings(prev => [newBooking, ...prev]);
    setActivePage('user-dashboard'); // take traveler directly to their tickets dashboard!

    if (auth.currentUser) {
      const dbPath = `bookings/${newBooking.id}`;
      try {
        const payload = {
          ...newBooking,
          userId: auth.currentUser.uid
        };
        await setDoc(doc(db, 'bookings', newBooking.id), payload);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, dbPath);
      }
    }
  };

  const handleCancelBooking = async (bookingId: string) => {
    const target = bookings.find(b => b.id === bookingId);
    if (!target) return;
    
    setBookings(prev => prev.filter(b => b.id !== bookingId));
    
    const notif: UserNotification = {
      id: `n-cancel-${Date.now()}`,
      title: 'Réservation annulée ❌',
      message: `Votre réservation pour "${target.experienceTitle}" a été annulée sans frais.`,
      date: 'À l\'instant',
      read: false
    };

    if (auth.currentUser) {
      try {
        await deleteDoc(doc(db, 'bookings', bookingId));
        
        const notifPayload = {
          ...notif,
          userId: auth.currentUser.uid
        };
        await setDoc(doc(db, 'notifications', notif.id), notifPayload);
        setNotifications(prev => [notifPayload, ...prev]);
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `bookings/${bookingId}`);
      }
    } else {
      setNotifications(prev => [notif, ...prev]);
    }
  };

  const handleAddExperience = (newExp: Experience) => {
    setExperiencesList(prev => [newExp, ...prev]);
  };

  const handleMarkNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const handleLoginSuccess = (role: 'user' | 'partner') => {
    setIsAuthenticated(true);
    setUserRole(role);
    setActivePage(role === 'partner' ? 'partner-dashboard' : 'user-dashboard');
    
    const welcomeNotif: UserNotification = {
      id: `n-welcome-${Date.now()}`,
      title: 'Connexion réussie ✨',
      message: `Heureux de vous revoir ! Vous naviguez en mode de démonstration ${role === 'partner' ? 'Professionnel Partenaire' : 'Explorateur Local'}.`,
      date: 'À l\'instant',
      read: false
    };
    setNotifications(prev => [welcomeNotif, ...prev]);
  };

  const handleLogout = async () => {
    try {
      await firebaseLogout();
    } catch (e) {
      console.error("Firebase logout error: ", e);
    }
    setIsAuthenticated(false);
    setActivePage('home');
    setBookings([]);
    setFavorites([]);
  };

  // Safe mapper favorites list
  const favoritedExperiences = experiencesList.filter(e => favorites.includes(e.id));

  return (
    <div className="min-h-screen bg-[#fafaf9] flex flex-col font-sans select-none antialiased">
      
      {/* 1. BRAND GLOBAL HEADER */}
      <Navbar 
        activePage={activePage}
        onNavigate={(page) => {
          setActivePage(page);
          if (page === 'explorer') {
            // clear transient selections during tab shifts
            setSelectedExperience(null);
          }
        }}
        favoritesCount={favorites.length}
        notifications={notifications}
        onMarkNotificationsRead={handleMarkNotificationsRead}
        isAuthenticated={isAuthenticated}
        onOpenAuth={(tab) => setAuthModal({ isOpen: true, initialTab: tab })}
        onLogout={handleLogout}
        userRole={userRole}
        onChangeRole={setUserRole}
      />

      {/* 2. DYNAMIC PRIMARY VIEWPORT PORTAL */}
      <main className="flex-grow">
        
        {activePage === 'home' && (
          <HomeView 
            onNavigate={setActivePage}
            onSelectExperience={(exp) => {
              setSelectedExperience(exp);
              setActivePage('event-detail');
            }}
            onSelectCategory={(catId) => {
              setSearchFilters({ city: '', category: catId, date: '' });
              setActivePage('explorer');
            }}
            favorites={favorites}
            onToggleFavorite={handleToggleFavorite}
            setSearchFilters={setSearchFilters}
          />
        )}

        {activePage === 'explorer' && (
          <ExplorerView 
            onSelectExperience={(exp) => {
              setSelectedExperience(exp);
              setActivePage('event-detail');
            }}
            favorites={favorites}
            onToggleFavorite={handleToggleFavorite}
            initialFilters={searchFilters}
            onClearInitialFilters={() => setSearchFilters({ city: '', category: '', date: '' })}
          />
        )}

        {activePage === 'event-detail' && selectedExperience && (
          <EventDetailView 
            key={selectedExperience.id}
            experience={selectedExperience}
            onNavigateToPartner={(pid) => {
              const part = partners.find(p => p.id === pid) || partners[0];
              setSelectedPartner(part);
              setActivePage('partner-detail');
              window.scrollTo({ top: 0, behavior: 'instant' });
            }}
            onSelectExperience={(exp) => {
              setSelectedExperience(exp);
              window.scrollTo({ top: 0, behavior: 'instant' });
            }}
            favorites={favorites}
            onToggleFavorite={handleToggleFavorite}
            onConfirmBooking={handleConfirmBooking}
            isAuthenticated={isAuthenticated}
            onOpenAuth={(tab) => setAuthModal({ isOpen: true, initialTab: tab })}
            bookings={bookings}
            onCancelBooking={handleCancelBooking}
          />
        )}

        {activePage === 'partner-detail' && selectedPartner && (
          <PartnerDetailView 
            partner={selectedPartner}
            onSelectExperience={(exp) => {
              setSelectedExperience(exp);
              setActivePage('event-detail');
              window.scrollTo({ top: 0, behavior: 'instant' });
            }}
            favorites={favorites}
            onToggleFavorite={handleToggleFavorite}
            onBack={() => {
              if (selectedExperience) {
                setActivePage('event-detail');
              } else {
                setActivePage('home');
              }
              window.scrollTo({ top: 0, behavior: 'instant' });
            }}
          />
        )}

        {activePage === 'become-partner' && (
          <BecomePartnerView />
        )}

        {activePage === 'user-dashboard' && (
          <UserDashboardView 
            bookings={bookings}
            onCancelBooking={handleCancelBooking}
            favorites={favoritedExperiences}
            favoritesIds={favorites}
            onToggleFavorite={handleToggleFavorite}
            onSelectExperience={(exp) => {
              setSelectedExperience(exp);
              setActivePage('event-detail');
            }}
            notifications={notifications}
            onMarkAllNotificationsRead={handleMarkNotificationsRead}
          />
        )}

        {activePage === 'partner-dashboard' && (
          <PartnerDashboardView 
            onAddExperience={handleAddExperience}
            experiencesCount={experiencesList.filter(x => x.partnerId === 'p1').length}
          />
        )}

        {(activePage === 'blog' || activePage === 'article-detail') && (
          <BlogView 
            onSelectArticle={(art) => {
              setSelectedArticle(art);
              setActivePage('article-detail');
            }}
            selectedArticle={selectedArticle}
            onCloseArticle={() => {
              setSelectedArticle(null);
              setActivePage('blog');
            }}
            onNavigateToExplorer={() => {
              setActivePage('explorer');
              setSelectedArticle(null);
            }}
          />
        )}

      </main>

      {/* 3. MOBILE IMMERSIVE BOTTOM TAB ACTIONS BAR */}
      <BottomNav 
        activePage={activePage}
        onNavigate={(page) => {
          setActivePage(page);
          if (page === 'blog') {
            setSelectedArticle(null);
          }
        }}
        favoritesCount={favorites.length}
        unreadCount={notifications.filter(n => !n.read).length}
      />

      {/* 4. BRAND GLOBAL FOOTER WITH SEO PARAGRAPHS */}
      <footer className="bg-brand-midnight text-[#E9E6D5] py-16 border-t border-[#E9E6D5]/10 select-none pb-24 md:pb-16 text-left">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-12">
          
          <div className="space-y-4">
            <span className="font-serif text-xl font-bold tracking-widest text-[#E9E6D5]">OSMOSE</span>
            <p className="text-xs text-stone-400 font-light leading-relaxed">
              Simplifiez la planification et l’organisation de vos moments d’évasion avec harmonie et efficacité. Osmose connecte la technologie et l’art de vivre.
            </p>
            <p className="text-[10px] text-brand-gold font-sans font-semibold">
              OSMOSE – Votre temps, notre priorité.
            </p>
          </div>

          <div>
            <h4 className="font-serif font-bold text-xs uppercase tracking-widest text-brand-gold mb-4">Mégalopoles couvertes</h4>
            <ul className="space-y-2 text-xs text-stone-400 font-light">
              <li>Paris (Île-de-France)</li>
              <li>Lyon (Rhône-Alpes)</li>
              <li>Marseille (PACA)</li>
              <li>Bordeaux (Nouvelle-Aquitaine)</li>
              <li>Nantes (Pays-de-la-Loire)</li>
            </ul>
          </div>

          <div>
            <h4 className="font-serif font-bold text-xs uppercase tracking-widest text-brand-gold mb-4 font-semibold">LES SPHÈRES</h4>
            <ul className="space-y-2 text-xs text-stone-400 font-light">
              <li>Sorties & Expériences</li>
              <li>Insolite & Cabanes</li>
              <li>Sport & Nature sauvage</li>
              <li>Gastronomie & Ateliers</li>
              <li>Bien-être & Massages</li>
            </ul>
          </div>

          <div className="space-y-4">
            <h4 className="font-serif font-bold text-xs uppercase tracking-widest text-brand-gold">Modèle de Monétisation</h4>
            <p className="text-[11px] text-stone-400 font-light leading-normal">
              Abonnement mensuel B2B fixe sans commissions pour les producteurs certifiés. Featured listings sponsorisés et premium visibility par ville.
            </p>
            <div className="pt-2 border-t border-brand-cream/10">
              <span className="text-[9px] text-[#E9E6D5] uppercase tracking-wider font-extrabold flex items-center gap-1">
                🛡️ PROS CERTIFIES CHARTE
              </span>
            </div>
          </div>

        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-8 border-t border-[#E9E6D5]/10 flex flex-col sm:flex-row justify-between items-center text-[10px] text-stone-500 gap-4">
          <p>© 2026 Osmose Inc. Tous droits réservés. Conforme à la Charte Graphique Osmose.</p>
          <div className="flex gap-4">
            <span className="hover:text-white cursor-pointer">Conditions Générales</span>
            <span className="hover:text-white cursor-pointer">Données Personnelles</span>
            <span className="hover:text-white cursor-pointer">Mentions Légales</span>
          </div>
        </div>
      </footer>

      {/* 5. INTERACTIVE AUTHENTICATION SCREENOVERLAY */}
      <AuthModal 
        isOpen={authModal.isOpen}
        initialTab={authModal.initialTab}
        onClose={() => setAuthModal({ isOpen: false, initialTab: 'login' })}
        onLoginSuccess={handleLoginSuccess}
      />

    </div>
  );
}
