export type CategoryId = 
  | 'sorties' 
  | 'insolite' 
  | 'sport' 
  | 'gastronomie' 
  | 'famille' 
  | 'bien_etre' 
  | 'sante';

export interface Category {
  id: CategoryId;
  name: string;
  image: string;
  icon: string;
  description: string;
  ctaText: string;
}

export interface Review {
  id: string;
  userName: string;
  userAvatar: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Partner {
  id: string;
  name: string;
  logo: string;
  coverImage: string;
  description: string;
  category: CategoryId;
  services: string[];
  rating: number;
  reviewsCount: number;
  reviews: Review[];
  location: string;
  founded: string;
  email: string;
  phone: string;
  premium: boolean;
}

export interface Experience {
  id: string;
  title: string;
  description: string;
  longDescription?: string;
  image: string;
  gallery: string[];
  location: string;
  city: 'Paris' | 'Lyon' | 'Marseille' | 'Bordeaux' | 'Nantes' | 'Lille';
  price: number;
  isFree: boolean;
  category: CategoryId;
  rating: number;
  reviewsCount: number;
  distance: number; // in km
  date: string;
  isWeekend: boolean;
  isToday: boolean;
  isRecommended: boolean;
  partnerId: string;
  coordinates: { x: number; y: number }; // Percentage offsets for custom high-fidelity Map representation
}

export interface Article {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  image: string;
  date: string;
  author: string;
  readingTime: string;
  category: string;
}

export interface Booking {
  id: string;
  experienceId: string;
  experienceTitle: string;
  experienceImage: string;
  date: string;
  price: number;
  status: 'upcoming' | 'completed' | 'cancelled';
  ticketsCount: number;
  partnerName: string;
  partnerLogo: string;
}

export interface UserNotification {
  id: string;
  title: string;
  message: string;
  date: string;
  read: boolean;
}

export type ActivePage = 
  | 'home' 
  | 'explorer' 
  | 'event-detail' 
  | 'partner-detail' 
  | 'become-partner' 
  | 'user-dashboard' 
  | 'partner-dashboard' 
  | 'blog' 
  | 'article-detail';
