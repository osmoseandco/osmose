import { Category, Experience, Partner, Article, Booking, UserNotification } from '../types';

export const categories: Category[] = [
  {
    id: 'sorties',
    name: 'Sorties & Expériences',
    icon: 'Compass',
    image: 'https://images.unsplash.com/photo-1511192336575-5a79af67a629?auto=format&fit=crop&w=1400&q=80',
    description: 'Découvrez des spectacles captivants, concerts intimes et événements culturels exclusifs.',
    ctaText: 'Explorer les sorties'
  },
  {
    id: 'insolite',
    name: 'Insolite',
    icon: 'Sparkles',
    image: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=1400&q=80',
    description: 'Vivez des aventures hors normes : nuits sous les étoiles, lieux secrets et mystérieux.',
    ctaText: 'Vivre l\'inattendu'
  },
  {
    id: 'sport',
    name: 'Sport',
    icon: 'Activity',
    image: 'https://images.unsplash.com/photo-1486218119243-13883505764c?auto=format&fit=crop&w=1400&q=80',
    description: 'Relevez le défi avec des sessions de surf, escalade de bloc ou randonnées guidées.',
    ctaText: 'Se dépasser'
  },
  {
    id: 'gastronomie',
    name: 'Gastronomie',
    icon: 'Utensils',
    image: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=1400&q=80',
    description: 'Éveillez vos papilles : cours de cuisine moléculaire, dégustations de vins rares et tables d\'hôtes.',
    ctaText: 'Déguster'
  },
  {
    id: 'famille',
    name: 'Famille',
    icon: 'Heart',
    image: 'https://images.unsplash.com/photo-1481841580057-e2b9927a05c6?auto=format&fit=crop&w=1400&q=80',
    description: 'Créez des souvenirs inoubliables avec des ateliers créatifs et parcs d\'exploration.',
    ctaText: 'Partager'
  },
  {
    id: 'bien_etre',
    name: 'Bien-être',
    icon: 'Layers',
    image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1400&q=80',
    description: 'Retrouvez votre harmonie lors de séances de bain sonore, yoga vinyasa ou massages premium.',
    ctaText: 'Se ressourcer'
  },
  {
    id: 'sante',
    name: 'Santé & Spécialistes',
    icon: 'ShieldAlert',
    image: 'https://images.unsplash.com/photo-1519817650390-64a93db51149?auto=format&fit=crop&w=1400&q=80',
    description: 'Consultez des kinésiologues certifiés, coachs de posture et nutritionnistes réputés.',
    ctaText: 'Prendre soin'
  }
];

export const partners: Partner[] = [
  {
    id: 'p1',
    name: 'Le Cercle de l\'Osmose',
    logo: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=200&h=200&q=80',
    coverImage: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=1200&q=80',
    description: 'Un espace gastronomique d’exception en plein cœur historique, alliant plaisirs culinaires raffinés et ateliers interactifs encadrés par des chefs étoilés.',
    category: 'gastronomie',
    services: ['Cours de cuisine privée', 'Dîner immersif', 'Dégustations exclusives', 'Privatisation d\'événements'],
    rating: 4.9,
    reviewsCount: 148,
    location: '12 Rue des Beaux-Arts, Paris',
    founded: '2021',
    email: 'contact@cercle-osmose.fr',
    phone: '+33 1 42 66 18 90',
    premium: true,
    reviews: [
      {
        id: 'r1',
        userName: 'Aurélie Martin',
        userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&h=100&q=80',
        rating: 5,
        comment: 'Une expérience de dégustation absolument inoubliable ! Le chef prend le temps d\'expliquer chaque alliance de goûts.',
        date: 'Il y a 3 jours'
      },
      {
        id: 'r2',
        userName: 'Marc Dubois',
        userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=100&h=100&q=80',
        rating: 4,
        comment: 'Le cadre est magnifique et la carte des vins est tout simplement incroyable. Je recommande vivement le menu signature.',
        date: 'Il y a 1 semaine'
      }
    ]
  },
  {
    id: 'p2',
    name: 'Atelier Holistique Nūba',
    logo: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&w=200&h=200&q=80',
    coverImage: 'https://images.unsplash.com/photo-1519824141121-997e5b99ad44?auto=format&fit=crop&w=1200&q=80',
    description: 'Nūba est un temple dédié à la relaxation profonde, aux rituels de soin ancestraux et aux thérapies holistiques avancées basées à Lyon.',
    category: 'bien_etre',
    services: ['Massages signatures', 'Bains de sons (Gong Bath)', 'Yoga Vinyasa', 'Thérapies énergétiques'],
    rating: 4.8,
    reviewsCount: 92,
    location: '45 Quai de la Pêcherie, Lyon',
    founded: '2022',
    email: 'hello@nuba-holistic.com',
    phone: '+33 4 72 00 11 22',
    premium: true,
    reviews: [
      {
        id: 'r3',
        userName: 'Sophie Viret',
        userAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=100&h=100&q=80',
        rating: 5,
        comment: 'Le bain sonore à Lyon m’a fait l’effet d’un reboot complet. Une sensation intense de légèreté par l’écoute vibratoire.',
        date: 'Il y a 2 jours'
      }
    ]
  },
  {
    id: 'p3',
    name: 'Altitude Aventure',
    logo: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=200&h=200&q=80',
    coverImage: 'https://images.unsplash.com/photo-1470246973918-29a93221c455?auto=format&fit=crop&w=1200&q=80',
    description: 'Une équipe de guides chevronnés vous accompagnant dans des activités sportives d\'extérieur : escalade, rafting et trekking sauvage.',
    category: 'sport',
    services: ['Randonnée guidée', 'Stage escalade de falaise', 'Rafting en eaux vives', 'Canyoning sensation'],
    rating: 4.7,
    reviewsCount: 64,
    location: 'Place du Village, Chamonix & Marseille',
    founded: '2019',
    email: 'info@altitude-aventure.org',
    phone: '+33 6 12 34 56 78',
    premium: false,
    reviews: []
  },
  {
    id: 'p4',
    name: 'Maison Bulle Cabanes',
    logo: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=200&h=200&q=80',
    coverImage: 'https://images.unsplash.com/photo-1488462237308-ecaa28b729d7?auto=format&fit=crop&w=1200&q=80',
    description: 'Des expériences de nuits d’hôtels insolites sous forme de dômes transparents haut de gamme nichés en pleine nature sauvage.',
    category: 'insolite',
    services: ['Nuit insolite sous bulle', 'Dîner sous coupole étoilée', 'Spa privatif extérieur'],
    rating: 4.9,
    reviewsCount: 112,
    location: 'Forêt de Fontainebleau, Île-de-France',
    founded: '2020',
    email: 'resa@maison-bulle.fr',
    phone: '+33 1 64 22 33 44',
    premium: true,
    reviews: []
  }
];

export const experiences: Experience[] = [
  {
    id: 'e1',
    title: 'Dîner Immersif & Théâtre Sensoriel',
    description: 'Un voyage gustatif de 5 plats plongé dans le noir complet avec design sonore 3D et acteurs invisibles.',
    longDescription: 'Prenez place pour une expérience inoubliable orchestrée par "Le Cercle de l\'Osmose". Durant 2 heures, vos yeux se reposent pendant que votre ouïe, votre odorat et vos papilles s’éveillent de façon spectaculaire. Chaque plat est accompagné de textures tactiles, de murmures de comédiens, de parfums boisés et d’instruments de musique joués à proximité immédiate pour conter une histoire légendaire.',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=800&q=80'
    ],
    location: 'Le Cercle de l\'Osmose, Paris',
    city: 'Paris',
    price: 85,
    isFree: false,
    category: 'gastronomie',
    rating: 4.95,
    reviewsCount: 54,
    distance: 1.2,
    date: '2026-05-20',
    isToday: true,
    isWeekend: false,
    isRecommended: true,
    partnerId: 'p1',
    coordinates: { x: 38, y: 42 }
  },
  {
    id: 'e2',
    title: 'Bain Sonore vibratoire aux Gongs Sacrés',
    description: 'Une relaxation acoustique totale allongée sur des futons, bercée par des bols en cristal d’Himalaya.',
    longDescription: 'Installez-vous pour une résonance réparatrice unique d’une heure et demie. Les gongs, cymbales et bols de cristal créent des vibrations physiques harmonieuses qui pénètrent les cellules pour relâcher instantanément les tensions musculaires et le stress psychique accumulé. Le rituel se termine par une infusion d’herbes bio sélective.',
    image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1519824141121-997e5b99ad44?auto=format&fit=crop&w=800&q=80'
    ],
    location: 'Atelier Holistique Nūba, Lyon',
    city: 'Lyon',
    price: 35,
    isFree: false,
    category: 'bien_etre',
    rating: 4.88,
    reviewsCount: 38,
    distance: 2.8,
    date: '2026-05-23',
    isToday: false,
    isWeekend: true,
    isRecommended: true,
    partnerId: 'p2',
    coordinates: { x: 55, y: 65 }
  },
  {
    id: 'e3',
    title: 'Nuit Céleste sous Bulle Transparente',
    description: 'Dormez sous la Voie Lactée avec tout le confort d\'une suite d\'hôtel de luxe.',
    longDescription: 'Maison Bulle vous propose un cocon éco-conçu transparent à 100%, chauffé à température idéale. Profitez de votre lit king-size tout en restant à l’affût du passage des comètes. Le forfait inclut un accès illimité au jacuzzi extérieur chauffé au bois, un télescope autofocus et un panier de petit-déjeuner bio livré au saut du lit devant votre bulle.',
    image: 'https://images.unsplash.com/photo-1488462237308-ecaa28b729d7?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1488462237308-ecaa28b729d7?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1470240112957-efb55102a07e?auto=format&fit=crop&w=800&q=80'
    ],
    location: 'Forêt de Fontainebleau, Île-de-France',
    city: 'Paris',
    price: 195,
    isFree: false,
    category: 'insolite',
    rating: 4.91,
    reviewsCount: 88,
    distance: 45.0,
    date: '2026-05-24',
    isToday: false,
    isWeekend: true,
    isRecommended: true,
    partnerId: 'p4',
    coordinates: { x: 42, y: 35 }
  },
  {
    id: 'e4',
    title: 'Excursion Randonnée Littorale Secrète',
    description: 'Une exploration des sentiers oubliés des Calanques sauvages, avec initiation gratuite à la flore locale.',
    longDescription: 'Partez à la découverte des splendeurs cachées de la Côte Bleue avec notre guide diplômé. Cette randonnée de 3h conjugue panoramas époustouflants et apprentissage de la boussole. Totalement gratuit pour sensibiliser à la protection environnementale marine.',
    image: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1542037104857-ffbe0484de3e?auto=format&fit=crop&w=800&q=80'
    ],
    location: 'Parc National des Calanques, Marseille',
    city: 'Marseille',
    price: 0,
    isFree: true,
    category: 'sport',
    rating: 4.75,
    reviewsCount: 19,
    distance: 4.5,
    date: '2026-05-20',
    isToday: true,
    isWeekend: false,
    isRecommended: false,
    partnerId: 'p3',
    coordinates: { x: 72, y: 88 }
  },
  {
    id: 'e5',
    title: 'Atelier Parent-Enfant : Archéologie & Poterie',
    description: 'Venez fouiller comme un archéologue puis façonner une œuvre antique ensemble de vos mains.',
    longDescription: 'Un atelier immersif exceptionnel d’une matinée conçu pour les enfants de 5 à 12 ans et leurs parents. Simulation de chantier de fouille sous-terraine par des professionnels agréés puis création de céramique argilise que vous emporterez fièrement.',
    image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1502082553048-f009c37129b9?auto=format&fit=crop&w=800&q=80'
    ],
    location: 'Atelier de Création l\'Escargot, Bordeaux',
    city: 'Bordeaux',
    price: 15,
    isFree: false,
    category: 'famille',
    rating: 4.82,
    reviewsCount: 29,
    distance: 3.1,
    date: '2026-05-23',
    isToday: false,
    isWeekend: true,
    isRecommended: false,
    partnerId: 'p1',
    coordinates: { x: 25, y: 70 }
  },
  {
    id: 'e6',
    title: 'Exposition Privée Street Art & Cocktails',
    description: 'Visite exclusive d\'une friche industrielle métamorphosée par 12 grapheurs influents avec mixologue.',
    longDescription: 'Faufilez-vous dans un hangar secret normalement fermé au grand public. Votre billet comprend deux cocktails créatifs concoctés sur place par des barmen experts de la scène nocturne urbaine et un set de DJ alternatif.',
    image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=800&q=80'
    ],
    location: 'Le Lab Nomade, Nantes',
    city: 'Nantes',
    price: 25,
    isFree: false,
    category: 'sorties',
    rating: 4.68,
    reviewsCount: 42,
    distance: 0.8,
    date: '2026-05-20',
    isToday: true,
    isWeekend: false,
    isRecommended: true,
    partnerId: 'p1',
    coordinates: { x: 18, y: 52 }
  },
  {
    id: 'e7',
    title: 'Consultation Posture & Alignement Bio-moteur',
    description: 'Une séance diagnostic complète avec capteurs 3D pour rééquilibrer vos appuis au quotidien.',
    longDescription: 'Consultez notre kinésiologue spécialiste de la motricité. Idéal pour les sportifs confirmés ou pour corriger la fatigue due au travail assis prolongé. Vous repartez avec votre rapport médical modélisé par e-mail.',
    image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=800&q=80'
    ],
    location: 'Centre Santé du Parc, Paris',
    city: 'Paris',
    price: 70,
    isFree: false,
    category: 'sante',
    rating: 4.9,
    reviewsCount: 22,
    distance: 1.5,
    date: '2026-05-20',
    isToday: true,
    isWeekend: false,
    isRecommended: false,
    partnerId: 'p2',
    coordinates: { x: 36, y: 44 }
  },
  {
    id: 'e8',
    title: 'Stage d\'Initiation à la slackline côtière',
    description: 'Prenez de la hauteur et apprenez à tenir en équilibre parfait au-dessus du sable, stage gratuit ouvert à tous.',
    longDescription: 'Encadrés par des champions de France de Highline, venez tester vos réflexes d’équilibre et de respiration. Équipements de pointe fournis, aucune expérience requise.',
    image: 'https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=800&q=80'
    ],
    location: 'Plage du Prado, Marseille',
    city: 'Marseille',
    price: 0,
    isFree: true,
    category: 'sport',
    rating: 4.64,
    reviewsCount: 14,
    distance: 5.2,
    date: '2026-05-23',
    isToday: false,
    isWeekend: true,
    isRecommended: false,
    partnerId: 'p3',
    coordinates: { x: 74, y: 85 }
  },
  {
    id: 'e9',
    title: 'Visite guidée gratuite : Secret d\'Histoire de Lille',
    description: 'Découvrez les souterrains secrets et l\'influence médiévale flamande de Lille gratuitement.',
    longDescription: 'Une visite pédestre féérique animée par Nicolas, historien passionné locale. Parcourez des cryptes habituellement scellées sous la ville historique.',
    image: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=800&q=80'
    ],
    location: 'Mairie de Lille, Lille',
    city: 'Lille',
    price: 0,
    isFree: true,
    category: 'sorties',
    rating: 4.88,
    reviewsCount: 31,
    distance: 0.1,
    date: '2026-05-24',
    isToday: false,
    isWeekend: true,
    isRecommended: false,
    partnerId: 'p4',
    coordinates: { x: 45, y: 15 }
  }
];

export const articles: Article[] = [
  {
    id: 'a1',
    title: '5 coins insolites pour pique-niquer en Île-de-France cet été',
    excerpt: 'Loin du surpeuplement des quais de Seine, découvrez des enclaves magiques et mysthiques pour installer votre nappe.',
    content: 'La recherche du spot de pique-nique idéal à Paris relève souvent du parcours du combattant. Entre pelouses bondées et bruit de circulation, s’isoler relève de l’exploit. C’est pourquoi nous vous dévoilons notre guide exclusif des recoins cachés. Des carrières de grès de Fontainebleau pour un déjeuner d’alpinistes, au jardin chinois secret caché derrière des murs de pierre en Seine-et-Marne, vous découvrirez des lieux préservés de la fureur urbaine.\n\nPrévoyez des aliments frais locaux et laissez l’endroit impeccable ! Notre coup de cœur va sans conteste aux jardins oubliés d’un ancien moulin de l’Essonne où le clapotis de l’eau douce escorte vos dégustations.',
    image: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=800&q=80',
    date: '20 Mai 2026',
    author: 'Mathilde Leroy',
    readingTime: '4 min',
    category: 'Insolite'
  },
  {
    id: 'a2',
    title: 'L’essor de la sonothérapie : se soigner par les ondes vibratoires',
    excerpt: 'Plongée dans cette thérapie acoustique millénaire de plus en plus plébiscitée par les citadins en quête d’harmonie.',
    content: 'Des bols tibétains de métal aux carillons en cristal, la sonothérapie investit et transforme les spas citadins. Comment l’écoute de fréquences pures peut-elle abaisser le cortisol sanguin en moins de 15 minutes ? Des études médicales récentes démontrent la synchronisation des ondes cérébrales avec les rythmes profonds des gongs. Notre système nerveux se cale naturellement sur ces vibrations apaisantes favorisant une auto-guérison cérébrale inédite.\n\nNous avons testé pour vous une séance d’Osmose vibratoire à l’Atelier Nūba, un véritable voyage astral sans quitter les tapis douillets.',
    image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=800&q=80',
    date: '18 Mai 2026',
    author: 'Romain Gauthier',
    readingTime: '6 min',
    category: 'Bien-être'
  },
  {
    id: 'a3',
    title: 'La gastronomie sensorielle, ou comment manger sans la vue réinvente le goût',
    excerpt: 'Pourquoi fermer les yeux démultiplie l’expérience des saveurs et transforme notre relation intime à l’assiette.',
    content: 'Quand la lumière s’éteint définitivement dans un restaurant immersif, une étrange sensation d’alarme fait place à une concentration extrême de nos capteurs olfactifs et tactiles. En privant le cerveau de sa principale boussole – le visuel –, le goût et les arômes des aliments sont perçus avec une netteté décuplée. Une simple cuillère de crème de chou-fleur à l’aneth devient une explosion complexe de textures chaudes, d’acidité et d\'arômes insoupçonnés.',
    image: 'https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?auto=format&fit=crop&w=800&q=80',
    date: '15 Mai 2026',
    author: 'Chef Alexandre',
    readingTime: '5 min',
    category: 'Gastronomie'
  }
];

export const mockNotifications: UserNotification[] = [
  {
    id: 'n1',
    title: 'Réservation confirmée ✅',
    message: 'Votre réservation pour "Dîner Immersif & Théâtre Sensoriel" le 20 mai est confirmée par le partenaire.',
    date: 'Aujourd\'hui, 10:15',
    read: false
  },
  {
    id: 'n2',
    title: 'Nouveau message d\'un partenaire ✉️',
    message: 'Atelier Holistique Nūba : "Bonjour, veuillez prévoir des vêtements amples pour votre séance de gongs."',
    date: 'Hier, 14:32',
    read: true
  }
];

export const initialBookings: Booking[] = [
  {
    id: 'b-001',
    experienceId: 'e1',
    experienceTitle: 'Dîner Immersif & Théâtre Sensoriel',
    experienceImage: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=150&q=80',
    date: '20 Mai 2026',
    price: 85,
    status: 'upcoming',
    ticketsCount: 1,
    partnerName: 'Le Cercle de l\'Osmose',
    partnerLogo: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=100&h=100&q=80'
  }
];
