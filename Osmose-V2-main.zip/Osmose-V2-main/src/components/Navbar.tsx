import { useState } from 'react';
import { ActivePage, UserNotification } from '../types';
import { LucideIcon } from './LucideIcon';

interface NavbarProps {
  activePage: ActivePage;
  onNavigate: (page: ActivePage) => void;
  favoritesCount: number;
  notifications: UserNotification[];
  onMarkNotificationsRead: () => void;
  isAuthenticated: boolean;
  onOpenAuth: (tab: 'login' | 'signup') => void;
  onLogout: () => void;
  userRole: 'user' | 'partner';
  onChangeRole: (role: 'user' | 'partner') => void;
}

export function Navbar({
  activePage,
  onNavigate,
  favoritesCount,
  notifications,
  onMarkNotificationsRead,
  isAuthenticated,
  onOpenAuth,
  onLogout,
  userRole,
  onChangeRole
}: NavbarProps) {
  const [notifOpen, setNotifOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  
  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          
          {/* Logo Brand Brand */}
          <div 
            onClick={() => onNavigate('home')} 
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="relative w-14 h-14 flex items-center justify-center group-hover:scale-105 transition-transform duration-300 select-none shrink-0 -my-1">
              <svg className="w-full h-full" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  {/* Luxury Metallic Gold Gradient */}
                  <linearGradient id="logoGold" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#cca353" />
                    <stop offset="30%" stopColor="#f8f1d5" />
                    <stop offset="50%" stopColor="#bfa054" />
                    <stop offset="85%" stopColor="#ebd79d" />
                    <stop offset="100%" stopColor="#9c7a3c" />
                  </linearGradient>
                  {/* Luxury Deep Emerald Green Gradient */}
                  <linearGradient id="logoGreen" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#10574D" />
                    <stop offset="50%" stopColor="#0a473f" />
                    <stop offset="100%" stopColor="#042c27" />
                  </linearGradient>
                  {/* Location Pin Shiny Petrol-Green Gradient */}
                  <linearGradient id="pinGreen" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#1C7E71" />
                    <stop offset="100%" stopColor="#0B423A" />
                  </linearGradient>
                </defs>
                
                {/* Thin beautiful golden outer circle bounding container */}
                <circle cx="48" cy="45" r="38" fill="none" stroke="url(#logoGold)" strokeWidth="2.5" />
                
                {/* Emerald Green Rounded Calendar Plate */}
                <rect x="26" y="24" width="44" height="42" rx="7" fill="url(#logoGreen)" stroke="#052723" strokeWidth="0.8" />
                
                {/* Dual Vertical Metallic Gold Ring Hooks */}
                <rect x="33" y="15" width="5.5" height="14" rx="2.5" fill="url(#logoGold)" />
                <rect x="61" y="15" width="5.5" height="14" rx="2.5" fill="url(#logoGold)" />
                
                {/* Golden horizontal header delimiter line built inside the plate */}
                <line x1="26" y1="31" x2="70" y2="31" stroke="url(#logoGold)" strokeWidth="1" opacity="0.8" />
                
                {/* 2x3 Grid representing scheduler days, colored in gold dots/squares */}
                <rect x="33" y="37" width="7" height="7" rx="1.5" fill="url(#logoGold)" />
                <rect x="44" y="37" width="7" height="7" rx="1.5" fill="url(#logoGold)" />
                <rect x="55" y="37" width="7" height="7" rx="1.5" fill="url(#logoGold)" />
                <rect x="33" y="48" width="7" height="7" rx="1.5" fill="url(#logoGold)" />
                <rect x="44" y="48" width="7" height="7" rx="1.5" fill="url(#logoGold)" />
                <rect x="55" y="48" width="7" height="7" rx="1.5" fill="url(#logoGold)" />
                
                {/* Intersecting teardrop map-pin location indicator on the lower right periphery */}
                <path 
                  d="M 72 45 C 62 45, 55 53, 72 75 C 89 53, 82 45, 72 45 Z" 
                  fill="url(#pinGreen)" 
                  stroke="url(#logoGold)" 
                  strokeWidth="1.5" 
                />
                
                {/* Core inner gold dot marker on pin center */}
                <circle cx="72" cy="55" r="5" fill="url(#logoGold)" />
                <circle cx="72" cy="55" r="4" fill="none" stroke="#fff" strokeWidth="0.5" opacity="0.6" />
              </svg>
            </div>
            <div>
              <span className="font-serif text-2xl font-bold tracking-[0.18em] text-brand-green-dark group-hover:text-brand-green-med transition-colors duration-300">
                OSMOSE
              </span>
              <p className="font-sans text-[8px] tracking-[0.3em] uppercase text-brand-gold -mt-1 font-semibold">
                Harmonie & Temps
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <button 
              onClick={() => onNavigate('explorer')}
              className={`font-sans font-medium text-sm tracking-wider uppercase transition-colors relative py-1 ${
                activePage === 'explorer' 
                  ? 'text-brand-green-dark font-semibold' 
                  : 'text-stone-500 hover:text-brand-green-dark'
              }`}
            >
              Explorer
              {activePage === 'explorer' && (
                <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-brand-gold rounded-full" />
              )}
            </button>

            <button 
              onClick={() => onNavigate('blog')}
              className={`font-sans font-medium text-sm tracking-wider uppercase transition-colors relative py-1 ${
                activePage === 'blog' || activePage === 'article-detail' 
                  ? 'text-brand-green-dark font-semibold' 
                  : 'text-stone-500 hover:text-brand-green-dark'
              }`}
            >
              Guides & Blog
              {(activePage === 'blog' || activePage === 'article-detail') && (
                <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-brand-gold rounded-full" />
              )}
            </button>

            <button 
              onClick={() => onNavigate('become-partner')}
              className={`font-sans font-medium text-sm tracking-wider uppercase transition-colors relative py-1 ${
                activePage === 'become-partner' 
                  ? 'text-brand-green-dark font-semibold' 
                  : 'text-stone-500 hover:text-brand-green-dark'
              }`}
            >
              Partenaires
              {activePage === 'become-partner' && (
                <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-brand-gold rounded-full" />
              )}
            </button>
          </nav>

          {/* Quick Action Controls */}
          <div className="flex items-center gap-4">
            
            {/* Quick Favorites shortcut icon */}
            <button 
              onClick={() => onNavigate('user-dashboard')}
              className="p-2 text-stone-500 hover:text-brand-green-dark relative rounded-full hover:bg-stone-50 transition-colors"
              title="Mes Favoris & Réservations"
            >
              <LucideIcon name="Heart" size={20} />
              {favoritesCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-brand-gold text-brand-green-dark text-[10px] font-extrabold w-5 h-5 rounded-full flex items-center justify-center border-2 border-white">
                  {favoritesCount}
                </span>
              )}
            </button>

            {/* Notifications Popover trigger */}
            <div className="relative">
              <button 
                onClick={() => {
                  setNotifOpen(!notifOpen);
                  setProfileOpen(false);
                  if (!notifOpen && unreadCount > 0) {
                    onMarkNotificationsRead();
                  }
                }}
                className="p-2 text-stone-500 hover:text-brand-green-dark relative rounded-full hover:bg-stone-50 transition-colors"
              >
                <LucideIcon name="Bell" size={20} />
                {unreadCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-brand-gold rounded-full animate-ping" />
                )}
              </button>

              {notifOpen && (
                <div className="absolute right-0 mt-3 w-80 bg-white border border-stone-200 rounded-2xl shadow-xl z-50 overflow-hidden transform origin-top-right transition-all animate-in fade-in-50 duration-200">
                  <div className="p-4 bg-brand-green-dark text-white flex justify-between items-center">
                    <h3 className="font-serif font-bold text-sm tracking-wider">NOTIFICATIONS</h3>
                    <button 
                      onClick={() => setNotifOpen(false)}
                      className="text-stone-300 hover:text-white"
                    >
                      <LucideIcon name="X" size={16} />
                    </button>
                  </div>
                  <div className="max-h-72 overflow-y-auto divide-y divide-stone-100">
                    {notifications.length === 0 ? (
                      <div className="p-6 text-center text-stone-400 text-xs">
                        Aucune notification pour le moment.
                      </div>
                    ) : (
                      notifications.map(n => (
                        <div key={n.id} className={`p-4 hover:bg-stone-50 transition-colors ${!n.read ? 'bg-emerald-50/20' : ''}`}>
                          <div className="flex justify-between items-start gap-2">
                            <span className="font-semibold text-xs text-brand-green-dark">{n.title}</span>
                            <span className="text-[9px] text-stone-400">{n.date}</span>
                          </div>
                          <p className="text-xs text-stone-600 mt-1">{n.message}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Profile Menu dropdown & Identity Selector */}
            <div className="relative">
              {isAuthenticated ? (
                <div>
                  <button 
                    onClick={() => {
                      setProfileOpen(!profileOpen);
                      setNotifOpen(false);
                    }}
                    className="flex items-center gap-2 p-1.5 border border-stone-200 rounded-full hover:border-brand-green-med transition-all duration-200 bg-stone-50"
                  >
                    <div className="w-8 h-8 rounded-full bg-brand-green-med/20 flex items-center justify-center text-brand-green-dark font-bold text-sm">
                      M
                    </div>
                    <span className="hidden lg:inline text-xs font-semibold text-stone-700 px-1">
                      {userRole === 'partner' ? 'Partenaire ✨' : 'Explorateur'}
                    </span>
                  </button>

                  {profileOpen && (
                    <div className="absolute right-0 mt-3 w-56 bg-white border border-stone-200 rounded-2xl shadow-xl z-50 overflow-hidden py-1">
                      <div className="px-4 py-3 border-b border-stone-100 bg-stone-50">
                        <p className="text-xs text-stone-400">Connecté en tant que</p>
                        <p className="font-semibold text-xs text-stone-800">osmoseandco@gmail.com</p>
                      </div>

                      {/* Role switcher for template testing */}
                      <div className="p-2 border-b border-stone-100">
                        <p className="text-[9px] uppercase tracking-wider text-brand-gold font-bold px-2 mb-1">
                          Mode de démonstration :
                        </p>
                        <div className="grid grid-cols-2 gap-1 bg-stone-100 p-1 rounded-lg">
                          <button
                            onClick={() => {
                              onChangeRole('user');
                              onNavigate('user-dashboard');
                              setProfileOpen(false);
                            }}
                            className={`text-[10px] py-1 rounded-md font-medium transition-colors ${
                              userRole === 'user'
                                ? 'bg-brand-green-dark text-white'
                                : 'text-stone-600 hover:bg-stone-200'
                            }`}
                          >
                            Utilisateur
                          </button>
                          <button
                            onClick={() => {
                              onChangeRole('partner');
                              onNavigate('partner-dashboard');
                              setProfileOpen(false);
                            }}
                            className={`text-[10px] py-1 rounded-md font-medium transition-colors ${
                              userRole === 'partner'
                                ? 'bg-brand-green-dark text-white'
                                : 'text-stone-600 hover:bg-stone-200'
                            }`}
                          >
                            Partenaire
                          </button>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          onNavigate('user-dashboard');
                          setProfileOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-stone-700 hover:bg-brand-cream/30 hover:text-brand-green-dark flex items-center gap-2"
                      >
                        <LucideIcon name="User" size={14} className="text-stone-400" />
                        Mon Espace
                      </button>

                      {userRole === 'partner' && (
                        <button
                          onClick={() => {
                            onNavigate('partner-dashboard');
                            setProfileOpen(false);
                          }}
                          className="w-full text-left px-4 py-2 text-xs text-stone-700 hover:bg-brand-cream/30 hover:text-brand-green-dark flex items-center gap-2"
                        >
                          <LucideIcon name="TrendingUp" size={14} className="text-brand-gold" />
                          Dashboard Pro
                        </button>
                      )}

                      <button
                        onClick={() => {
                          onLogout();
                          setProfileOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-red-600 hover:bg-red-50 flex items-center gap-2 border-t border-stone-100 mt-1"
                      >
                        <LucideIcon name="Trash" size={14} className="text-red-400" />
                        Se déconnecter
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex gap-2">
                  <button 
                    onClick={() => onOpenAuth('login')}
                    className="hidden sm:inline px-4 py-2 text-xs font-semibold uppercase tracking-wider text-stone-600 hover:text-brand-green-dark transition-colors"
                  >
                    Connexion
                  </button>
                  <button 
                    onClick={() => onOpenAuth('signup')}
                    className="px-4 py-2 bg-brand-green-dark hover:bg-brand-green-med text-brand-cream text-xs font-sans font-bold uppercase tracking-widest rounded-full shadow-md hover:shadow-lg transition-all duration-300 border border-brand-gold"
                  >
                    S'inscrire
                  </button>
                </div>
              )}
            </div>

          </div>

        </div>
      </div>
    </header>
  );
}
