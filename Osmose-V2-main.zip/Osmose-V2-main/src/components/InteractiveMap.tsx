import { useState, useMemo, useCallback, memo } from 'react';
import { Experience, CategoryId } from '../types';
import { LucideIcon } from './LucideIcon';

interface InteractiveMapProps {
  experiences: Experience[];
  selectedExperience: Experience | null;
  onSelectExperience: (experience: Experience) => void;
  className?: string;
}

const colorMap: Record<CategoryId, string> = {
  sorties: 'bg-indigo-600',
  insolite: 'bg-amber-600',
  sport: 'bg-sky-600',
  gastronomie: 'bg-rose-600',
  famille: 'bg-emerald-600',
  bien_etre: 'bg-teal-600',
  sante: 'bg-cyan-600'
};

const iconMap: Record<CategoryId, string> = {
  sorties: 'Compass',
  insolite: 'Sparkles',
  sport: 'Activity',
  gastronomie: 'Utensils',
  famille: 'Heart',
  bien_etre: 'Layers',
  sante: 'ShieldAlert'
};

// 1. HIGH-PERFORMANCE MEMOIZED MAP PIN COMPONENT (With Custom comparator to 100% bypass unneeded re-renders on slider changes)
const MapPin = memo(function MapPin({
  experience,
  isSelected,
  pinColor,
  onClick
}: {
  experience: Experience;
  isSelected: boolean;
  pinColor: string;
  onClick: (experience: Experience) => void;
}) {
  const handleClick = useCallback(() => {
    onClick(experience);
  }, [experience, onClick]);

  const isFree = experience.price === 0;
  const categoryIcon = isFree ? 'Star' : (iconMap[experience.category] || 'Compass');

  return (
    <div
      className="absolute z-20 cursor-pointer -translate-x-1/2 -translate-y-1/2 transition-all duration-300 hover:z-30 hover:scale-110"
      style={{ left: `${experience.coordinates.x}%`, top: `${experience.coordinates.y}%` }}
      onClick={handleClick}
    >
      {isSelected ? (
        /* High visual balloon detailing current selection */
        <div className={`font-bold text-xs p-1 rounded-full shadow-2xl border-2 flex items-center gap-1.5 shrink-0 animate-bounce whitespace-nowrap ${isFree ? 'bg-gradient-to-r from-emerald-850 via-brand-green-dark to-teal-900 text-brand-cream border-amber-400' : 'bg-brand-green-dark text-brand-cream border-brand-gold'}`}>
          <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs shrink-0 ${isFree ? 'bg-amber-400/20 text-amber-400' : 'bg-brand-gold/10 text-brand-gold'}`}>
            <LucideIcon name={categoryIcon} size={12} className="stroke-[2.5]" />
          </div>
          <div className="pr-2 flex items-center gap-1.5">
            <span className={`text-[10px] font-sans font-extrabold px-1.5 py-0.5 rounded ${isFree ? 'bg-amber-400 text-stone-905 shadow-sm' : 'bg-brand-gold text-brand-green-dark'}`}>
              {isFree ? 'Gratuit' : `${experience.price}€`}
            </span>
            <span className="truncate max-w-[100px] text-[10px] font-serif font-medium leading-none text-brand-cream">
              {experience.title.split(':')[0]}
            </span>
          </div>
        </div>
      ) : (
        /* Dynamic small modern target bubble */
        <div className="group/pin relative flex flex-col items-center">
          {isFree ? (
            /* Special glowing gold badge with Star icon for FREE experiences */
            <div className="flex items-center gap-1 bg-gradient-to-r from-amber-400 via-yellow-200 to-amber-500 text-stone-900 border-2 border-amber-600 px-2.5 py-1 rounded-full shadow-xl font-extrabold text-[9px] hover:scale-110 transition-transform animate-pulse max-w-[125px] whitespace-nowrap">
              <div className="w-3.5 h-3.5 rounded-full bg-stone-950 flex items-center justify-center text-amber-400 shrink-0">
                <LucideIcon name="Star" size={9} className="stroke-[3] fill-amber-400 text-amber-400" />
              </div>
              <span className="tracking-wider uppercase text-[8px] font-black text-stone-950">GRATUIT</span>
            </div>
          ) : (
            /* Standard pin displaying price and icon on hover */
            <div className={`flex items-center gap-1 ${pinColor} text-white px-2 py-1 rounded-full shadow-md font-bold text-[9px] hover:scale-105 transition-transform border border-white/20 max-w-[115px] whitespace-nowrap`}>
              <div className="w-3.5 h-3.5 rounded-full bg-white/20 flex items-center justify-center text-white shrink-0">
                <LucideIcon name={categoryIcon} size={9} className="stroke-[2.5]" />
              </div>
              <span className="font-sans font-bold">{experience.price}€</span>
            </div>
          )}
          
          {/* Pin Pointer triangle */}
          <div className={`w-1.5 h-1.5 rotate-45 -mt-[4px] shadow-sm border-r border-b border-black/5 ${isFree ? 'bg-amber-400 border-r-amber-600 border-b-amber-600' : pinColor}`} />
        </div>
      )}
    </div>
  );
}, (prevProps, nextProps) => {
  // Deep visual and reference tracking comparison
  return (
    prevProps.isSelected === nextProps.isSelected &&
    prevProps.pinColor === nextProps.pinColor &&
    prevProps.experience.id === nextProps.experience.id &&
    prevProps.experience.price === nextProps.experience.price &&
    prevProps.experience.title === nextProps.experience.title &&
    prevProps.experience.category === nextProps.experience.category &&
    prevProps.experience.coordinates.x === nextProps.experience.coordinates.x &&
    prevProps.experience.coordinates.y === nextProps.experience.coordinates.y
  );
});

export function InteractiveMap({ 
  experiences, 
  selectedExperience, 
  onSelectExperience, 
  className = "h-[450px]" 
}: InteractiveMapProps) {
  const [mapType, setMapType] = useState<'standard' | 'satellite'>('standard');
  const [zoom, setZoom] = useState(13);
  const [isLocating, setIsLocating] = useState(false);
  const [showUserLocCode, setShowUserLocCode] = useState(true);

  // Simulated GPS positioning coordinate
  const userLocation = useMemo(() => ({ x: 35, y: 50 }), []);

  const handleGeolocateMe = useCallback(() => {
    setIsLocating(true);
    setTimeout(() => {
      setIsLocating(false);
      setShowUserLocCode(true);
    }, 1200);
  }, []);

  const handleZoomIn = useCallback(() => {
    setZoom(prev => Math.min(prev + 1, 18));
  }, []);

  const handleZoomOut = useCallback(() => {
    setZoom(prev => Math.max(prev - 1, 10));
  }, []);

  // 2. VECTOR PATHS & GRID PATTERNS VIRTUALIZED ONCE VIA USEMEMO
  const mapSvgBackground = useMemo(() => (
    <svg className="absolute inset-0 w-full h-full opacity-60 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
          <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#0E5B50" strokeWidth="0.5" strokeOpacity="0.08" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#grid)" />
      
      {/* The Seine / Rhone River representations */}
      <path d="M-50,150 Q150,80 350,180 T750,120 T1150,190" fill="none" stroke="#bae6fd" strokeWidth="50" strokeLinecap="round" strokeOpacity="1" />
      <path d="M-50,150 Q150,80 350,180 T750,120 T1150,190" fill="none" stroke="#38bdf8" strokeWidth="8" strokeLinecap="round" strokeOpacity="0.4" />
      
      {/* Main Primary Boulevard Roads */}
      <line x1="0" y1="200" x2="1600" y2="400" stroke="#ffffff" strokeWidth="12" />
      <line x1="0" y1="200" x2="1600" y2="400" stroke="#f1f5f9" strokeWidth="6" />
      
      <line x1="400" y1="0" x2="400" y2="1000" stroke="#ffffff" strokeWidth="16" />
      <line x1="400" y1="0" x2="400" y2="1000" stroke="#f1f5f9" strokeWidth="8" />

      <line x1="0" y1="60" x2="1600" y2="120" stroke="#ffffff" strokeWidth="10" />
      <line x1="0" y1="60" x2="1600" y2="120" stroke="#f1f5f9" strokeWidth="4" />

      {/* Simulated green spaces/parks */}
      <circle cx="250" cy="300" r="80" fill="#dcfce7" fillOpacity="0.8" />
      <circle cx="850" cy="120" r="110" fill="#dcfce7" fillOpacity="0.8" />
    </svg>
  ), []);

  const satelliteBgStyle = useMemo(() => ({
    backgroundImage: `url('https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&w=1200&q=80')`
  }), []);

  const handlePinSelect = useCallback((exp: Experience) => {
    onSelectExperience(exp);
  }, [onSelectExperience]);

  return (
    <div className={`relative rounded-3xl overflow-hidden border border-stone-200 shadow-lg bg-stone-100 flex flex-col ${className}`}>
      
      {/* Map Control Buttons Top Right */}
      <div className="absolute top-4 right-4 z-20 flex flex-col gap-2">
        <div className="bg-white rounded-xl shadow-md p-1 border border-stone-100 flex flex-col gap-0.5">
          <button 
            onClick={handleZoomIn}
            className="w-8 h-8 rounded-lg hover:bg-stone-50 flex items-center justify-center text-stone-600 font-bold text-sm"
            title="S'approcher"
          >
            +
          </button>
          <div className="w-5 h-[1px] bg-stone-200 mx-auto" />
          <button 
            onClick={handleZoomOut}
            className="w-8 h-8 rounded-lg hover:bg-stone-50 flex items-center justify-center text-stone-600 font-bold text-sm"
            title="S'éloigner"
          >
            -
          </button>
        </div>

        <button 
          onClick={handleGeolocateMe}
          className={`w-9 h-9 rounded-xl bg-white shadow-md border border-stone-100 flex items-center justify-center text-stone-700 hover:text-brand-green-dark transition-colors ${isLocating ? 'animate-spin' : ''}`}
          title="Me géolocaliser"
        >
          <LucideIcon name="Compass" size={16} className={isLocating ? 'text-brand-gold' : 'text-stone-700'} />
        </button>
      </div>

      {/* Map Style Switcher Bottom Left */}
      <div className="absolute bottom-4 left-4 z-20 flex gap-1.5 bg-white p-1 rounded-xl shadow-md border border-stone-100">
        <button
          onClick={() => setMapType('standard')}
          className={`px-3 py-1 text-[10px] uppercase tracking-wider font-bold rounded-lg transition-all ${mapType === 'standard' ? 'bg-brand-green-dark text-white' : 'text-stone-500 hover:bg-stone-100'}`}
        >
          Plan
        </button>
        <button
          onClick={() => setMapType('satellite')}
          className={`px-3 py-1 text-[10px] uppercase tracking-wider font-bold rounded-lg transition-all ${mapType === 'satellite' ? 'bg-brand-green-dark text-white' : 'text-stone-500 hover:bg-stone-100'}`}
        >
          Satellite
        </button>
      </div>

      {/* Primary Map Arena Canvas Container */}
      <div className="relative flex-grow overflow-hidden select-none">
        
        {/* standard Map background representation: styled as a minimal roadmap and water bodies */}
        <div className={`absolute inset-0 transition-opacity duration-300 ${mapType === 'standard' ? 'opacity-100 bg-[#E9E6D5]/20' : 'opacity-0 bg-[#1e293b]'}`}>
          {mapSvgBackground}
        </div>

        {/* Satellite Map background representation */}
        <div className={`absolute inset-0 transition-opacity duration-300 ${mapType === 'satellite' ? 'opacity-100 bg-[#0f172a]' : 'opacity-0 pointer-events-none'}`}>
          <div className="absolute inset-0 bg-cover bg-center brightness-75 scale-102" style={satelliteBgStyle} />
          {/* Custom neon grid Overlay on satellite */}
          <div className="absolute inset-0 bg-[radial-gradient(#ffffff0a_1px,transparent_1px)] [background-size:16px_16px]" />
        </div>

        {/* GPS Geolocation marker pulsing light dot */}
        {showUserLocCode && (
          <div 
            className="absolute z-10 -translate-x-1/2 -translate-y-1/2 transition-all duration-1000"
            style={{ left: `${userLocation.x}%`, top: `${userLocation.y}%` }}
          >
            <span className="absolute flex h-6 w-6 -left-3 -top-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-6 w-6 bg-blue-500 border-2 border-white shadow-md"></span>
            </span>
            <div className="absolute left-4 -top-3.5 bg-brand-green-dark text-white rounded px-1.5 py-0.5 text-[8px] font-sans font-bold uppercase tracking-wider whitespace-nowrap shadow">
              Moi 🧭
            </div>
          </div>
        )}

        {/* Event / Partners pins mapping (optimized with React.memo MapPin component) */}
        {experiences.map((exp) => {
          const isSelected = selectedExperience?.id === exp.id;
          const pinColor = colorMap[exp.category] || 'bg-stone-600';
          
          return (
            <MapPin
              key={exp.id}
              experience={exp}
              isSelected={isSelected}
              pinColor={pinColor}
              onClick={handlePinSelect}
            />
          );
        })}

        {/* Selected Experience Card Bottom Drawer Overlay on Standard layout */}
        {selectedExperience && (
          <div className="absolute bottom-4 left-4 right-4 md:left-24 md:right-24 bg-white/95 backdrop-blur rounded-2xl p-4 shadow-2xl border border-brand-cream max-w-xl mx-auto z-30 animate-slide-up">
            <div className="flex gap-4">
              <div className="w-1/3 aspect-4/3 rounded-lg overflow-hidden relative shrink-0 bg-stone-100">
                <img 
                  src={selectedExperience.image} 
                  alt={selectedExperience.title} 
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <span className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded text-[8px] font-bold text-white bg-brand-green-dark">
                  ★ {selectedExperience.rating.toFixed(1)}
                </span>
              </div>
              <div className="flex-grow flex flex-col justify-between text-left">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] bg-brand-green-dark/10 text-brand-green-dark px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                      {selectedExperience.category}
                    </span>
                    <span className="text-[10px] text-stone-400">🧭 {selectedExperience.distance} km d'ici</span>
                  </div>
                  <h4 className="font-serif font-bold text-xs text-stone-900 mt-1 line-clamp-1">
                    {selectedExperience.title}
                  </h4>
                  <p className="text-stone-500 text-[11px] leading-tight mt-0.5 line-clamp-2">
                    {selectedExperience.description}
                  </p>
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-stone-100">
                  <span className="text-xs font-bold font-serif text-brand-green-dark">
                    Tarif: {selectedExperience.price === 0 ? 'Gratuit' : `${selectedExperience.price}€`}
                  </span>
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => handlePinSelect(selectedExperience)}
                      className="px-3 py-1 bg-brand-green-dark hover:bg-brand-green-med border border-brand-gold text-brand-cream text-[10px] font-bold rounded-lg uppercase tracking-wider transition-colors cursor-pointer"
                    >
                      Détails
                    </button>
                    <button
                      onClick={() => onSelectExperience(selectedExperience)}
                      className="p-1 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded cursor-pointer"
                    >
                      <LucideIcon name="X" size={14} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
