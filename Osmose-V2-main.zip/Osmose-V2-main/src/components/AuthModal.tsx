import React, { useState } from 'react';
import { LucideIcon } from './LucideIcon';
import { auth, loginWithGoogle } from '../firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, sendPasswordResetEmail } from 'firebase/auth';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (role: 'user' | 'partner') => void;
  initialTab?: 'login' | 'signup';
}

export function AuthModal({ isOpen, onClose, onLoginSuccess, initialTab = 'login' }: AuthModalProps) {
  const [tab, setTab] = useState<'login' | 'signup' | 'forgot'>(initialTab);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [agreedTerms, setAgreedTerms] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errMsg, setErrMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrMsg('');
    setSuccessMsg('');

    if (tab === 'login') {
      if (!email || !password) {
        setErrMsg('Veuillez remplir tous les champs.');
        return;
      }
      try {
        await signInWithEmailAndPassword(auth, email, password);
        const isPartner = email.toLowerCase().includes('partner') || email === 'osmoseandco@gmail.com';
        setSuccessMsg('Connexion réussie ! Chargement de votre univers...');
        setTimeout(() => {
          onLoginSuccess(isPartner ? 'partner' : 'user');
          onClose();
          setSuccessMsg('');
        }, 1000);
      } catch (error: any) {
        setErrMsg(error?.message || 'Identifiants invalides ou erreur de connexion.');
      }
    } else if (tab === 'signup') {
      if (!email || !password || !name) {
        setErrMsg('Veuillez remplir tous les champs requis.');
        return;
      }
      if (!agreedTerms) {
        setErrMsg('Veuillez valider les conditions générales.');
        return;
      }
      try {
        await createUserWithEmailAndPassword(auth, email, password);
        setSuccessMsg('Compte créé avec succès ! Bienvenue chez Osmose.');
        setTimeout(() => {
          onLoginSuccess('user');
          onClose();
          setSuccessMsg('');
        }, 1200);
      } catch (error: any) {
        setErrMsg(error?.message || 'Erreur lors de la création du compte.');
      }
    } else {
      if (!email) {
        setErrMsg('Entrez votre adresse mail.');
        return;
      }
      try {
        await sendPasswordResetEmail(auth, email);
        setSuccessMsg('Un e-mail de réinitialisation sécurisé a été envoyé à ' + email);
        setTimeout(() => {
          setTab('login');
          setSuccessMsg('');
        }, 3000);
      } catch (error: any) {
        setErrMsg(error?.message || 'Erreur lors de l\'envoi de l\'e-mail.');
      }
    }
  };

  const handleGoogleSignInClick = async () => {
    setErrMsg('');
    setSuccessMsg('');
    try {
      const user = await loginWithGoogle();
      const userEmail = user?.email || '';
      const isPartner = userEmail.toLowerCase().includes('partner') || userEmail === 'osmoseandco@gmail.com' || userEmail === 'partenaire@osmose.fr';
      setSuccessMsg(`Connexion réussie : ${user?.displayName || userEmail}`);
      setTimeout(() => {
        onLoginSuccess(isPartner ? 'partner' : 'user');
        onClose();
        setSuccessMsg('');
      }, 1000);
    } catch (error: any) {
      setErrMsg(error?.message || 'Erreur de connexion avec Google.');
    }
  };

  const handleDemoSignIn = (role: 'user' | 'partner') => {
    setErrMsg('');
    setSuccessMsg('');
    const demoEmail = role === 'partner' ? 'partenaire@osmose.fr' : 'explorateur@osmose.fr';
    setEmail(demoEmail);
    setPassword('demo1234');
    setName(role === 'partner' ? 'Partenaire Osmose' : 'Aventurier Local');
    
    setSuccessMsg(`Connexion Démo (${role === 'partner' ? 'Pro' : 'Explorateur'}) en cours...`);
    setTimeout(() => {
      onLoginSuccess(role);
      onClose();
      setSuccessMsg('');
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-brand-midnight/65 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl border border-stone-200 animate-scale-in">
        
        {/* Modal Header banner styled with deep emerald and brand gold decoration */}
        <div className="bg-brand-green-dark p-6 text-brand-cream relative">
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-brand-green-med/50 text-white/80 hover:text-white transition-colors"
          >
            <LucideIcon name="X" size={18} />
          </button>
          
          <div className="text-center">
            <span className="font-serif text-2xl font-bold tracking-widest text-[#E9E6D5]">OSMOSE</span>
            <p className="text-[10px] tracking-widest text-brand-gold uppercase mt-0.5">Votre temps, notre priorité.</p>
          </div>
        </div>

        {/* Modal Content */}
        <div className="p-6 sm:p-8">
          
          {/* Tabs */}
          {tab !== 'forgot' && (
            <div className="flex border-b border-stone-100 mb-6">
              <button
                onClick={() => { setTab('login'); setErrMsg(''); }}
                className={`w-1/2 pb-3 text-xs font-bold uppercase tracking-wider text-center border-b-2 transition-colors ${
                  tab === 'login' 
                    ? 'border-brand-gold text-brand-green-dark' 
                    : 'border-transparent text-stone-400 hover:text-stone-600'
                }`}
              >
                Se connecter
              </button>
              <button
                onClick={() => { setTab('signup'); setErrMsg(''); }}
                className={`w-1/2 pb-3 text-xs font-bold uppercase tracking-wider text-center border-b-2 transition-colors ${
                  tab === 'signup' 
                    ? 'border-brand-gold text-brand-green-dark' 
                    : 'border-transparent text-stone-400 hover:text-stone-600'
                }`}
              >
                Créer un compte
              </button>
            </div>
          )}

          {tab === 'forgot' && (
            <div className="mb-4">
              <button 
                onClick={() => setTab('login')}
                className="text-brand-green-dark text-xs font-semibold flex items-center gap-1 hover:underline"
              >
                <LucideIcon name="ChevronLeft" size={16} /> Retour à la connexion
              </button>
              <h3 className="font-serif font-bold text-lg text-brand-green-dark mt-2">Mot de passe oublié</h3>
              <p className="text-stone-500 text-xs mt-1">Saisissez l'adresse e-mail associée à votre compte, nous vous enverrons un lien d'accès.</p>
            </div>
          )}

          {/* Feedback states */}
          {errMsg && (
            <div className="mb-4 p-3 bg-red-50 border-l-4 border-red-500 text-red-700 text-xs rounded-r-lg">
              {errMsg}
            </div>
          )}
          {successMsg && (
            <div className="mb-4 p-3 bg-emerald-50 border-l-4 border-brand-green-med text-brand-green-dark text-xs rounded-r-lg">
              {successMsg}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {tab === 'signup' && (
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-stone-500 mb-1">Nom complet</label>
                <input
                  type="text"
                  placeholder="Jean Dupont"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-stone-200 text-xs focus:ring-2 focus:ring-brand-green-med outline-none transition-all placeholder:text-stone-300"
                  required
                />
              </div>
            )}

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-stone-500 mb-1">E-mail</label>
              <input
                type="email"
                placeholder={tab === 'login' ? "votre@email.com" : "contact@email.com"}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-stone-200 text-xs focus:ring-2 focus:ring-brand-green-med outline-none transition-all placeholder:text-stone-300"
                required
              />
            </div>

            {tab !== 'forgot' && (
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-stone-500">Mot de passe</label>
                  {tab === 'login' && (
                    <button
                      type="button"
                      onClick={() => setTab('forgot')}
                      className="text-[10px] text-brand-green-dark hover:underline font-medium"
                    >
                      Oublié ?
                    </button>
                  )}
                </div>
                <input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-stone-200 text-xs focus:ring-2 focus:ring-brand-green-med outline-none transition-all placeholder:text-stone-300"
                  required
                />
              </div>
            )}

            {tab === 'signup' && (
              <label className="flex items-start gap-2.5 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={agreedTerms}
                  onChange={(e) => setAgreedTerms(e.target.checked)}
                  className="mt-0.5 rounded text-brand-green-med focus:ring-brand-green-med focus:ring-offset-0 border-stone-300"
                />
                <span className="text-[10px] text-stone-500 leading-tight">
                  J'accepte les <span className="text-brand-green-dark underline">Conditions Générales d'Utilisation</span> et la politique de confidentialité de la plateforme.
                </span>
              </label>
            )}

            <button
              type="submit"
              className="w-full py-3.5 mt-2 bg-brand-green-dark hover:bg-brand-green-med text-brand-cream font-sans font-extrabold uppercase tracking-widest text-[11px] rounded-xl shadow-md transition-all duration-300 border border-brand-gold flex items-center justify-center gap-2 cursor-pointer"
            >
              {tab === 'login' && 'Se connecter'}
              {tab === 'signup' && 'Créer mon espace'}
              {tab === 'forgot' && 'Réinitialiser'}
            </button>
          </form>

          {tab !== 'forgot' && (
            <div className="mt-4">
              <div className="relative flex py-2 items-center">
                <div className="flex-grow border-t border-stone-100"></div>
                <span className="flex-shrink mx-4 text-stone-400 text-[10px] uppercase font-bold tracking-wider">ou</span>
                <div className="flex-grow border-t border-stone-100"></div>
              </div>

              <button
                type="button"
                onClick={handleGoogleSignInClick}
                className="w-full py-3 mt-1 bg-white hover:bg-stone-50 text-stone-700 font-sans font-extrabold uppercase tracking-widest text-[11px] rounded-xl shadow-sm border border-stone-200 transition-all flex items-center justify-center gap-2.5 cursor-pointer"
              >
                <LucideIcon name="Sparkles" size={14} className="text-brand-gold" />
                Se connecter avec Google
              </button>
            </div>
          )}

          {/* Quick Demo Bypass (Amazing for templates testing!) */}
          <div className="mt-6 pt-5 border-t border-stone-100 text-center">
            <span className="text-[9px] uppercase tracking-wider font-extrabold text-[#B8860B] bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
              ⚡ Connexion test immédiate
            </span>
            <div className="grid grid-cols-2 gap-2 mt-3">
              <button
                type="button"
                onClick={() => handleDemoSignIn('user')}
                className="py-2.5 border border-stone-200 hover:border-brand-green-med text-stone-700 text-[10px] font-bold uppercase rounded-xl hover:bg-stone-50 transition-all flex flex-col justify-center items-center gap-0.5"
              >
                <span>👤 Explorateur</span>
                <span className="text-[8px] font-normal text-stone-400 capitalize">B2C Expériences</span>
              </button>
              <button
                type="button"
                onClick={() => handleDemoSignIn('partner')}
                className="py-2.5 border border-brand-gold/50 hover:border-brand-green-med text-stone-700 text-[10px] font-bold uppercase rounded-xl hover:bg-stone-50 transition-all flex flex-col justify-center items-center gap-0.5"
              >
                <span>✨ Partenaire Pro</span>
                <span className="text-[8px] font-normal text-brand-green-dark capitalize">B2B Analytics</span>
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
