import { ActivePage } from '../types';
import { LucideIcon } from './LucideIcon';

interface BottomNavProps {
  activePage: ActivePage;
  onNavigate: (page: ActivePage) => void;
  favoritesCount: number;
  unreadCount: number;
}

export function BottomNav({ activePage, onNavigate, favoritesCount, unreadCount }: BottomNavProps) {
  const tabs = [
    { id: 'home', label: 'Accueil', icon: 'Compass' },
    { id: 'explorer', label: 'Explorer', icon: 'Search' },
    { id: 'become-partner', label: 'Partenaire', icon: 'HeartHandshake' },
    { id: 'blog', label: 'Guides', icon: 'Sparkles' },
    { id: 'user-dashboard', label: 'Espace', icon: 'User' },
    { id: 'partner-dashboard', label: 'Pro', icon: 'TrendingUp' }
  ] as const;

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-stone-200/80 px-4 py-2 z-50 shadow-2xl backdrop-blur-lg bg-opacity-95 pb-safe">
      <div className="flex justify-around items-center">
        {tabs.map((tab) => {
          const isActive = activePage === tab.id || (tab.id === 'blog' && activePage === 'article-detail');
          return (
            <button
              key={tab.id}
              onClick={() => onNavigate(tab.id as ActivePage)}
              className="flex flex-col items-center gap-1 py-1 px-3 relative transition-all duration-300 rounded-xl"
            >
              <div
                className={`p-1 rounded-full transition-all duration-300 ${
                  isActive 
                    ? 'text-brand-green-dark scale-110' 
                    : 'text-stone-400 hover:text-stone-600'
                }`}
              >
                <LucideIcon name={tab.icon} size={20} />
                {tab.id === 'user-dashboard' && favoritesCount > 0 && (
                  <span className="absolute top-0 right-2 w-4 h-4 bg-brand-gold text-brand-green-dark text-[9px] font-bold rounded-full flex items-center justify-center border border-white">
                    {favoritesCount}
                  </span>
                )}
                {tab.id === 'home' && unreadCount > 0 && (
                  <span className="absolute top-1 right-3 w-2 h-2 bg-brand-gold rounded-full" />
                )}
              </div>
              <span
                className={`text-[9px] font-medium tracking-tight transition-all duration-300 ${
                  isActive ? 'text-brand-green-dark font-semibold' : 'text-stone-400'
                }`}
              >
                {tab.label}
              </span>
              {isActive && (
                <div className="absolute -bottom-1 w-5 h-1 bg-brand-gold rounded-full" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
