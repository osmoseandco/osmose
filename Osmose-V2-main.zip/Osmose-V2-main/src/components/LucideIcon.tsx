import { 
  Compass, 
  Sparkles, 
  Activity, 
  Utensils, 
  Heart, 
  Layers, 
  ShieldAlert, 
  Calendar, 
  MapPin, 
  Clock, 
  User, 
  CheckCircle, 
  Bell, 
  Mail, 
  Settings, 
  Edit, 
  Trash, 
  Phone, 
  Search, 
  Filter, 
  ChevronRight, 
  ChevronLeft, 
  ArrowRight,
  TrendingUp, 
  Map, 
  List, 
  Share2, 
  Award, 
  DollarSign, 
  Users, 
  Eye, 
  HeartHandshake, 
  Star,
  Check,
  X,
  Plus
} from 'lucide-react';

const iconsMap = {
  Compass,
  Sparkles,
  Activity,
  Utensils,
  Heart,
  Layers,
  ShieldAlert,
  Calendar,
  MapPin,
  Clock,
  User,
  CheckCircle,
  Bell,
  Mail,
  Settings,
  Edit,
  Trash,
  Phone,
  Search,
  Filter,
  ChevronRight,
  ChevronLeft,
  ArrowRight,
  TrendingUp,
  Map,
  List,
  Share2,
  Award,
  DollarSign,
  Users,
  Eye,
  HeartHandshake,
  Star,
  Check,
  X,
  Plus
} as const;

export type IconName = keyof typeof iconsMap;

interface LucideIconProps {
  name: string;
  className?: string;
  size?: number;
}

export function LucideIcon({ name, className, size }: LucideIconProps) {
  // Graceful fallback if icon isn't found
  const IconComponent = iconsMap[name as IconName] || Compass;
  return <IconComponent className={className} size={size} />;
}
