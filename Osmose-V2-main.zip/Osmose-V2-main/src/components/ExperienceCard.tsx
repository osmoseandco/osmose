import React from 'react';
import { Experience, CategoryId } from '../types';
import { LucideIcon } from './LucideIcon';

interface ExperienceCardProps {
  key?: React.Key;
  experience: Experience;
  isFavorited: boolean;
  onToggleFavorite: (e: React.MouseEvent, id: string) => void;
  onClick: (experience: Experience) => void;
}

// Map categories to specific elegant Tailwind colors
const categoryColorMap: Record<CategoryId, { bg: string; text: string; label: string }> = {
  sorties: { bg: 'bg-indigo-50 border-indigo-200', text: 'text-indigo-800', label: 'Sorties & Expériences' },
  insolite: { bg: 'bg-amber-50 border-amber-200', text: 'text-amber-800', label: 'Insolite' },
  sport: { bg: 'bg-sky-50 border-sky-200', text: 'text-sky-800', label: 'Sport' },
  gastronomie: { bg: 'bg-rose-50 border-rose-200', text: 'text-rose-800', label: 'Gastronomie' },
  famille: { bg: 'bg-emerald-50 border-emerald-200', text: 'text-emerald-800', label: 'Famille' },
  bien_etre: { bg: 'bg-teal-50 border-teal-200', text: 'text-teal-800', label: 'Bien-être' },
  sante: { bg: 'bg-cyan-50 border-cyan-200', text: 'text-cyan-800', label: 'Santé & Spécialistes' }
};

export function ExperienceCard({ experience, isFavorited, onToggleFavorite, onClick }: ExperienceCardProps) {
  const catStyle = categoryColorMap[experience.category] || { bg: 'bg-stone-50 border-stone-200', text: 'text-stone-800', label: experience.category };

  return (
    <div 
      onClick={() => onClick(experience)}
      className="group bg-white rounded-2xl border border-stone-100/80 overflow-hidden shadow-sm hover:shadow-[0_20px_25px_-5px_rgba(0,0,0,0.06),0_10px_10px_-5px_rgba(0,0,0,0.03)] hover:-translate-y-2 hover:scale-[1.02] hover:border-brand-gold/40 transition-all duration-300 ease-out flex flex-col h-full cursor-pointer"
    >
      {/* 4:3 Image Container */}
      <div className="relative aspect-4/3 w-full overflow-hidden bg-stone-100">
        <img 
          src={experience.image} 
          alt={experience.title} 
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
        />
        
        {/* Category Floating Badge */}
        <div className="absolute top-3 left-3 z-10">
          <span className={`px-2.5 py-1 text-[9px] font-bold uppercase tracking-wider rounded-full border ${catStyle.bg} ${catStyle.text}`}>
            {catStyle.label}
          </span>
        </div>

        {/* Favorite Trigger Button */}
        <button
          onClick={(e) => onToggleFavorite(e, experience.id)}
          className="absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-white/90 hover:bg-white shadow-md flex items-center justify-center text-stone-600 transition-all hover:scale-110 active:scale-95"
          title={isFavorited ? "Retirer des favoris" : "Ajouter aux favoris"}
        >
          <LucideIcon 
            name="Heart" 
            size={16} 
            className={`${isFavorited ? 'fill-red-500 text-red-500 scale-105' : 'text-stone-600'} transition-all`} 
          />
        </button>

        {/* Price Tag Overlay bottom right */}
        <div className="absolute bottom-3 right-3 bg-brand-green-dark text-white rounded-lg px-2.5 py-1 text-xs font-semibold shadow-md flex items-center border border-brand-gold/30">
          {experience.price === 0 ? (
            <span className="text-brand-cream text-[10px] font-bold uppercase tracking-widest">GRATUIT</span>
          ) : (
            <span>{experience.price} €</span>
          )}
        </div>
      </div>

      {/* Experience Content Footer */}
      <div className="p-4 flex-grow flex flex-col justify-between">
        <div>
          {/* Rating and Distance strip */}
          <div className="flex items-center justify-between text-[11px] text-stone-500 font-medium mb-1.5">
            <div className="flex items-center gap-1">
              <span className="flex items-center text-brand-gold-dark font-bold font-sans">
                ★ <span className="text-stone-700 ml-0.5">{experience.rating.toFixed(1)}</span>
              </span>
              <span className="text-stone-300">•</span>
              <span className="text-stone-600">{experience.reviewsCount} avis</span>
            </div>
            
            {experience.distance && (
              <span className="bg-stone-50 text-stone-600 px-1.5 py-0.5 rounded border border-stone-200">
                🧭 {experience.distance} km
              </span>
            )}
          </div>

          <h3 className="font-serif font-bold text-sm text-stone-900 group-hover:text-brand-green-dark transition-colors duration-200 leading-snug line-clamp-2">
            {experience.title}
          </h3>
          
          <p className="font-sans text-xs text-stone-500 mt-1.5 line-clamp-2">
            {experience.description}
          </p>
        </div>

        {/* Real-time date indicator tag */}
        <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between">
          <span className="text-[10px] text-stone-400 flex items-center gap-1 font-medium">
            <LucideIcon name="MapPin" size={12} className="text-brand-green-med" />
            {experience.location.split(',')[0]}
          </span>
          
          {experience.isToday ? (
            <span className="text-[9px] bg-red-50 border border-red-200 text-red-600 px-2 py-0.5 rounded font-bold uppercase tracking-wider animate-pulse">
              Aujourd'hui
            </span>
          ) : experience.isWeekend ? (
            <span className="text-[9px] bg-indigo-50 border border-indigo-200 text-indigo-600 px-2 py-0.5 rounded font-bold uppercase tracking-wider">
              Ce Week-end
            </span>
          ) : (
            <span className="text-[9px] text-stone-400 font-sans">
              Prochainement
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
