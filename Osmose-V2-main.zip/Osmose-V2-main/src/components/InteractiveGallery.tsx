import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Maximize2, X } from 'lucide-react';

interface InteractiveGalleryProps {
  gallery: string[];
  title: string;
}

export function InteractiveGallery({ gallery, title }: InteractiveGalleryProps) {
  const images = gallery && gallery.length > 0 ? gallery : ['https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80'];
  const [activeIndex, setActiveIndex] = useState<number>(0);
  const [isLightboxOpen, setIsLightboxOpen] = useState<boolean>(false);

  // Reset active index when the gallery changes
  useEffect(() => {
    setActiveIndex(0);
  }, [gallery]);

  // Keyboard navigation for the lightbox
  useEffect(() => {
    if (!isLightboxOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') {
        setActiveIndex((prev) => (prev + 1) % images.length);
      } else if (e.key === 'ArrowLeft') {
        setActiveIndex((prev) => (prev - 1 + images.length) % images.length);
      } else if (e.key === 'Escape') {
        setIsLightboxOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isLightboxOpen, images.length]);

  const handleNext = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setActiveIndex((prev) => (prev + 1) % images.length);
  };

  const handlePrev = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setActiveIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  const openLightbox = () => {
    setIsLightboxOpen(true);
  };

  return (
    <div className="space-y-4 select-none">
      <div className="flex items-center justify-between">
        <h3 className="font-serif font-bold text-base text-brand-green-dark tracking-wide uppercase">
          Galerie de photos interactive
        </h3>
        {images.length > 1 && (
          <span className="text-xs font-mono text-stone-500 font-medium">
            {activeIndex + 1} / {images.length}
          </span>
        )}
      </div>

      {/* 1. MAIN LARGE VISUAL PREVIEW DISPLAY */}
      <div 
        onClick={openLightbox}
        className="group relative aspect-[16/9] w-full rounded-2xl overflow-hidden bg-stone-900 border border-stone-200/80 shadow-sm cursor-pointer"
      >
        <img 
          src={images[activeIndex]} 
          alt={`${title} - Photo ${activeIndex + 1}`} 
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-all duration-700 ease-out group-hover:scale-105"
        />
        
        {/* Subtle vignette gradient overlays */}
        <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-stone-950/40 to-transparent pointer-events-none" />
        <div className="absolute inset-0 bg-stone-950/0 group-hover:bg-stone-950/10 transition-colors duration-300 pointer-events-none" />

        {/* Floating actions */}
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md hover:bg-white text-stone-700 p-2.5 rounded-full shadow border border-white/50 hover:scale-110 transition-all duration-300 opacity-0 group-hover:opacity-100 focus:opacity-100 z-10">
          <Maximize2 size={16} className="text-stone-800" />
        </div>

        {/* Gallery Carousel Controls - Left & Right Arrow overlays (visible if multiple images exist) */}
        {images.length > 1 && (
          <>
            <button
              onClick={handlePrev}
              className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/80 backdrop-blur-md border border-stone-200 flex items-center justify-center text-stone-800 hover:bg-white hover:scale-105 shadow hover:translate-x-0.5 transition-all outline-none"
              title="Image précédente"
            >
              <ChevronLeft size={20} className="stroke-[2.5]" />
            </button>
            <button
              onClick={handleNext}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/80 backdrop-blur-md border border-stone-200 flex items-center justify-center text-stone-800 hover:bg-white hover:scale-105 shadow hover:-translate-x-0.5 transition-all outline-none"
              title="Image suivante"
            >
              <ChevronRight size={20} className="stroke-[2.5]" />
            </button>
          </>
        )}
      </div>

      {/* 2. THUMBNAILS CAROUSEL */}
      {images.length > 1 && (
        <div className="flex gap-2.5 overflow-x-auto pb-1.5 pt-0.5 scrollbar-thin scrollbar-thumb-stone-300 scrollbar-track-transparent">
          {images.map((img, idx) => (
            <button
              key={idx}
              onClick={() => setActiveIndex(idx)}
              className={`relative aspect-[4/3] w-20 sm:w-24 shrink-0 rounded-xl overflow-hidden border-2 bg-stone-100 transition-all duration-300 ${
                idx === activeIndex
                  ? 'border-brand-gold ring-2 ring-brand-gold/30 scale-98 md:scale-95 shadow'
                  : 'border-transparent opacity-65 hover:opacity-100 hover:scale-102 hover:border-stone-200'
              }`}
            >
              <img 
                src={img} 
                alt={`${title} miniature ${idx + 1}`} 
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              {idx === activeIndex && (
                <div className="absolute inset-0 bg-brand-gold/10" />
              )}
            </button>
          ))}
        </div>
      )}

      {/* 3. LIGHTBOX MODAL PORTAL / FIXED LAYOUT */}
      {isLightboxOpen && (
        <div 
          className="fixed inset-0 z-50 bg-stone-950/95 backdrop-blur-lg flex flex-col justify-between p-4 sm:p-6 md:p-8 animate-fade-in"
          onClick={() => setIsLightboxOpen(false)}
        >
          {/* Header */}
          <div className="flex items-center justify-between w-full text-white pb-3 border-b border-white/10" onClick={(e) => e.stopPropagation()}>
            <div className="space-y-0.5">
              <span className="text-[10px] font-sans font-bold uppercase tracking-widest text-brand-gold">
                Galerie immersive
              </span>
              <p className="font-serif text-sm sm:text-base font-bold text-stone-100 truncate max-w-sm sm:max-w-xl">
                {title}
              </p>
            </div>
            
            <div className="flex items-center gap-4">
              <span className="text-xs sm:text-sm font-mono text-stone-400">
                {activeIndex + 1} / {images.length}
              </span>
              <button 
                onClick={() => setIsLightboxOpen(false)}
                className="w-9 h-9 flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer border border-white/10"
                title="Fermer (Échap)"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          {/* Central content - Lightbox interactive view */}
          <div 
            className="relative flex items-center justify-center flex-1 max-w-full w-full py-4"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Image display */}
            <div className="relative max-h-[70vh] max-w-full md:max-w-4xl lg:max-w-5xl rounded-2xl overflow-hidden border border-white/5 bg-stone-950 shadow-2xl">
              <img 
                src={images[activeIndex]} 
                alt={`${title} - Vue grand format ${activeIndex + 1}`} 
                referrerPolicy="no-referrer"
                className="max-h-[70vh] object-contain w-auto h-auto mx-auto select-none"
              />
            </div>

            {/* Overlaid Lightbox Navigation Arrows */}
            {images.length > 1 && (
              <>
                <button
                  onClick={handlePrev}
                  className="absolute left-2 md:left-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 hover:scale-105 border border-white/15 hover:border-white/30 flex items-center justify-center text-white transition-all duration-200 outline-none shadow-lg"
                  title="Image précédente (←)"
                >
                  <ChevronLeft size={24} className="stroke-[2.5]" />
                </button>
                <button
                  onClick={handleNext}
                  className="absolute right-2 md:right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 hover:scale-105 border border-white/15 hover:border-white/30 flex items-center justify-center text-white transition-all duration-200 outline-none shadow-lg"
                  title="Image suivante (→)"
                >
                  <ChevronRight size={24} className="stroke-[2.5]" />
                </button>
              </>
            )}
          </div>

          {/* Footer - Mini-Indicator dots selection */}
          <div 
            className="flex flex-col items-center gap-3 pt-3 border-t border-white/10"
            onClick={(e) => e.stopPropagation()}
          >
            {images.length > 1 && (
              <div className="flex gap-2">
                {images.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveIndex(idx)}
                    className={`h-2 rounded-full transition-all duration-350 ease-out ${
                      idx === activeIndex
                        ? 'w-7 bg-brand-gold'
                        : 'w-2 bg-stone-600 hover:bg-stone-400'
                    }`}
                    title={`Aller à la photo ${idx + 1}`}
                  />
                ))}
              </div>
            )}
            <span className="text-[10px] text-stone-500 font-sans tracking-wide">
              Utilisez les flèches ← et → de votre clavier pour naviguer
            </span>
          </div>

        </div>
      )}
    </div>
  );
}
