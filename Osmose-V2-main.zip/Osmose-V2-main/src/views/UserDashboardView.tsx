import React, { useState } from 'react';
import { Booking, Experience, UserNotification } from '../types';
import { LucideIcon } from '../components/LucideIcon';
import { ExperienceCard } from '../components/ExperienceCard';

interface UserDashboardViewProps {
  bookings: Booking[];
  onCancelBooking: (bookingId: string) => void;
  favorites: Experience[];
  favoritesIds: string[];
  onToggleFavorite: (e: React.MouseEvent, id: string) => void;
  onSelectExperience: (experience: Experience) => void;
  notifications: UserNotification[];
  onMarkAllNotificationsRead: () => void;
}

export function UserDashboardView({
  bookings,
  onCancelBooking,
  favorites,
  favoritesIds,
  onToggleFavorite,
  onSelectExperience,
  notifications,
  onMarkAllNotificationsRead
}: UserDashboardViewProps) {
  const [activeTab, setActiveTab] = useState<'bookings' | 'wishlist' | 'settings' | 'notifications'>('bookings');
  
  // Local preferences checklist states
  const [prefSorties, setPrefSorties] = useState(true);
  const [prefInsolite, setPrefInsolite] = useState(true);
  const [prefSport, setPrefSport] = useState(false);
  const [prefBienEtre, setPrefBienEtre] = useState(true);
  
  const [notifEmail, setNotifEmail] = useState(true);
  const [notifSMS, setNotifSMS] = useState(false);

  // Success preferences saving notification
  const [showConfigSaved, setShowConfigSaved] = useState(false);

  const handleSavePreferences = (e: React.FormEvent) => {
    e.preventDefault();
    setShowConfigSaved(true);
    setTimeout(() => {
      setShowConfigSaved(false);
    }, 2000);
  };

  const pendingCount = bookings.filter(b => b.status === 'upcoming').length;

  return (
    <div className="min-h-screen pb-32">
      
      {/* 1. TOP PREMIUM PROFILE BAR */}
      <section className="bg-gradient-to-r from-brand-green-dark to-brand-green-med text-[#E9E6D5] py-12 px-4 shadow-inner relative overflow-hidden select-none">
        <div className="absolute inset-0 bg-[radial-gradient(#ffffff04_1px,transparent_1px)] [background-size:16px_16px]" />
        
        <div className="relative z-10 max-w-7xl mx-auto flex flex-col md:flex-row gap-6 items-center justify-between">
          <div className="flex items-center gap-4 text-left">
            <div className="w-16 h-16 rounded-full bg-[#E9E6D5] border-2 border-brand-gold flex items-center justify-center text-brand-green-dark font-serif font-extrabold text-2xl shadow-md">
              M
            </div>
            <div>
              <span className="text-[9px] uppercase tracking-widest font-extrabold text-brand-gold block">PANEL CLIENT</span>
              <h1 className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-white leading-none">
                osmoseandco@gmail.com
              </h1>
              <p className="text-[10px] text-stone-200 mt-0.5">Membre Explorateur • Compte vérifié ✅</p>
            </div>
          </div>

          {/* Core quick counters */}
          <div className="flex gap-4 text-center">
            <div className="bg-white/10 border border-white/10 px-4 py-2.5 rounded-2xl min-w-[100px]">
              <span className="block text-2xl font-sans font-bold text-white">{pendingCount}</span>
              <span className="text-[8px] uppercase tracking-wider text-brand-gold font-bold">Réservations</span>
            </div>
            <div className="bg-white/10 border border-white/10 px-4 py-2.5 rounded-2xl min-w-[100px]">
              <span className="block text-2xl font-sans font-bold text-white">{favorites.length}</span>
              <span className="text-[8px] uppercase tracking-wider text-brand-gold font-bold">Favoris</span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. SUB NAVIGATION CONTROL SWITCH TABS */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 grid grid-cols-1 lg:grid-cols-12 gap-8 text-left">
        
        {/* Navigation layout list */}
        <div className="lg:col-span-3 space-y-4">
          <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-sm divide-y divide-stone-100 flex flex-col">
            
            <button
              onClick={() => setActiveTab('bookings')}
              className={`w-full text-left py-3 px-3 text-xs font-bold uppercase tracking-wider rounded-xl transition-all flex items-center justify-between ${
                activeTab === 'bookings' 
                  ? 'bg-brand-green-dark text-[#E9E6D5] font-semibold' 
                  : 'text-stone-500 hover:bg-stone-50 hover:text-stone-700'
              }`}
            >
              <span className="flex items-center gap-2">
                <LucideIcon name="Calendar" size={14} /> Mes Réservations
              </span>
              {pendingCount > 0 && (
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${activeTab === 'bookings' ? 'bg-brand-gold text-brand-green-dark' : 'bg-brand-green-dark/10 text-brand-green-dark'}`}>
                  {pendingCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('wishlist')}
              className={`w-full text-left py-3 px-3 text-xs font-bold uppercase tracking-wider rounded-xl transition-all flex items-center justify-between ${
                activeTab === 'wishlist' 
                  ? 'bg-brand-green-dark text-[#E9E6D5] font-semibold' 
                  : 'text-stone-500 hover:bg-stone-50 hover:text-stone-700'
              }`}
            >
              <span className="flex items-center gap-2">
                <LucideIcon name="Heart" size={14} /> Ma Liste d'Envies
              </span>
              {favorites.length > 0 && (
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${activeTab === 'wishlist' ? 'bg-brand-gold text-brand-green-dark' : 'bg-brand-green-dark/10 text-brand-green-dark'}`}>
                  {favorites.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('notifications')}
              className={`w-full text-left py-3 px-3 text-xs font-bold uppercase tracking-wider rounded-xl transition-all flex items-center justify-between ${
                activeTab === 'notifications' 
                  ? 'bg-brand-green-dark text-[#E9E6D5] font-semibold' 
                  : 'text-stone-500 hover:bg-stone-50 hover:text-stone-700'
              }`}
            >
              <span className="flex items-center gap-2">
                <LucideIcon name="Bell" size={14} /> Messages & Alertes
              </span>
              {notifications.filter(n => !n.read).length > 0 && (
                <span className="w-2 h-2 rounded-full bg-brand-gold" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`w-full text-left py-3 px-3 text-xs font-bold uppercase tracking-wider rounded-xl transition-all flex items-center gap-2 ${
                activeTab === 'settings' 
                  ? 'bg-brand-green-dark text-[#E9E6D5] font-semibold' 
                  : 'text-stone-500 hover:bg-stone-50 hover:text-stone-700'
              }`}
            >
              <LucideIcon name="Settings" size={14} /> Préférences Profil
            </button>

          </div>
        </div>

        {/* ACTIVE CORES PANELS VIEWPORTS */}
        <div className="lg:col-span-9 bg-white border border-stone-200/80 rounded-3xl p-6 md:p-8 shadow-sm">
          
          {/* TAB 1: BOOKINGS STREAM */}
          {activeTab === 'bookings' && (
            <div className="space-y-6 animate-fade-in text-left">
              <div className="pb-4 border-b border-stone-100 flex justify-between items-center">
                <h3 className="font-serif font-extrabold text-sm uppercase tracking-wider text-stone-900">
                  Mes billets d'activités
                </h3>
                <span className="text-[10px] text-stone-400 font-medium">B2C Sécurisé</span>
              </div>

              {bookings.length === 0 ? (
                <div className="py-12 text-center space-y-4">
                  <div className="w-16 h-16 bg-stone-50 rounded-full flex items-center justify-center mx-auto text-stone-350">
                    <LucideIcon name="Calendar" size={28} />
                  </div>
                  <div className="max-w-xs mx-auto space-y-1">
                    <h4 className="font-serif font-bold text-xs text-stone-700">Aucun billet réservé</h4>
                    <p className="text-xs text-stone-500 leading-normal">
                      Vos réservations en attente ou confirmées s'afficheront ici de manière structurée.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  {bookings.map((booking) => (
                    <div 
                      key={booking.id}
                      className="border border-stone-200 rounded-3xl overflow-hidden shadow-sm grid grid-cols-1 md:grid-cols-12 hover:shadow-md transition-shadow"
                    >
                      {/* Image block thumbnail */}
                      <div className="md:col-span-3 h-44 md:h-full relative overflow-hidden bg-stone-100">
                        <img 
                          src={booking.experienceImage} 
                          alt={booking.experienceTitle} 
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                        <span className="absolute top-2 left-2 bg-brand-green-dark text-[#E9E6D5] font-sans font-bold text-[9px] uppercase tracking-wider px-2 py-0.5 rounded-full">
                          En attente ⌛
                        </span>
                      </div>

                      {/* Code Metadata and Core ticket receipts details */}
                      <div className="md:col-span-6 p-5 flex flex-col justify-between">
                        <div>
                          <div className="flex items-center gap-2 mb-1.5">
                            <img 
                              src={booking.partnerLogo} 
                              alt={booking.partnerName} 
                              referrerPolicy="no-referrer" 
                              className="w-5 h-5 rounded-full object-cover border border-brand-gold/50"
                            />
                            <span className="text-[10px] text-brand-gold-dark font-sans font-bold uppercase tracking-wider">
                              {booking.partnerName}
                            </span>
                          </div>

                          <h4 className="font-serif font-bold text-sm text-stone-900 leading-snug">
                            {booking.experienceTitle}
                          </h4>

                          <div className="flex gap-4 text-[11px] text-stone-500 mt-3 font-semibold font-sans uppercase tracking-wider">
                            <div>
                              <span className="block text-[8px] text-stone-400 tracking-widest uppercase">📅 DATE :</span>
                              <span className="text-stone-700">{booking.date}</span>
                            </div>
                            <div className="border-l border-stone-200 pl-4">
                              <span className="block text-[8px] text-stone-400 tracking-widest uppercase">👤 PLACES :</span>
                              <span className="text-stone-700">{booking.ticketsCount} voyageur(s)</span>
                            </div>
                          </div>
                        </div>

                        <div className="pt-4 border-t border-stone-100 flex items-center justify-between mt-4">
                          <span className="text-xs font-bold text-brand-green-dark font-serif uppercase tracking-wider">
                            RÉGLÉ : {booking.price === 0 ? 'Gratuit' : `${booking.price} €`}
                          </span>
                          
                          <button
                            onClick={() => onCancelBooking(booking.id)}
                            className="text-[9px] font-bold text-red-600 hover:text-red-700 hover:underline px-2 py-1 bg-red-50 hover:bg-red-100/50 rounded uppercase tracking-wider transition-colors"
                          >
                            Annuler ma réservation
                          </button>
                        </div>
                      </div>

                      {/* Interactive Visual QR core pass block rendering */}
                      <div className="md:col-span-3 bg-stone-50/50 border-t md:border-t-0 md:border-l border-stone-100 p-5 flex flex-col items-center justify-center gap-2">
                        <div className="w-20 h-20 bg-white border border-stone-200 p-1 rounded-lg">
                          <div className="grid grid-cols-4 gap-1.5 w-full h-full opacity-70">
                            {Array.from({ length: 16 }).map((_, i) => (
                              <div 
                                key={i} 
                                className={`rounded-sm ${(i % 4 === 0 || i % 6 === 0 || i < 4 || i > 12) ? 'bg-stone-800' : 'bg-transparent'}`} 
                              />
                            ))}
                          </div>
                        </div>
                        <span className="font-mono text-[9px] text-stone-400 font-bold uppercase">
                          {booking.id}
                        </span>
                      </div>

                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: MY WISHLIST FAVORITES */}
          {activeTab === 'wishlist' && (
            <div className="space-y-6 animate-fade-in text-left">
              <div className="pb-4 border-b border-stone-100 flex justify-between items-center">
                <h3 className="font-serif font-extrabold text-sm uppercase tracking-wider text-stone-900">
                  Mes favoris de coeur ({favorites.length})
                </h3>
              </div>

              {favorites.length === 0 ? (
                <div className="py-12 text-center space-y-4">
                  <div className="w-16 h-16 bg-stone-50 rounded-full flex items-center justify-center mx-auto text-stone-350">
                    <LucideIcon name="Heart" size={28} />
                  </div>
                  <div className="max-w-xs mx-auto space-y-1">
                    <h4 className="font-serif font-bold text-xs text-stone-700">Aucune annonce sauvegardée</h4>
                    <p className="text-xs text-stone-500 leading-normal">
                      Cliquez sur l'icône de cœur de n'importe quelle expérience pour la retrouver directement sur cet écran.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {favorites.map((exp) => (
                    <ExperienceCard
                      key={exp.id}
                      experience={exp}
                      isFavorited={favoritesIds.includes(exp.id)}
                      onToggleFavorite={onToggleFavorite}
                      onClick={onSelectExperience}
                    />
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: NOTIFICATION STREAM LOG */}
          {activeTab === 'notifications' && (
            <div className="space-y-6 animate-fade-in text-left">
              <div className="pb-4 border-b border-stone-100 flex justify-between items-center">
                <h3 className="font-serif font-extrabold text-sm uppercase tracking-wider text-stone-900">
                  Boîte de réception
                </h3>
                
                {notifications.some(n => !n.read) && (
                  <button 
                    onClick={onMarkAllNotificationsRead}
                    className="text-[9px] font-bold uppercase tracking-wider text-brand-green-med hover:text-brand-green-dark hover:underline"
                  >
                    Tout marquer comme lu 🔓
                  </button>
                )}
              </div>

              <div className="space-y-3 divide-y divide-stone-100">
                {notifications.length === 0 ? (
                  <p className="text-xs text-stone-400 py-6 text-center">Aucune notification.</p>
                ) : (
                  notifications.map((n) => (
                    <div key={n.id} className={`py-4 transition-all flex gap-3.5 items-start ${!n.read ? 'bg-emerald-50/10 px-3 rounded-2xl border-l-4 border-brand-green-med' : ''}`}>
                      <div className="w-7 h-7 rounded-full bg-[#E9E6D5]/40 text-brand-green-dark flex items-center justify-center shrink-0">
                        <LucideIcon name={n.title.includes('Réservation') ? 'CheckCircle' : 'Mail'} size={12} />
                      </div>
                      <div className="space-y-1 flex-grow">
                        <div className="flex justify-between items-baseline">
                          <h4 className="text-xs font-bold text-stone-800">{n.title}</h4>
                          <span className="text-[9px] text-stone-400">{n.date}</span>
                        </div>
                        <p className="text-xs text-stone-600 leading-normal font-sans font-light">{n.message}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 4: PREFERENCES PROFIL FORM */}
          {activeTab === 'settings' && (
            <form onSubmit={handleSavePreferences} className="space-y-8 animate-fade-in text-left">
              <div className="pb-4 border-b border-stone-100 flex justify-between items-center">
                <h3 className="font-serif font-extrabold text-sm uppercase tracking-wider text-stone-900">
                  Ajuster mes préférences d'éveil
                </h3>
                {showConfigSaved && (
                  <span className="text-[9px] bg-brand-green-dark text-white px-2 py-0.5 rounded font-bold uppercase tracking-wider animate-bounce">
                    ✓ Enregistré !
                  </span>
                )}
              </div>

              {/* Spheres preferences checklists */}
              <div className="space-y-4">
                <h4 className="text-[10px] font-extrabold tracking-widest text-[#B8860B] uppercase">I. SPHÈRES D’INTÉRÊTS ÉLUS</h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <label className="flex items-center gap-3 p-3 border border-stone-200 rounded-2xl cursor-pointer hover:bg-stone-50 transition-colors">
                    <input 
                      type="checkbox" 
                      checked={prefSorties}
                      onChange={(e) => setPrefSorties(e.target.checked)}
                      className="rounded text-brand-green-med focus:ring-brand-green-med"
                    />
                    <div>
                      <span className="block text-xs font-bold text-stone-800">Culture & Spectacles</span>
                      <p className="text-[9px] text-stone-400 capitalize">Sorties théâtrales & expos</p>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 p-3 border border-stone-200 rounded-2xl cursor-pointer hover:bg-stone-50 transition-colors">
                    <input 
                      type="checkbox" 
                      checked={prefInsolite}
                      onChange={(e) => setPrefInsolite(e.target.checked)}
                      className="rounded text-brand-green-med focus:ring-brand-green-med"
                    />
                    <div>
                      <span className="block text-xs font-bold text-stone-800">Nuits & Lieux Insolites</span>
                      <p className="text-[9px] text-stone-400 capitalize">Bulle céleste, cabanes secrètes</p>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 p-3 border border-stone-200 rounded-2xl cursor-pointer hover:bg-stone-50 transition-colors">
                    <input 
                      type="checkbox" 
                      checked={prefBienEtre}
                      onChange={(e) => setPrefBienEtre(e.target.checked)}
                      className="rounded text-brand-green-med focus:ring-brand-green-med"
                    />
                    <div>
                      <span className="block text-xs font-bold text-stone-800">Massages & Sonothérapie</span>
                      <p className="text-[9px] text-stone-400 capitalize">Bains de gong, relaxation</p>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 p-3 border border-stone-200 rounded-2xl cursor-pointer hover:bg-stone-50 transition-colors">
                    <input 
                      type="checkbox" 
                      checked={prefSport}
                      onChange={(e) => setPrefSport(e.target.checked)}
                      className="rounded text-brand-green-med focus:ring-brand-green-med"
                    />
                    <div>
                      <span className="block text-xs font-bold text-stone-800">Sensations Extérieures (Sport)</span>
                      <p className="text-[9px] text-stone-400 capitalize">Trekking de calanques, escalades</p>
                    </div>
                  </label>
                </div>
              </div>

              {/* Channel Alerts preferences */}
              <div className="space-y-4 pt-4 border-t border-stone-100">
                <h4 className="text-[10px] font-extrabold tracking-widest text-[#B8860B] uppercase">II. CANAUX DE SYNCHRONISATION</h4>
                
                <div className="flex gap-6">
                  <label className="flex items-start gap-2 cursor-pointer select-none">
                    <input 
                      type="checkbox" 
                      checked={notifEmail}
                      onChange={(e) => setNotifEmail(e.target.checked)}
                      className="rounded text-brand-green-med focus:ring-brand-green-med"
                    />
                    <div className="-mt-1">
                      <span className="text-xs font-semibold text-stone-700">Rapports & Factures Email</span>
                      <p className="text-[9px] text-stone-400">Reçu PDF immédiat après réservations</p>
                    </div>
                  </label>

                  <label className="flex items-start gap-2 cursor-pointer select-none">
                    <input 
                      type="checkbox" 
                      checked={notifSMS}
                      onChange={(e) => setNotifSMS(e.target.checked)}
                      className="rounded text-brand-green-med focus:ring-brand-green-med"
                    />
                    <div className="-mt-1">
                      <span className="text-xs font-semibold text-stone-700">Notifications SMS</span>
                      <p className="text-[9px] text-stone-400">Rappels 2h avant le début d'activité</p>
                    </div>
                  </label>
                </div>
              </div>

              <div className="pt-4 border-t border-stone-100">
                <button
                  type="submit"
                  className="px-6 py-3 bg-brand-green-dark hover:bg-brand-green-med text-brand-cream border border-brand-gold rounded-xl text-xs font-bold uppercase tracking-widest transition-all cursor-pointer"
                >
                  Sauvegarder mes préférences
                </button>
              </div>
            </form>
          )}

        </div>

      </div>

    </div>
  );
}
