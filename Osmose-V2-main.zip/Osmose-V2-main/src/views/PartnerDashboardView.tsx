import React, { useState } from 'react';
import { Experience, CategoryId } from '../types';
import { LucideIcon } from '../components/LucideIcon';

interface PartnerDashboardViewProps {
  onAddExperience: (experience: Experience) => void;
  experiencesCount: number;
}

export function PartnerDashboardView({ onAddExperience, experiencesCount }: PartnerDashboardViewProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'add-event'>('overview');
  
  // New experience form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('45');
  const [city, setCity] = useState<'Paris' | 'Lyon' | 'Marseille' | 'Bordeaux' | 'Nantes' | 'Lille'>('Paris');
  const [category, setCategory] = useState<CategoryId>('gastronomie');
  const [isToday, setIsToday] = useState(false);
  const [isWeekend, setIsWeekend] = useState(true);
  const [success, setSuccess] = useState(false);

  const handleCreateListing = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description) return;

    const newExp: Experience = {
      id: `e-${Date.now()}`,
      title,
      description,
      longDescription: description,
      image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80', // Default gorgeous partner generic view
      gallery: ['https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80'],
      location: `Notre Atelier, ${city}`,
      city,
      price: Number(price) || 0,
      isFree: Number(price) === 0,
      category,
      rating: 5.0,
      reviewsCount: 1,
      distance: 1.5,
      date: '2026-05-25',
      isToday,
      isWeekend,
      isRecommended: true,
      partnerId: 'p1', // associated to circle of osmose
      coordinates: { x: 30 + Math.random() * 40, y: 30 + Math.random() * 40 } // random coords around paris/lyon on map canvas
    };

    onAddExperience(newExp);
    
    // reset form
    setTitle('');
    setDescription('');
    setPrice('45');
    setSuccess(true);

    setTimeout(() => {
      setSuccess(false);
      setActiveTab('overview');
    }, 2000);
  };

  const salesHistory = [
    { id: 'tx-8809', client: 'Aurélie Martin', activity: 'Dîner Immersif & Théâtre', date: 'Aujourd\'hui, 10:15', amount: '85 €', status: 'Payé' },
    { id: 'tx-8808', client: 'Marc Dubois', activity: 'Exposition Privée Street Art', date: 'Hier, 16:30', amount: '50 €', status: 'Payé' },
    { id: 'tx-8807', client: 'Sophie Viret', activity: 'Bain Sonore Gongs Sacrés', date: '21 Mai, 11:20', amount: '70 €', status: 'Payé' }
  ];

  return (
    <div className="min-h-screen pb-32">
      
      {/* 1. TOP PRO BANNER */}
      <section className="bg-brand-midnight text-[#E9E6D5] py-12 px-4 shadow-xl relative overflow-hidden select-none">
        <div className="absolute inset-0 bg-[radial-gradient(#ffffff04_1px,transparent_1px)] [background-size:16px_16px]" />
        
        <div className="relative z-10 max-w-7xl mx-auto flex flex-col md:flex-row gap-6 items-center justify-between">
          <div className="flex items-center gap-4 text-left">
            <div className="w-16 h-16 rounded-3xl bg-brand-green-dark border-2 border-brand-gold flex items-center justify-center text-brand-cream font-serif font-extrabold text-2xl shadow-lg">
              ✨
            </div>
            <div>
              <span className="text-[9px] uppercase tracking-widest font-extrabold text-brand-gold bg-white/10 px-2.5 py-0.5 rounded-full border border-brand-gold/25 block w-fit">
                COMPTE PREMIUM PRO
              </span>
              <h1 className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-[#E9E6D5] leading-none mt-1.5">
                Le Cercle de l'Osmose
              </h1>
              <p className="text-[10px] text-stone-300 mt-1">Espace Administratif Partenaire • Abonnement Actif (99€ HT)</p>
            </div>
          </div>

          <div className="flex gap-4">
            <button
              onClick={() => setActiveTab('add-event')}
              className="px-4 py-2.5 bg-brand-green-dark hover:bg-brand-green-med border border-brand-gold text-brand-cream text-xs font-sans font-bold uppercase tracking-widest rounded-xl shadow-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <LucideIcon name="Plus" size={12} /> Placer une offre
            </button>
          </div>
        </div>
      </section>

      {/* 2. TABBED SUB-PANELS */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 grid grid-cols-1 lg:grid-cols-12 gap-8 text-left select-none">
        
        {/* Navigation panel switches */}
        <div className="lg:col-span-3">
          <div className="bg-white border border-stone-200 rounded-2xl p-4 shadow-sm flex flex-col gap-1">
            <button
              onClick={() => setActiveTab('overview')}
              className={`w-full text-left py-3 px-3 text-xs font-bold uppercase tracking-wider rounded-xl transition-all flex items-center gap-2 ${
                activeTab === 'overview' 
                  ? 'bg-brand-green-dark text-brand-cream font-semibold shadow-md' 
                  : 'text-stone-500 hover:bg-stone-50'
              }`}
            >
              <LucideIcon name="TrendingUp" size={14} /> Vue d'Ensemble
            </button>

            <button
              onClick={() => setActiveTab('add-event')}
              className={`w-full text-left py-3 px-3 text-xs font-bold uppercase tracking-wider rounded-xl transition-all flex items-center gap-2 ${
                activeTab === 'add-event' 
                  ? 'bg-brand-green-dark text-brand-cream font-semibold shadow-md' 
                  : 'text-stone-500 hover:bg-stone-50'
              }`}
            >
              <LucideIcon name="Plus" size={14} /> Créer une Expérience
            </button>
          </div>
        </div>

        {/* ACTIVE MAIN VIEWPORTS */}
        <div className="lg:col-span-9 space-y-8 bg-white border border-stone-200/80 rounded-3xl p-6 md:p-8 shadow-sm">
          
          {/* TAB 1: OVERVIEW METRICS */}
          {activeTab === 'overview' && (
            <div className="space-y-8 animate-fade-in text-left">
              
              <div className="pb-4 border-b border-stone-100 flex justify-between items-center">
                <h3 className="font-serif font-extrabold text-sm uppercase tracking-wider text-stone-900">
                  Performances Administratives
                </h3>
                <span className="text-[10px] text-stone-400 font-medium">B2B SYNCHRONISÉ</span>
              </div>

              {/* SAAS METRICS BLOCKS */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 border border-stone-150 rounded-2xl bg-stone-50 space-y-1">
                  <span className="text-[9px] font-bold uppercase tracking-wider text-brand-green-dark">CA Mensuel net</span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-xl font-extrabold font-sans text-stone-900">4 250 €</span>
                    <span className="text-[9px] text-emerald-600 font-bold">+18%</span>
                  </div>
                </div>

                <div className="p-4 border border-stone-150 rounded-2xl bg-stone-50 space-y-1">
                  <span className="text-[9px] font-bold uppercase tracking-wider text-brand-green-dark">Vues Annonces</span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-xl font-extrabold font-sans text-stone-900">1 842</span>
                    <span className="text-[9px] text-emerald-600 font-bold">+24%</span>
                  </div>
                </div>

                <div className="p-4 border border-stone-150 rounded-2xl bg-stone-50 space-y-1">
                  <span className="text-[9px] font-bold uppercase tracking-wider text-brand-green-dark">Places réservées</span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-xl font-extrabold font-sans text-stone-900">38</span>
                    <span className="text-[9px] text-stone-400 font-bold"> stable</span>
                  </div>
                </div>

                <div className="p-4 border border-stone-150 rounded-2xl bg-stone-50 space-y-1">
                  <span className="text-[9px] font-bold uppercase tracking-wider text-brand-green-dark">Taux Conversion</span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-xl font-extrabold font-sans text-stone-900">4.82 %</span>
                    <span className="text-[9px] text-emerald-600 font-bold">+0.5%</span>
                  </div>
                </div>
              </div>

              {/* ACTIVE LISTINGS STATS */}
              <div className="p-5 border border-amber-200 bg-amber-50/40 rounded-2xl flex flex-col sm:flex-row gap-5 justify-between items-center">
                <div className="space-y-1">
                  <span className="text-[8px] font-extrabold uppercase tracking-widest text-brand-gold bg-white border border-brand-gold/30 rounded px-2 py-0.5">
                    RECRUTEMENT SPONSORISÉ
                  </span>
                  <h4 className="font-serif font-bold text-xs text-brand-green-dark">
                    Votre visibilité Premium Osmose est active.
                  </h4>
                  <p className="text-[10px] text-stone-500 leading-snug">
                    Grâce à votre abonnement PREMIUM, vos <strong>{experiencesCount} offres actives</strong> apparaissent systématiquement en surbrillance dorée sur les cartes d'exploration de votre zone.
                  </p>
                </div>
                <div className="flex-shrink-0">
                  <button 
                    onClick={() => setActiveTab('add-event')}
                    className="px-4 py-2 bg-brand-green-dark hover:bg-brand-green-med text-brand-cream border border-brand-gold rounded-xl font-bold text-[10px] uppercase tracking-widest cursor-pointer"
                  >
                    Ajouter une annonce
                  </button>
                </div>
              </div>

              {/* BOOKINGS HISTORY AND CHARTS */}
              <div className="space-y-4">
                <h4 className="font-serif text-xs font-bold text-stone-900 uppercase tracking-widest">
                  DERNIÈRES RÉSERVATIONS ENREGISTRÉES
                </h4>
                
                <div className="border border-stone-200 rounded-2xl overflow-hidden divide-y divide-stone-100">
                  {salesHistory.map((sh) => (
                    <div key={sh.id} className="p-4 hover:bg-stone-50 transition-colors flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                      <div className="space-y-1">
                        <div className="flex gap-2 items-center">
                          <span className="font-semibold text-xs text-stone-900">{sh.client}</span>
                          <span className="text-[9px] text-stone-400 font-mono">ID: {sh.id}</span>
                        </div>
                        <p className="text-xs text-stone-500">{sh.activity} • <span className="text-[10px] italic">{sh.date}</span></p>
                      </div>

                      <div className="flex justify-between sm:justify-end items-center gap-4">
                        <span className="font-extrabold text-xs text-brand-green-dark font-mono">{sh.amount}</span>
                        <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-700 text-[9px] font-bold uppercase tracking-wider rounded-full border border-emerald-200">
                          {sh.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: ADD EVENT LISTING MANAGER FORM */}
          {activeTab === 'add-event' && (
            <div className="space-y-6 animate-fade-in text-left">
              
              <div className="pb-4 border-b border-stone-100 flex justify-between items-center">
                <h3 className="font-serif font-extrabold text-sm uppercase tracking-wider text-stone-900">
                  Créer une nouvelle annonce d'activité
                </h3>
                <span className="text-[10px] text-stone-400 font-medium font-sans">EVALUATION DU DOSSIER IMMÉDIATE</span>
              </div>

              {success ? (
                <div className="text-center py-12 space-y-4 animate-scale-in">
                  <div className="w-16 h-16 bg-emerald-50 border-2 border-brand-green-med rounded-full flex items-center justify-center mx-auto text-brand-green-dark">
                    <LucideIcon name="CheckCircle" size={32} />
                  </div>
                  <div>
                    <h4 className="font-serif font-bold text-[#0E5B50] text-sm uppercase tracking-wide">
                      ANNONCE CRÉÉE ET VALIDÉE !
                    </h4>
                    <p className="text-xs text-stone-500 max-w-sm mx-auto mt-1">
                      Votre activité a été publiée avec succès. Elle est désormais cartographiée et explorable !
                    </p>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleCreateListing} className="space-y-4">
                  <div className="space-y-1">
                    <label className="block text-[9px] font-bold uppercase tracking-wider text-stone-400">Titre de l'expérience</label>
                    <input
                      type="text"
                      placeholder="Atelier Confidentiel de Dégustation d'Huiles et Vins rares"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="w-full px-3.5 py-3 rounded-xl border border-stone-200 text-xs text-stone-800 bg-white focus:ring-2 focus:ring-brand-green-med outline-none"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-[9px] font-bold uppercase tracking-wider text-stone-400">Description détaillée</label>
                    <textarea
                      rows={4}
                      placeholder="Décrivez les temps forts, le planning des activités guidées et les commodités incluses..."
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="w-full px-3.5 py-3 rounded-xl border border-stone-200 text-xs text-stone-800 bg-white focus:ring-2 focus:ring-brand-green-med outline-none"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <label className="block text-[9px] font-bold uppercase tracking-wider text-stone-400">Tarif public (€)</label>
                      <input
                        type="number"
                        placeholder="45"
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        className="w-full px-3.5 py-3 rounded-xl border border-stone-200 text-xs text-stone-800 bg-white focus:ring-2 focus:ring-brand-green-med outline-none"
                        required
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[9px] font-bold uppercase tracking-wider text-stone-400">Ville du lieu</label>
                      <select
                        value={city}
                        onChange={(e) => setCity(e.target.value as any)}
                        className="w-full px-3.5 py-3 rounded-xl border border-stone-200 text-xs text-stone-800 bg-white focus:ring-2 focus:ring-brand-green-med outline-none"
                      >
                        <option value="Paris">Paris (IDF)</option>
                        <option value="Lyon">Lyon (69)</option>
                        <option value="Marseille">Marseille (13)</option>
                        <option value="Bordeaux">Bordeaux (33)</option>
                        <option value="Nantes">Nantes (44)</option>
                        <option value="Lille">Lille (59)</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[9px] font-bold uppercase tracking-wider text-stone-400">Catégorie Sphere</label>
                      <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value as CategoryId)}
                        className="w-full px-3.5 py-3 rounded-xl border border-stone-200 text-xs text-stone-800 bg-white focus:ring-2 focus:ring-brand-green-med outline-none animate"
                      >
                        <option value="gastronomie">Gastronomie</option>
                        <option value="bien_etre">Bien-être</option>
                        <option value="sport">Sport</option>
                        <option value="insolite">Insolite</option>
                        <option value="sorties">Sorties & Expériences</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={isToday}
                        onChange={(e) => setIsToday(e.target.checked)}
                        className="rounded text-brand-green-med"
                      />
                      <span className="text-xs font-semibold text-stone-600">Offre disponible aujourd'hui</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={isWeekend}
                        onChange={(e) => setIsWeekend(e.target.checked)}
                        className="rounded text-brand-green-med"
                      />
                      <span className="text-xs font-semibold text-stone-600">Offre disponible ce week-end</span>
                    </label>
                  </div>

                  <div className="pt-4 border-t border-stone-100">
                    <button
                      type="submit"
                      className="px-6 py-3 bg-brand-green-dark hover:bg-brand-green-med text-brand-cream border border-brand-gold uppercase tracking-widest text-[#E9E6D5] text-xs font-bold rounded-xl shadow cursor-pointer transition-colors"
                    >
                      Publier l'expérience sur la plateforme
                    </button>
                  </div>
                </form>
              )}

            </div>
          )}

        </div>

      </div>

    </div>
  );
}
