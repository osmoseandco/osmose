import { useState } from 'react';
import { Article } from '../types';
import { articles, experiences } from '../data/mockData';
import { LucideIcon } from '../components/LucideIcon';

interface BlogViewProps {
  onSelectArticle: (article: Article) => void;
  selectedArticle: Article | null;
  onCloseArticle: () => void;
  onNavigateToExplorer: () => void;
}

export function BlogView({
  onSelectArticle,
  selectedArticle,
  onCloseArticle,
  onNavigateToExplorer
}: BlogViewProps) {
  const [activeCategory, setActiveCategory] = useState<string>('Tous');

  // Filter articles listed by active category click
  const filteredArticles = articles.filter(art => {
    if (activeCategory === 'Tous') return true;
    return art.category === activeCategory;
  });

  const blogCategories = ['Tous', 'Insolite', 'Bien-être', 'Gastronomie'];

  return (
    <div className="min-h-screen pb-32">
      
      {/* 1. EDITORIAL HEADER BANNER (Displayed ONLY when reading listings list) */}
      {!selectedArticle && (
        <section className="bg-[#E9E6D5]/40 py-12 border-b border-stone-200/60 select-none">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-3 animate-fade-in">
            <span className="text-[10px] uppercase font-sans tracking-widest font-extrabold text-brand-gold-dark bg-white rounded-full px-3 py-1 border border-brand-gold/25">
              MAGAZINE LIFESTYLECONFIDENTIEL
            </span>
            <h1 className="font-serif text-3xl sm:text-4.5xl font-extrabold text-brand-green-dark tracking-tight">
              Les Guides de l'Osmose
            </h1>
            <p className="font-sans text-stone-500 text-xs sm:text-sm max-w-xl mx-auto font-light leading-relaxed">
              Inspirations, adresses cachées, secrets d’artisans et thérapies holistiques décryptés sous la plume de notre rédaction.
            </p>
          </div>
        </section>
      )}

      {/* 2. CHIEF CONTENT CORES VIEWPORTS */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        
        {selectedArticle ? (
          /* ========================================================
             DETAIL VIEW: RICH READ STORIES LAYOUT PANEL
             ======================================================== */
          <div className="max-w-4xl mx-auto space-y-8 animate-fade-in text-left">
            
            {/* Back to Guides link */}
            <button 
              onClick={onCloseArticle}
              className="text-brand-green-dark text-xs font-semibold flex items-center gap-1.5 hover:underline"
            >
              <LucideIcon name="ChevronLeft" size={16} /> Retour aux guides et articles
            </button>

            {/* Immersive cover and metrics */}
            <div className="relative aspect-16/9 rounded-3xl overflow-hidden border border-stone-250 shadow-sm bg-stone-100">
              <img 
                src={selectedArticle.image} 
                alt={selectedArticle.title} 
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
              
              <div className="absolute bottom-6 left-6 right-6 text-[#E9E6D5] space-y-2">
                <span className="px-2.5 py-0.5 bg-brand-gold text-brand-green-dark rounded font-sans text-[8px] font-bold uppercase tracking-wider">
                  {selectedArticle.category}
                </span>
                
                <h1 className="font-serif text-xl sm:text-2xl md:text-3xl font-extrabold text-white leading-tight">
                  {selectedArticle.title}
                </h1>

                <div className="flex items-center gap-4 text-[10px] text-stone-300 font-medium">
                  <span>Par {selectedArticle.author}</span>
                  <span>•</span>
                  <span>{selectedArticle.date}</span>
                  <span>•</span>
                  <span className="bg-white/20 px-2 py-0.5 rounded text-white flex items-center gap-1">
                    <LucideIcon name="Clock" size={10} /> {selectedArticle.readingTime} de lecture
                  </span>
                </div>
              </div>
            </div>

            {/* Article core content paragraphs */}
            <div className="prose prose-stone leading-relaxed text-stone-700 text-sm max-w-none space-y-6 font-sans font-light border-b border-stone-100 pb-10">
              {selectedArticle.content.split('\n\n').map((paragraph, i) => (
                <p key={i}>
                  {paragraph}
                </p>
              ))}
            </div>

            {/* HIGH CONVERSION EMBEDDED CTA BLOCK */}
            <div className="bg-brand-midnight text-[#E9E6D5] rounded-3xl p-6 sm:p-8 space-y-6 border-2 border-brand-gold shadow-xl flex flex-col md:flex-row gap-6 items-center justify-between">
              <div className="space-y-2 text-center md:text-left">
                <span className="inline-block text-[8px] font-bold uppercase tracking-widest text-brand-gold bg-white/10 px-2.5 py-1 rounded-full border border-brand-gold/25">
                  ⚡ ALLIANCE DE L'ÉVASION
                </span>
                
                <h3 className="font-serif font-bold text-lg text-white leading-tight">
                  Inspiré par cette lecture ? Passez à l'expérience.
                </h3>
                
                <p className="font-sans text-stone-300 text-[11px] leading-relaxed max-w-lg font-light">
                  Découvrez des dizaines d’activités locales et de rituels holistiques de soins conçus sur-mesure pour vous ressourcer en accord avec notre charte premium.
                </p>
              </div>

              <div className="flex-shrink-0 w-full md:w-auto">
                <button
                  onClick={onNavigateToExplorer}
                  className="w-full md:w-auto px-6 py-4 bg-brand-green-dark hover:bg-brand-green-med text-brand-cream border border-brand-gold rounded-xl font-bold font-sans text-xs uppercase tracking-widest transition-all cursor-pointer shadow-md"
                >
                  Explorer les offres locales
                </button>
              </div>
            </div>

          </div>
        ) : (
          /* ========================================================
             LISTINGS VIEW: LIST OF EDITORIAL GUIDES
             ======================================================== */
          <div className="space-y-12 text-left">
            
            {/* Category tabs filters */}
            <div className="flex justify-center gap-2 border-b border-stone-150 pb-4">
              {blogCategories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-4 py-2 font-sans font-bold text-[10px] uppercase tracking-wider rounded-full border transition-all ${
                    activeCategory === cat 
                      ? 'bg-brand-green-dark text-[#E9E6D5] border-brand-green-dark shadow-sm' 
                      : 'bg-white text-stone-500 border-stone-200 hover:bg-stone-50'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Featured Hero Article card (first returned article in row if any) */}
            {filteredArticles.length > 0 && (
              <div 
                onClick={() => onSelectArticle(filteredArticles[0])}
                className="group bg-white rounded-3xl border border-stone-200/80 overflow-hidden shadow-sm hover:shadow-md cursor-pointer transition-all duration-300 grid grid-cols-1 lg:grid-cols-12"
              >
                <div className="lg:col-span-7 aspect-16/9 lg:aspect-auto bg-stone-100">
                  <img 
                    src={filteredArticles[0].image} 
                    alt={filteredArticles[0].title} 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-[1.01] transition-transform duration-500"
                  />
                </div>
                
                <div className="lg:col-span-5 p-6 sm:p-10 flex flex-col justify-between">
                  <div className="space-y-4">
                    <span className="px-2 py-0.5 bg-brand-green-dark/10 text-brand-green-dark rounded font-sans text-[8px] font-bold uppercase tracking-wider">
                      {filteredArticles[0].category}
                    </span>
                    
                    <h2 className="font-serif text-xl sm:text-2xl font-bold text-stone-900 group-hover:text-brand-green-dark transition-colors duration-200 leading-tight">
                      {filteredArticles[0].title}
                    </h2>
                    
                    <p className="text-stone-500 text-xs sm:text-sm font-sans font-light leading-relaxed">
                      {filteredArticles[0].excerpt}
                    </p>
                  </div>

                  <div className="pt-6 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-400 font-medium">
                    <div className="flex items-center gap-1.5">
                      <span className="font-semibold text-stone-600">{filteredArticles[0].author}</span>
                      <span>•</span>
                      <span>{filteredArticles[0].date}</span>
                    </div>
                    <span className="flex items-center gap-1 font-semibold text-brand-green-med">
                      <LucideIcon name="Clock" size={12} /> {filteredArticles[0].readingTime}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Sub-grid of remaining articles */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredArticles.slice(1).map(art => (
                <div
                  key={art.id}
                  onClick={() => onSelectArticle(art)}
                  className="group bg-white rounded-2xl border border-stone-100 overflow-hidden shadow-sm hover:shadow-md cursor-pointer transition-all duration-300 flex flex-col"
                >
                  <div className="aspect-16/9 bg-stone-100 overflow-hidden">
                    <img 
                      src={art.image} 
                      alt={art.title} 
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                    />
                  </div>

                  <div className="p-5 flex-grow flex flex-col justify-between space-y-4">
                    <div className="space-y-2">
                      <span className="text-[8px] font-extrabold uppercase tracking-wider text-brand-green-med">
                        {art.category}
                      </span>
                      
                      <h3 className="font-serif font-bold text-sm text-stone-900 group-hover:text-brand-green-dark transition-colors duration-200 leading-snug line-clamp-2">
                        {art.title}
                      </h3>
                      
                      <p className="text-stone-500 text-xs font-sans font-light leading-relaxed line-clamp-2">
                        {art.excerpt}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-[10px] text-stone-400 font-medium">
                      <span>{art.date}</span>
                      <span className="flex items-center gap-1">
                        <LucideIcon name="Clock" size={10} /> {art.readingTime}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

          </div>
        )}

      </div>

    </div>
  );
}
