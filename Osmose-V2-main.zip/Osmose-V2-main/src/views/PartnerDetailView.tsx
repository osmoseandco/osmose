import React, { useState } from 'react';
import { Partner, Experience, Review } from '../types';
import { experiences } from '../data/mockData';
import { LucideIcon } from '../components/LucideIcon';
import { ExperienceCard } from '../components/ExperienceCard';

interface PartnerDetailViewProps {
  partner: Partner;
  onSelectExperience: (experience: Experience) => void;
  favorites: string[];
  onToggleFavorite: (e: React.MouseEvent, id: string) => void;
  onBack: () => void;
}

export function PartnerDetailView({
  partner,
  onSelectExperience,
  favorites,
  onToggleFavorite,
  onBack
}: PartnerDetailViewProps) {
  const [activeTab, setActiveTab] = useState<'info' | 'services' | 'reviews'>('info');
  const [reviewsList, setReviewsList] = useState<Review[]>(partner.reviews || []);
  
  // Custom Reviews state form
  const [newComment, setNewComment] = useState('');
  const [newRating, setNewRating] = useState(5);
  const [authorName, setAuthorName] = useState('');
  const [showForm, setShowForm] = useState(false);

  // Retrieve experiences specific to this partner
  const hostedExperiences = experiences.filter(exp => exp.partnerId === partner.id);

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment || !authorName) return;

    const addedReview: Review = {
      id: `rev-${Date.now()}`,
      userName: authorName,
      userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&h=100&q=80', // default avatar
      rating: newRating,
      comment: newComment,
      date: 'A l\'instant'
    };

    setReviewsList([addedReview, ...reviewsList]);
    setNewComment('');
    setAuthorName('');
    setShowForm(false);
  };

  return (
    <div className="min-h-screen pb-32">
      
      {/* 1. TOP PREMIUM COVER HERO */}
      <div className="relative h-[30vh] bg-stone-900">
        <img 
          src={partner.coverImage} 
          alt={partner.name} 
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover opacity-60"
        />
        {/* Sleek navigation back button */}
        <button
          onClick={onBack}
          className="absolute top-4 left-4 z-20 inline-flex items-center gap-2 px-3.5 py-2 bg-white/90 backdrop-blur-md hover:bg-white rounded-xl text-xs font-bold text-stone-800 transition-all border border-stone-200 hover:scale-105 cursor-pointer shadow-md select-none"
        >
          <LucideIcon name="ArrowLeft" size={14} className="text-stone-600" />
          <span>Retour</span>
        </button>

        {/* Decorative linear bottom fade-out */}
        <div className="absolute inset-0 bg-gradient-to-t from-stone-50 to-transparent" />
      </div>

      {/* 2. CIRCULAR LOGO & IDENTITY PROFILE */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-20 relative z-10 space-y-8 select-none">
        
        <div className="flex flex-col md:flex-row gap-6 items-end md:items-center justify-between bg-white border border-stone-200 p-6 rounded-3xl shadow-md">
          <div className="flex flex-col sm:flex-row gap-5 items-start sm:items-center">
            
            {/* Round company logo with premium golden frame */}
            <div className="w-24 h-24 shrink-0 rounded-full border-4 border-brand-gold bg-white shadow-xl overflow-hidden -mt-16 md:mt-0">
              <img 
                src={partner.logo} 
                alt={partner.name} 
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="space-y-1.5 text-left">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="font-serif text-xl sm:text-2xl font-extrabold text-stone-900 tracking-tight leading-none">
                  {partner.name}
                </h1>
                {partner.premium && (
                  <span className="bg-amber-50 text-brand-gold-dark border border-brand-gold/50 text-[8px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-0.5 shadow-sm">
                    ✨ Partenaire Premium
                  </span>
                )}
              </div>
              
              <p className="text-xs text-stone-500 font-medium flex items-center gap-1">
                <LucideIcon name="MapPin" size={13} className="text-brand-green-med" />
                {partner.location}
              </p>

              <div className="flex items-center gap-3 text-xs text-stone-600">
                <div className="flex items-center gap-0.5">
                  <span className="text-brand-gold text-sm">★</span>
                  <span className="font-bold">{partner.rating.toFixed(1)}</span>
                </div>
                <span className="text-stone-300">•</span>
                <span>{reviewsList.length} avis certifiés</span>
                <span className="text-stone-300">•</span>
                <span>Membre depuis {partner.founded}</span>
              </div>
            </div>
            
          </div>

          {/* Quick contact / direct bookings trigger */}
          <div className="flex gap-2 w-full sm:w-auto">
            <a 
              href={`mailto:${partner.email}`}
              className="flex-grow sm:flex-grow-0 px-4 py-2.5 border border-stone-200 text-stone-600 hover:text-brand-green-dark hover:border-brand-green-med rounded-xl text-xs font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5"
            >
              <LucideIcon name="Mail" size={12} /> Nous écrire
            </a>
            <a 
              href={`tel:${partner.phone}`}
              className="px-4 py-2.5 bg-brand-green-dark hover:bg-brand-green-med text-brand-cream rounded-xl text-xs font-bold border border-brand-gold uppercase tracking-wider transition-all shadow duration-300 flex items-center justify-center gap-1.5"
            >
              <LucideIcon name="Phone" size={12} /> Appeler
            </a>
          </div>

        </div>

        {/* 3. CORE SUB-BAR NAVIGATION TABS */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* LEFT PANEL COLUMN */}
          <div className="lg:col-span-8 space-y-8 text-left bg-white border border-stone-200/80 rounded-3xl p-6 md:p-8 shadow-sm">
            
            {/* Tabs control */}
            <div className="flex border-b border-stone-100 pb-2">
              <button
                onClick={() => setActiveTab('info')}
                className={`pb-3 text-xs font-bold uppercase tracking-wider transition-colors relative px-4 ${
                  activeTab === 'info' ? 'text-brand-green-dark font-semibold' : 'text-stone-400 hover:text-stone-600'
                }`}
              >
                Information
                {activeTab === 'info' && <div className="absolute bottom-[-1px] left-0 right-0 h-[2px] bg-brand-gold rounded-full" />}
              </button>
              
              <button
                onClick={() => setActiveTab('services')}
                className={`pb-3 text-xs font-bold uppercase tracking-wider transition-colors relative px-4 ${
                  activeTab === 'services' ? 'text-brand-green-dark font-semibold' : 'text-stone-400 hover:text-stone-600'
                }`}
              >
                Services Pro ({partner.services.length})
                {activeTab === 'services' && <div className="absolute bottom-[-1px] left-0 right-0 h-[2px] bg-brand-gold rounded-full" />}
              </button>
              
              <button
                onClick={() => setActiveTab('reviews')}
                className={`pb-3 text-xs font-bold uppercase tracking-wider transition-colors relative px-4 ${
                  activeTab === 'reviews' ? 'text-brand-green-dark font-semibold' : 'text-stone-400 hover:text-stone-600'
                }`}
              >
                Avis Clients ({reviewsList.length})
                {activeTab === 'reviews' && <div className="absolute bottom-[-1px] left-0 right-0 h-[2px] bg-brand-gold rounded-full" />}
              </button>
            </div>

            {/* TAB CONTENT: PRESENTATION INFO */}
            {activeTab === 'info' && (
              <div className="space-y-6 animate-fade-in">
                <div className="space-y-3">
                  <h3 className="font-serif font-bold text-sm text-brand-green-dark uppercase tracking-wider">A propos de nous</h3>
                  <p className="text-sm text-stone-600 leading-relaxed font-sans font-light">
                    {partner.description}
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-stone-100 text-stone-500 text-xs">
                  <div className="space-y-1">
                    <span className="font-bold text-[9px] uppercase tracking-wider text-brand-green-dark">Adresse des Ateliers</span>
                    <p className="text-stone-700 font-semibold">{partner.location}</p>
                  </div>
                  <div className="space-y-1">
                    <span className="font-bold text-[9px] uppercase tracking-wider text-brand-green-dark">Contact administratif</span>
                    <p className="text-stone-700 font-semibold">{partner.email}</p>
                  </div>
                </div>
              </div>
            )}

            {/* TAB CONTENT: EXCLUSIVE SERVICES */}
            {activeTab === 'services' && (
              <div className="space-y-4 animate-fade-in">
                <h3 className="font-serif font-bold text-sm text-brand-green-dark uppercase tracking-wider">PRESTATIONS SUR-MESURE</h3>
                <p className="text-xs text-stone-500">Contactez directement le partenaire ou réservez une de ses sessions listées ci-dessous.</p>
                
                <div className="divide-y divide-stone-100">
                  {partner.services.map((srv, idx) => (
                    <div key={idx} className="py-3 flex items-center justify-between gap-4">
                      <div className="flex items-center gap-2.5">
                        <span className="w-5 h-5 rounded-full bg-brand-cream/60 flex items-center justify-center text-brand-green-dark font-bold text-xs">
                          {idx + 1}
                        </span>
                        <span className="text-xs text-stone-700 font-semibold">{srv}</span>
                      </div>
                      <span className="text-[10px] text-brand-gold-dark font-sans font-bold uppercase tracking-wider bg-amber-50 rounded px-2.5 py-0.5 border border-brand-gold/15">
                        Inclus Service Pro
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB CONTENT: CLIENTS REVIEWS */}
            {activeTab === 'reviews' && (
              <div className="space-y-6 animate-fade-in">
                
                <div className="flex justify-between items-center pb-4 border-b border-stone-100">
                  <h3 className="font-serif font-bold text-sm text-brand-green-dark uppercase tracking-wider">Avis certifiés</h3>
                  <button
                    onClick={() => setShowForm(!showForm)}
                    className="px-3.5 py-1.5 bg-brand-green-dark hover:bg-brand-green-med border border-brand-gold text-brand-cream font-sans font-bold text-[10px] uppercase tracking-widest rounded-lg flex items-center gap-1 shadow-sm"
                  >
                    <LucideIcon name="Edit" size={11} /> Rédiger un avis
                  </button>
                </div>

                {/* Submitting form module */}
                {showForm && (
                  <form onSubmit={handleSubmitReview} className="bg-stone-50 border border-stone-200 p-4 rounded-2xl space-y-4 animate-scale-in">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[9px] font-bold uppercase tracking-wider text-stone-400 mb-1">Votre Nom</label>
                        <input
                          type="text"
                          placeholder="Marie Lafitte"
                          value={authorName}
                          onChange={(e) => setAuthorName(e.target.value)}
                          className="w-full px-3 py-2 rounded-lg border border-stone-200 outline-none text-xs bg-white text-stone-800"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] font-bold uppercase tracking-wider text-stone-400 mb-1">Note de l'alliance</label>
                        <select
                          value={newRating}
                          onChange={(e) => setNewRating(Number(e.target.value))}
                          className="w-full px-3 py-2 rounded-lg border border-stone-200 outline-none text-xs bg-white text-stone-800 font-bold"
                        >
                          <option value="5">★★★★★ Excellent (5/5)</option>
                          <option value="4">★★★★ Très bon (4/5)</option>
                          <option value="3">★★★ Moyen (3/5)</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[9px] font-bold uppercase tracking-wider text-stone-400 mb-1">Votre Commentaire</label>
                      <textarea
                        rows={3}
                        placeholder="Racontez votre expérience avec ce partenaire..."
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg border border-stone-200 outline-none text-xs bg-white text-stone-800"
                        required
                      />
                    </div>

                    <div className="flex gap-2 justify-end">
                      <button
                        type="button"
                        onClick={() => setShowForm(false)}
                        className="px-3 py-1.5 border border-stone-200 text-stone-600 text-[10px] font-bold rounded-lg uppercase"
                      >
                        Annuler
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 bg-brand-green-dark text-[#E9E6D5] text-[10px] font-bold rounded-lg uppercase tracking-wider border border-brand-gold"
                      >
                        Envoyer
                      </button>
                    </div>
                  </form>
                )}

                {/* Reviews Stream */}
                <div className="space-y-4">
                  {reviewsList.length === 0 ? (
                    <p className="text-xs text-stone-400">Aucun avis rédigé pour le moment. Soyez le premier !</p>
                  ) : (
                    reviewsList.map((rev) => (
                      <div key={rev.id} className="p-4 border border-stone-100 rounded-2xl bg-stone-50/50 space-y-2">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2.5">
                            <img 
                              src={rev.userAvatar} 
                              alt={rev.userName} 
                              referrerPolicy="no-referrer"
                              className="w-8 h-8 rounded-full object-cover border border-stone-200"
                            />
                            <div>
                              <h4 className="font-semibold text-xs text-stone-800">{rev.userName}</h4>
                              <p className="text-[9px] text-stone-400">{rev.date}</p>
                            </div>
                          </div>

                          <div className="flex text-brand-gold text-xs">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <span key={i}>{i < rev.rating ? '★' : '☆'}</span>
                            ))}
                          </div>
                        </div>
                        <p className="text-xs text-stone-600 italic font-medium leading-relaxed font-sans">
                          "{rev.comment}"
                        </p>
                      </div>
                    ))
                  )}
                </div>

              </div>
            )}

          </div>

          {/* RIGHT BUSINESS METRICS SIDE */}
          <div className="lg:col-span-4">
            <div className="bg-brand-midnight text-brand-cream border-2 border-brand-gold rounded-3xl p-6 shadow-xl space-y-6">
              
              <div className="space-y-1 pb-4 border-b border-brand-cream/10">
                <span className="text-[8px] font-extrabold uppercase tracking-widest text-brand-gold">
                  ⚡ CERTIFICAT OSMOSE
                </span>
                <h3 className="font-serif font-bold text-sm tracking-wider">Allègements administratifs</h3>
              </div>
              
              <div className="space-y-4 text-xs text-stone-300">
                <div className="flex gap-2">
                  <div className="w-5 h-5 shrink-0 rounded-full bg-brand-green-dark border-all border-brand-gold flex items-center justify-center text-brand-gold text-[10px]">
                    ✓
                  </div>
                  <p className="leading-tight leading-relaxed">
                    Professionnels qualifiés et diplômés d'État certifiés après examen sur dossier.
                  </p>
                </div>

                <div className="flex gap-2">
                  <div className="w-5 h-5 shrink-0 rounded-full bg-brand-green-dark border-all border-brand-gold flex items-center justify-center text-brand-gold text-[10px]">
                    ✓
                  </div>
                  <p className="leading-tight leading-relaxed">
                    Assurance responsabilité civile professionnelle à jour et disponible en téléchargement libre.
                  </p>
                </div>

                <div className="flex gap-2">
                  <div className="w-5 h-5 shrink-0 rounded-full bg-brand-green-dark border-all border-brand-gold flex items-center justify-center text-brand-gold text-[10px]">
                    ✓
                  </div>
                  <p className="leading-tight leading-relaxed">
                    Garantie remboursement 100% en cas d'annulation majeure de la session d'activité.
                  </p>
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* 4. HOSTED EXPERIENCES LISTINGS GRID FOOTER */}
        <section className="space-y-6 pt-12 border-t border-stone-100">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-6 bg-brand-gold rounded-full" />
            <h2 className="font-serif text-xl font-bold text-stone-800 uppercase tracking-wide">
              EXPÉRIENCES PROPOSÉES ({hostedExperiences.length})
            </h2>
          </div>
          
          {hostedExperiences.length === 0 ? (
            <p className="text-xs text-stone-400">Aucune activité n'est programmée pour le moment.</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {hostedExperiences.map((exp) => (
                <ExperienceCard
                  key={exp.id}
                  experience={exp}
                  isFavorited={favorites.includes(exp.id)}
                  onToggleFavorite={onToggleFavorite}
                  onClick={onSelectExperience}
                />
              ))}
            </div>
          )}
        </section>

      </div>

    </div>
  );
}
