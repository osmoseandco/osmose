import React, { useState } from 'react';
import { LucideIcon } from '../components/LucideIcon';

export function BecomePartnerView() {
  const [companyName, setCompanyName] = useState('');
  const [category, setCategory] = useState('gastronomie');
  const [selectedPlan, setSelectedPlan] = useState<'free' | 'pro' | 'premium'>('pro');
  const [phone, setPhone] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyName || !phone) return;
    setSuccess(true);
  };

  const steps = [
    { title: '1. Créez votre compte', desc: 'Renseignez votre SIRET et téléchargez votre assurance RCP.' },
    { title: '2. Publiez vos offres', desc: 'Saisissez vos créneaux, images immersives et conditions d\'annulation.' },
    { title: '3. Encaissez sereinement', desc: 'Recevez les paiements automatisés mensuellement par virement SEPA direct.' }
  ];

  const plans = [
    {
      id: 'free',
      name: 'FREE',
      price: '0 €',
      period: 'sans engagement',
      features: [
        'Référencement standard',
        'Jusqu’à 3 annonces d\'activités',
        'Paiements automatisés',
        'Commissions de 15% par réservation'
      ],
      cta: 'Démarrer gratuitement',
      badge: '',
      color: 'border-stone-200'
    },
    {
      id: 'pro',
      name: 'PRO',
      price: '49 €',
      period: 'HT / mois',
      features: [
        'Visibilité doublée sur la carte',
        'Annonces illimitées',
        'Taux de commission réduit à 5%',
        'Statistiques du dashboard pro',
        'Support client sous 24h'
      ],
      cta: 'Choisir le forfait PRO',
      badge: 'Le plus plébiscité 🔥',
      color: 'border-brand-green-med ring-2 ring-brand-green-med/40'
    },
    {
      id: 'premium',
      name: 'PREMIUM',
      price: '99 €',
      period: 'HT / mois',
      features: [
        'Placements sponsorisés en tête de liste',
        'Annonces illimitées',
        '0% commission sur vos transactions',
        'Dashboard pro analytics détaillé',
        'Conseiller stratégique dédié',
        'Campagne e-mailing mensuelle Osmose'
      ],
      cta: 'Passer au PREMIUM',
      badge: 'Visibilité maximale 🚀',
      color: 'border-brand-gold ring-4 ring-brand-gold/30'
    }
  ] as const;

  return (
    <div className="min-h-screen pb-32">
      
      {/* 1. MARKETING VALUE LANDING HERO */}
      <section className="bg-brand-green-dark text-[#E9E6D5] py-20 px-4 text-center space-y-6 relative overflow-hidden select-none">
        <div className="absolute inset-0 bg-[radial-gradient(#ffffff08_1px,transparent_1px)] [background-size:16px_16px]" />
        
        <div className="relative z-10 max-w-4xl mx-auto space-y-6 animate-fade-in">
          <span className="text-[10px] uppercase tracking-widest font-extrabold text-brand-gold bg-white/10 px-4 py-1.5 rounded-full border border-brand-gold/40">
            DÉVELOPPEZ VOTRE ACTIVITÉ LOCALE
          </span>
          
          <h1 className="font-serif text-3xl sm:text-4xl md:text-5.5xl font-bold leading-none tracking-tight">
            Devenez Partenaire <span className="text-brand-gold">Osmose</span>
          </h1>
          
          <p className="font-sans text-stone-200 text-sm max-w-2xl mx-auto font-light leading-relaxed">
            Rejoignez le collectif d’artisans, de guides, de thérapeutes et de créateurs d’expériences d'exception. Augmentez vos réservations d'activités grâce à notre visibilité.
          </p>
        </div>
      </section>

      {/* 2. STATS & BENEFITS MATRIX */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
          <div className="bg-white border border-stone-200 p-6 rounded-3xl shadow-sm space-y-2">
            <div className="w-10 h-10 rounded-full bg-brand-green-dark/10 text-brand-green-dark flex items-center justify-center mx-auto mb-2">
              <LucideIcon name="Users" size={16} />
            </div>
            <h3 className="font-serif font-bold text-lg text-brand-green-dark">+15 000</h3>
            <p className="text-xs text-stone-500 font-sans leading-tight">Explorateurs actifs recherchant de nouvelles expériences locales par mois.</p>
          </div>

          <div className="bg-white border border-stone-200 p-6 rounded-3xl shadow-sm space-y-2">
            <div className="w-10 h-10 rounded-full bg-brand-green-dark/10 text-brand-green-dark flex items-center justify-center mx-auto mb-2">
              <LucideIcon name="TrendingUp" size={16} />
            </div>
            <h3 className="font-serif font-bold text-lg text-brand-green-dark">+42 %</h3>
            <p className="text-xs text-stone-500 font-sans leading-tight">Augmentation constatée du taux d’occupation moyen de nos partenaires premium.</p>
          </div>

          <div className="bg-white border border-stone-200 p-6 rounded-3xl shadow-sm space-y-2">
            <div className="w-10 h-10 rounded-full bg-brand-green-dark/10 text-brand-green-dark flex items-center justify-center mx-auto mb-2">
              <LucideIcon name="Award" size={16} />
            </div>
            <h3 className="font-serif font-bold text-lg text-brand-green-dark">0 €</h3>
            <p className="text-xs text-stone-500 font-sans leading-tight">Frais cachés de configuration ou de maintenance. Intégration 100% transparente.</p>
          </div>
        </div>
      </section>

      {/* 3. CORE PLANS MATRIX */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-24 space-y-12">
        <div className="text-center space-y-2 select-none">
          <h2 className="font-serif text-2xl sm:text-3xl font-bold tracking-wide text-stone-950">Des abonnements adaptés à votre échelle</h2>
          <p className="text-sm text-stone-500 max-w-md mx-auto">Choisissez la formule idéale, passez au forfait supérieur à tout moment.</p>
          <div className="w-16 h-[2px] bg-brand-gold mx-auto" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch pt-4">
          {plans.map((p) => (
            <div 
              key={p.id}
              onClick={() => setSelectedPlan(p.id)}
              className={`bg-white border rounded-3xl p-8 flex flex-col justify-between shadow-md transition-all duration-300 relative cursor-pointer hover:shadow-xl ${p.color} ${selectedPlan === p.id ? 'scale-102 border-l-4' : ''}`}
            >
              <div>
                {/* Visual Gold tag badge */}
                {p.badge && (
                  <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3 py-1 bg-brand-green-dark text-brand-cream border border-brand-gold text-[8px] font-bold uppercase rounded-full tracking-widest shadow-md">
                    {p.badge}
                  </span>
                )}

                <div className="text-center border-b border-stone-100 pb-5">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-[#B8860B] block mb-2">{p.name}</span>
                  <div className="flex justify-center items-baseline gap-1">
                    <span className="font-serif font-extrabold text-3.5xl text-brand-green-dark">{p.price}</span>
                    <span className="text-xs text-stone-400 font-semibold font-sans uppercase tracking-widest leading-none">{p.period}</span>
                  </div>
                </div>

                <ul className="space-y-3.5 pt-6 text-left text-xs text-stone-600 font-medium">
                  {p.features.map((feature, idx) => (
                    <li key={idx} className="flex gap-2.5 items-start">
                      <div className="w-4 h-4 rounded-full bg-emerald-50 text-brand-green-dark border-all flex items-center justify-center shrink-0 text-[10px]">
                        ✓
                      </div>
                      <span className="leading-tight">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-8">
                <button
                  type="button"
                  className={`w-full py-3.5 font-sans font-extrabold text-2xs uppercase tracking-widest rounded-xl transition-all duration-300 border ${
                    selectedPlan === p.id 
                      ? 'bg-brand-green-dark text-brand-cream border-brand-gold shadow-md' 
                      : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'
                  }`}
                >
                  {p.cta}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. ON-BOARDING / ENROLLMENT APPLICATION FORM */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mt-28">
        
        <div className="bg-white border border-stone-200 rounded-3xl p-6 sm:p-10 shadow-xl space-y-8">
          
          <div className="text-center space-y-1.5 border-b border-stone-100 pb-6">
            <h3 className="font-serif font-extrabold text-xl text-brand-green-dark">DÉPOSEZ VOTRE CANDIDATURE</h3>
            <p className="text-stone-500 text-xs">Notre équipe étudiera votre dossier sous 48h ouvrées.</p>
          </div>

          {success ? (
            <div className="text-center py-8 space-y-4 animate-scale-in">
              <div className="w-16 h-16 bg-emerald-50 border-2 border-brand-green-med rounded-full flex items-center justify-center mx-auto text-brand-green-dark">
                <LucideIcon name="CheckCircle" size={32} />
              </div>
              <div className="space-y-2">
                <h4 className="font-serif font-bold text-[#0E5B50] text-lg uppercase tracking-wide">Dossier de candidature transmis !</h4>
                <p className="text-stone-500 text-xs max-w-md mx-auto">
                  Merci pour l'intérêt témoigné ! Un conseiller d'Osmose étudiera les éléments transmis et vous appellera sous peu au <strong>{phone}</strong> pour valider l'on-boarding.
                </p>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                
                {/* Etape 1: Company details */}
                <div className="space-y-4">
                  <h4 className="text-[10px] font-extrabold uppercase tracking-widest text-[#B8860B] border-b border-stone-100 pb-1">1. IDENTITÉ DU PARTENAIRE</h4>
                  
                  <div className="space-y-1">
                    <label className="block text-[9px] font-bold uppercase tracking-wider text-stone-400">Nom commercial / Société</label>
                    <input
                      type="text"
                      placeholder="Atelier de Céramique d'Art"
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      className="w-full px-3.5 py-3 rounded-xl border border-stone-200 text-xs text-stone-800 outline-none focus:ring-2 focus:ring-brand-green-med transition-all bg-white"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-[9px] font-bold uppercase tracking-wider text-stone-400">Catégorie d'activité principale</label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full px-3.5 py-3 rounded-xl border border-stone-200 text-xs text-stone-800 outline-none focus:ring-2 focus:ring-brand-green-med transition-all bg-white"
                    >
                      <option value="gastronomie">Gastronomie & Cuisine</option>
                      <option value="bien_etre">Bien-être & Massages</option>
                      <option value="sport">Activités Sportives Extérieures</option>
                      <option value="insolite">Hébergements / Insolite</option>
                      <option value="sorties">Sorties & Spectacles</option>
                    </select>
                  </div>
                </div>

                {/* Etape 2: Contact & validation plans */}
                <div className="space-y-4">
                  <h4 className="text-[10px] font-extrabold uppercase tracking-widest text-[#B8860B] border-b border-stone-100 pb-1">2. PLANS & ACTIONS</h4>
                  
                  <div className="space-y-1">
                    <label className="block text-[9px] font-bold uppercase tracking-wider text-stone-400">Numéro de Téléphone Direct</label>
                    <input
                      type="tel"
                      placeholder="+33 6 12 34 56 78"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-3.5 py-3 rounded-xl border border-stone-200 text-xs text-stone-800 outline-none focus:ring-2 focus:ring-brand-green-med transition-all bg-white"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-[9px] font-bold uppercase tracking-wider text-stone-400">Forfait souhaité</label>
                    <select
                      value={selectedPlan}
                      onChange={(e) => setSelectedPlan(e.target.value as any)}
                      className="w-full px-3.5 py-3 rounded-xl border border-brand-gold text-xs font-semibold text-brand-green-dark outline-none focus:ring-2 focus:ring-brand-green-med transition-all bg-[#E9E6D5]/20"
                    >
                      <option value="free">FREE Plan - 15% Comm. (0€ / mois)</option>
                      <option value="pro">PRO Plan - 5% Comm. (49€ HT / mois)</option>
                      <option value="premium">PREMIUM Plan - 0% Comm. (99€ HT / mois)</option>
                    </select>
                  </div>
                </div>

              </div>

              {/* Submit trigger button */}
              <button
                type="submit"
                className="w-full py-4 bg-brand-green-dark hover:bg-brand-green-med text-brand-cream border border-brand-gold uppercase font-sans font-extrabold tracking-widest text-xs rounded-2xl shadow-lg hover:scale-[1.01] transition-transform cursor-pointer"
              >
                Déposer ma demande d'on-boarding
              </button>

            </form>
          )}

        </div>
      </section>

      {/* 5. ROADMAP PROCESS GUIDELINES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-28">
        <h3 className="font-serif font-bold text-center text-xl text-brand-green-dark tracking-wide uppercase mb-12">
          Trois étapes pour lancer votre activité
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((st, idx) => (
            <div key={idx} className="bg-stone-50 border border-stone-250 p-6 rounded-2xl space-y-2 text-left">
              <h4 className="font-serif font-bold text-sm text-brand-green-dark uppercase">{st.title}</h4>
              <p className="text-xs text-stone-600 leading-normal font-sans font-light">{st.desc}</p>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}
