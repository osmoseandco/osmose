import React, { useState } from 'react';
import { experiences, partners } from '../data/mockData';
import { Experience, CategoryId, Partner, Booking } from '../types';
import { LucideIcon } from '../components/LucideIcon';
import { ExperienceCard } from '../components/ExperienceCard';
import { InteractiveGallery } from '../components/InteractiveGallery';
import { InteractiveMap } from '../components/InteractiveMap';
import { Facebook, Twitter, MessageCircle, Link } from 'lucide-react';

interface EventDetailViewProps {
  key?: React.Key;
  experience: Experience;
  onNavigateToPartner: (partnerId: string) => void;
  onSelectExperience: (experience: Experience) => void;
  favorites: string[];
  onToggleFavorite: (e: React.MouseEvent, id: string) => void;
  onConfirmBooking: (booking: Booking) => void;
  isAuthenticated: boolean;
  onOpenAuth: (tab: 'login' | 'signup') => void;
  bookings: Booking[];
  onCancelBooking: (bookingId: string) => void;
}

export function EventDetailView({
  experience,
  onNavigateToPartner,
  onSelectExperience,
  favorites,
  onToggleFavorite,
  onConfirmBooking,
  isAuthenticated,
  onOpenAuth,
  bookings,
  onCancelBooking
}: EventDetailViewProps) {
  const [ticketCount, setTicketCount] = useState<number>(1);
  const [loadingBooking, setLoadingBooking] = useState(false);
  const [isBooked, setIsBooked] = useState(false);
  const [showShareTooltip, setShowShareTooltip] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);
  const [isDescriptionExpanded, setIsDescriptionExpanded] = useState<boolean>(false);

  const existingBooking = bookings?.find(
    b => b.experienceId === experience.id && b.status !== 'cancelled'
  );

  const handleCancelBookingSubmit = (bookingId: string) => {
    onCancelBooking(bookingId);
    setIsBooked(false);
  };

  const shareUrl = typeof window !== 'undefined' ? window.location.href : 'https://osmose.app';
  const shareTitle = `Découvrez l'expérience d'exception "${experience.title}" sur Osmose !`;

  const shareOnFacebook = () => {
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const shareOnTwitter = () => {
    const url = `https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareTitle)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const shareOnWhatsApp = () => {
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareTitle + ' ' + shareUrl)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopySuccess(true);
      setTimeout(() => {
        setCopySuccess(false);
      }, 2500);
    });
  };

  // Retrieve Partner information
  const partner = partners.find(p => p.id === experience.partnerId) || partners[0];

  // Retrieve Similar Events (excluding current)
  const similarExperiences = experiences.filter(
    e => e.category === experience.category && e.id !== experience.id
  ).slice(0, 3);

  const totalPrice = experience.price * ticketCount;

  const handleBookingSubmit = () => {
    if (!isAuthenticated) {
      onOpenAuth('login');
      return;
    }
    setLoadingBooking(true);
    setTimeout(() => {
      const newBooking: Booking = {
        id: `b-${Math.floor(1000 + Math.random() * 9000)}`,
        experienceId: experience.id,
        experienceTitle: experience.title,
        experienceImage: experience.image,
        date: experience.date,
        price: totalPrice,
        status: 'upcoming',
        ticketsCount: ticketCount,
        partnerName: partner.name,
        partnerLogo: partner.logo
      };
      
      onConfirmBooking(newBooking);
      setLoadingBooking(false);
      setIsBooked(true);
    }, 1000);
  };

  const handleShare = () => {
    setShowShareTooltip(true);
    setTimeout(() => {
      setShowShareTooltip(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen pb-32">
      
      {/* 1. HERO COVER BANNER */}
      <div className="relative h-[45vh] md:h-[50vh] bg-stone-900 overflow-hidden">
        <img 
          src={experience.image} 
          alt={experience.title} 
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover opacity-80"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/20 to-transparent" />
        
        {/* Floating actions indicators */}
        <div className="absolute top-6 left-6 z-10">
          <span className="px-3.5 py-1 text-xs font-serif font-bold uppercase tracking-widest bg-brand-green-dark border-all border-brand-gold text-brand-cream rounded-full">
            {experience.category.replace('_', ' ')}
          </span>
        </div>
      </div>

      {/* 2. CORE LAYOUT COLUMNS */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* LEFT SIDE: CORE DETAILS & PRESENTATION */}
          <div className="lg:col-span-8 space-y-8 bg-white border border-stone-200/80 rounded-3xl p-6 md:p-8 shadow-sm">
            
            {/* Header Identity banner */}
            <div className="space-y-4">
              <div className="flex justify-between items-start gap-4">
                <h1 className="font-serif text-2xl md:text-3.5xl font-extrabold text-stone-900 leading-tight">
                  {experience.title}
                </h1>
                
                <button
                  onClick={(e) => onToggleFavorite(e, experience.id)}
                  className="w-10 h-10 shrink-0 rounded-full border border-stone-100 hover:border-brand-green-med bg-stone-50 hover:bg-stone-100 flex items-center justify-center text-stone-600 transition-all hover:scale-105"
                  title="Ajouter aux favoris"
                >
                  <LucideIcon 
                    name="Heart" 
                    size={20} 
                    className={favorites.includes(experience.id) ? 'fill-red-500 text-red-500 scale-105' : 'text-stone-500'} 
                  />
                </button>
              </div>

              {/* Fast Metadata Indicators */}
              <div className="flex flex-wrap items-center gap-x-6 gap-y-3 text-xs text-stone-500 font-medium">
                <div className="flex items-center gap-1.5">
                  <LucideIcon name="MapPin" size={14} className="text-brand-green-med" />
                  <span>{experience.location}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <LucideIcon name="Calendar" size={14} className="text-brand-green-med" />
                  <span>{experience.date}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="flex items-center text-brand-gold-dark font-bold font-sans">
                    ★ <span className="text-stone-800 ml-0.5">{experience.rating.toFixed(1)}</span>
                  </span>
                  <span>({experience.reviewsCount} avis certifiés)</span>
                </div>
              </div>
            </div>

            {/* MINI INTERACTIVE MAP CENTERED ON EXPERIENCE COORDINATES */}
            <div className="mt-6 p-1.5 bg-stone-50 space-y-3 rounded-3xl border border-stone-200/40">
              <div className="flex items-center justify-between px-3 pt-2">
                <span className="text-[11px] font-bold text-stone-800 font-sans tracking-wider uppercase flex items-center gap-1.5 text-left">
                  <LucideIcon name="Compass" size={13} className="text-brand-gold-dark" />
                  Localisation de l'expérience
                </span>
                <span className="text-[10px] font-mono text-stone-500 bg-white border border-stone-100 px-2 py-0.5 rounded-lg font-bold">
                  🧭 {experience.distance} km d'ici
                </span>
              </div>
              <InteractiveMap
                experiences={[experience]}
                selectedExperience={null}
                onSelectExperience={() => {}}
                className="h-[210px] rounded-2xl md:rounded-2xl"
              />
            </div>

            {/* PRESENTATION TEXTS */}
            <div className="space-y-4 border-t border-b border-stone-100 py-6 text-left">
              <h3 className="font-serif font-bold text-base text-brand-green-dark tracking-wide uppercase">Présentation de l'expérience</h3>
              
              <div className="relative space-y-4">
                <p className="font-sans text-stone-700 text-sm leading-relaxed first-letter:text-3xl first-letter:font-bold first-letter:text-brand-green-dark first-letter:mr-2 flex-wrap">
                  {experience.description}
                </p>

                {isDescriptionExpanded && (
                  <div className="space-y-6 pt-4 border-t border-stone-100/50 animate-fade-in text-left">
                    {experience.longDescription && experience.longDescription !== experience.description && (
                      <p className="font-sans text-stone-600 text-sm leading-relaxed">
                        {experience.longDescription}
                      </p>
                    )}

                    {/* Highly polished experience specs grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                      {/* Item 1 */}
                      <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/40 space-y-1.5 flex items-start gap-3">
                        <div className="w-8 h-8 rounded-full bg-brand-gold/15 flex items-center justify-center text-brand-gold-dark shrink-0">
                          <LucideIcon name="Clock" size={14} className="text-brand-gold-dark" />
                        </div>
                        <div className="text-left">
                          <h4 className="font-sans font-bold text-xs text-stone-800 uppercase tracking-widest">Durée</h4>
                          <p className="text-stone-500 text-xs font-normal">Format immersif de ~3 heures • Rythme doux & suspendu</p>
                        </div>
                      </div>

                      {/* Item 2 */}
                      <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/40 space-y-1.5 flex items-start gap-3">
                        <div className="w-8 h-8 rounded-full bg-brand-gold/15 flex items-center justify-center text-brand-gold-dark shrink-0">
                          <LucideIcon name="Sparkles" size={14} className="text-brand-gold-dark" />
                        </div>
                        <div className="text-left">
                          <h4 className="font-sans font-bold text-xs text-stone-800 uppercase tracking-widest">Inclus</h4>
                          <p className="text-stone-500 text-xs font-normal">Collation terroir, accueil privilégié, matériel certifié et assurances complètes</p>
                        </div>
                      </div>

                      {/* Item 3 */}
                      <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/40 space-y-1.5 flex items-start gap-3">
                        <div className="w-8 h-8 rounded-full bg-brand-gold/15 flex items-center justify-center text-brand-gold-dark shrink-0">
                          <LucideIcon name="Shield" size={14} className="text-brand-gold-dark" />
                        </div>
                        <div className="text-left">
                          <h4 className="font-sans font-bold text-xs text-stone-800 uppercase tracking-widest">Niveau d'effort</h4>
                          <p className="text-stone-500 text-xs font-normal">Aucun prérequis physique, adapté pour un éveil en toute sérénité</p>
                        </div>
                      </div>

                      {/* Item 4 */}
                      <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/40 space-y-1.5 flex items-start gap-3">
                        <div className="w-8 h-8 rounded-full bg-brand-gold/15 flex items-center justify-center text-brand-gold-dark shrink-0">
                          <LucideIcon name="Leaf" size={14} className="text-brand-gold-dark" />
                        </div>
                        <div className="text-left">
                          <h4 className="font-sans font-bold text-xs text-stone-800 uppercase tracking-widest">Charte Osmose</h4>
                          <p className="text-stone-500 text-xs font-normal">Expérience éco-conçue, 100% respectueuse de la biodiversité locale</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Micro-interactive Elegant Button wrapper */}
                <div className="pt-2 flex justify-start">
                  <button
                    onClick={() => setIsDescriptionExpanded(!isDescriptionExpanded)}
                    className="inline-flex items-center gap-2 px-4 py-2 bg-stone-100 hover:bg-stone-200/80 hover:text-stone-900 rounded-full text-xs font-bold text-stone-700 border border-stone-200 transition-all cursor-pointer shadow-sm hover:scale-103 group"
                  >
                    <span>{isDescriptionExpanded ? 'Masquer les détails' : 'Voir tous les détails'}</span>
                    <LucideIcon 
                      name={isDescriptionExpanded ? 'ChevronUp' : 'ChevronDown'} 
                      size={14} 
                      className="text-stone-500 group-hover:text-brand-green-dark transition-colors duration-200" 
                    />
                  </button>
                </div>
              </div>
            </div>

            {/* PICTURE GALLERY PORTFOLIO */}
            <InteractiveGallery 
              gallery={experience.gallery || [experience.image]} 
              title={experience.title} 
            />

            {/* PARTNER CARD EMBED */}
            <div className="p-6 bg-brand-cream/20 rounded-2xl border border-brand-cream/60 flex flex-col sm:flex-row gap-5 items-center justify-between">
              <div className="flex gap-4 items-center">
                <img 
                  src={partner.logo} 
                  alt={partner.name} 
                  referrerPolicy="no-referrer"
                  className="w-12 h-12 rounded-full object-cover border-2 border-brand-gold bg-stone-100"
                />
                <div>
                  <span className="text-[10px] text-brand-gold-dark font-bold tracking-widest uppercase">PROPOSE PAR L'EXPERT</span>
                  <h4 className="font-serif font-bold text-sm text-stone-900">{partner.name}</h4>
                  <div className="flex items-center gap-1.5 text-[11px] text-stone-500 font-medium">
                    <span className="text-brand-gold">★</span>
                    <span>{partner.rating.toFixed(1)}/5 • {partner.reviewsCount} avis clients</span>
                  </div>
                </div>
              </div>

              <div>
                <button
                  onClick={() => onNavigateToPartner(partner.id)}
                  className="px-4 py-2 border border-brand-green-dark text-brand-green-dark hover:bg-brand-green-dark hover:text-white rounded-xl text-2xs font-bold uppercase tracking-widest transition-all cursor-pointer"
                >
                  Voir son profil
                </button>
              </div>
            </div>

            {/* SOCIAL SHARES & NETWORK SHUNT */}
            <div className="flex items-center justify-between pt-4 border-t border-stone-100">
              <span className="text-xs text-stone-400 font-medium">Partager l'expérience :</span>
              <div className="flex gap-2 relative">
                <button 
                  onClick={handleCopyLink}
                  className="p-2 border border-stone-100 rounded-full hover:bg-stone-50 text-stone-500 hover:text-brand-green-dark transition-all cursor-pointer shadow-sm hover:scale-105"
                  title="Copier le lien"
                >
                  <LucideIcon name="Share2" size={14} />
                </button>
                <button 
                  onClick={shareOnFacebook} 
                  className="w-8 h-8 rounded-full border border-stone-100 flex items-center justify-center text-stone-500 hover:text-[#1877F2] hover:bg-stone-50 transition-all cursor-pointer shadow-sm hover:scale-105"
                  title="Facebook"
                >
                  <span className="text-xs font-bold leading-none uppercase">f</span>
                </button>
                <button 
                  onClick={shareOnTwitter} 
                  className="w-8 h-8 rounded-full border border-stone-100 flex items-center justify-center text-stone-500 hover:text-[#1DA1F2] hover:bg-stone-50 transition-all cursor-pointer shadow-sm hover:scale-105"
                  title="X (Twitter)"
                >
                  <span className="text-xs font-bold leading-none uppercase">t</span>
                </button>
                <button 
                  onClick={shareOnWhatsApp} 
                  className="w-8 h-8 rounded-full border border-stone-100 flex items-center justify-center text-stone-500 hover:text-[#25D366] hover:bg-stone-50 transition-all cursor-pointer shadow-sm hover:scale-105"
                  title="WhatsApp"
                >
                  <span className="text-xs font-bold leading-none uppercase">w</span>
                </button>
                {copySuccess && (
                  <div className="absolute bottom-11 right-0 bg-stone-900 text-white text-[10px] py-1.5 px-3 rounded-xl shadow-lg border border-white/10 whitespace-nowrap animate-fade-in font-bold z-20">
                    Lien copié ! 📋
                  </div>
                )}
              </div>
            </div>

          </div>

          {/* RIGHT SIDE: FLOATING RESERVATION CARD */}
          <div className="lg:col-span-4 select-none">
            
            <div className="bg-white border-2 border-brand-gold rounded-3xl p-6 shadow-xl sticky top-24 space-y-6">
              
              {isBooked ? (
                /* Ticket Success Panel Card */
                <div className="text-center space-y-4 py-4 animate-scale-in">
                  <div className="w-14 h-14 bg-emerald-50 border-2 border-emerald-500 rounded-full flex items-center justify-center mx-auto text-emerald-500 animate-pulse">
                    <LucideIcon name="CheckCircle" size={30} />
                  </div>
                  <div className="space-y-1">
                    <h3 className="font-serif font-bold text-base text-brand-green-dark">RÉSERVATION PRÊTE !</h3>
                    <p className="text-stone-500 text-xs">
                      Votre pass d’accès est sécurisé et disponible dans votre tableau de bord.
                    </p>
                  </div>

                  {/* Stylized local ticket QR visualization code */}
                  <div className="bg-stone-50 border border-stone-100 rounded-xl p-3 flex flex-col items-center justify-center gap-1.5">
                    <div className="w-24 h-24 bg-white border border-stone-200 rounded p-1.5">
                      {/* Grid representation mimicking QR-code */}
                      <div className="grid grid-cols-5 gap-1 w-full h-full opacity-80">
                        {Array.from({ length: 25 }).map((_, i) => (
                          <div 
                            key={i} 
                            className={`rounded-sm ${
                              (i % 3 === 0 || i % 7 === 0 || i < 5 || i > 20) 
                                ? 'bg-stone-800' 
                                : 'bg-transparent'
                            }`} 
                          />
                        ))}
                      </div>
                    </div>
                    <span className="font-mono text-[9px] text-stone-400 font-bold uppercase tracking-widest">
                      REF-{experience.id.toUpperCase()}-{ticketCount}
                    </span>
                  </div>

                  <p className="text-[10px] text-stone-400">
                    Billet électronique généré pour <strong>{ticketCount} voyageur(s)</strong>.
                  </p>
                </div>
              ) : (
                /* Interactive booking widget forms */
                <>
                  <div>
                    <span className="text-[9px] font-bold uppercase tracking-widest text-[#B8860B] bg-amber-50 rounded-full px-2.5 py-1 border border-amber-200">
                      🎟️ TARIF PUBLIC
                    </span>
                    <div className="flex justify-between items-baseline mt-3">
                      <span className="font-serif font-extrabold text-2xl text-brand-green-dark">
                        {experience.price === 0 ? 'Gratuit' : `${experience.price} €`}
                      </span>
                      <span className="text-[10px] text-stone-400 font-semibold font-sans uppercase tracking-widest">
                        par participant
                      </span>
                    </div>
                  </div>

                  {/* Experience Stepper */}
                  <div className="border-t border-b border-stone-100 py-4 space-y-3">
                    <div className="flex justify-between items-center">
                      <div className="space-y-0.5">
                        <span className="text-xs font-bold text-stone-800 uppercase tracking-wide">Places requises</span>
                        <p className="text-[10px] text-stone-400 capitalize">Selon places restantes</p>
                      </div>
                      <div className="flex items-center border border-stone-200 rounded-xl bg-stone-50">
                        <button
                          onClick={() => setTicketCount(prev => Math.max(1, prev - 1))}
                          className="w-8 h-8 flex items-center justify-center font-bold font-sans text-stone-500 hover:text-stone-800 hover:bg-stone-100 transition-colors rounded-l-xl"
                        >
                          -
                        </button>
                        <span className="w-8 text-center text-xs font-bold font-sans text-stone-800">
                          {ticketCount}
                        </span>
                        <button
                          onClick={() => setTicketCount(prev => Math.min(10, prev + 1))}
                          className="w-8 h-8 flex items-center justify-center font-bold font-sans text-stone-500 hover:text-stone-800 hover:bg-stone-100 transition-colors rounded-r-xl"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    <div className="flex justify-between text-xs font-serif text-stone-600 font-bold">
                      <span>Total à régler :</span>
                      <span className="text-brand-green-dark font-sans text-sm font-semibold">
                        {experience.price === 0 ? '0,00 €' : `${totalPrice} €`}
                      </span>
                    </div>
                  </div>

                  {/* Submit Order action */}
                  <button
                    onClick={handleBookingSubmit}
                    disabled={loadingBooking}
                    className="w-full py-4 bg-brand-green-dark hover:bg-brand-green-med text-brand-cream border border-brand-gold hover:border-brand-cream font-sans font-extrabold text-xs uppercase tracking-widest rounded-2xl shadow-xl transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {loadingBooking ? (
                      <>
                        <div className="w-4 h-4 border-2 border-stone-400 border-t-white rounded-full animate-spin" />
                        <span>Transmission...</span>
                      </>
                    ) : (
                      <>
                        <LucideIcon name="CheckCircle" size={14} /> Réserver maintenant
                      </>
                    )}
                  </button>

                  {/* Cancel Booking option if existing booking exists */}
                  {isAuthenticated && existingBooking && (
                    <button
                      onClick={() => handleCancelBookingSubmit(existingBooking.id)}
                      className="w-full py-3.5 bg-red-50 hover:bg-red-100/80 text-red-700 hover:text-red-800 border border-red-200 hover:border-red-300 font-sans font-bold text-xs uppercase tracking-wider rounded-2xl shadow-md transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <LucideIcon name="XCircle" size={14} className="text-red-600" /> Annuler la réservation
                    </button>
                  )}

                  <div className="space-y-2 p-3.5 bg-[#E9E6D5]/20 border border-stone-150 rounded-2xl text-center">
                    <span className="text-[9px] uppercase tracking-wider font-extrabold text-brand-green-dark block">
                      💯 SÉCURITÉ GARANTIE
                    </span>
                    <p className="text-[10px] text-stone-600 leading-normal">
                      Aucun prépaiement requis sur de nombreuses formules créées par nos experts professionnels agréés.
                    </p>
                  </div>
                </>
              )}

            </div>
          </div>

        </div>
      </div>

      {/* 3. SIMILAR EXPERIENCES BLOCK FOOTER */}
      {similarExperiences.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-24 space-y-6">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-6 bg-brand-gold rounded-full" />
            <h2 className="font-serif text-2xl font-bold tracking-wide text-stone-800">EXPÉRIENCES SIMILAIRES</h2>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {similarExperiences.map(similar => (
              <ExperienceCard
                key={similar.id}
                experience={similar}
                isFavorited={favorites.includes(similar.id)}
                onToggleFavorite={onToggleFavorite}
                onClick={onSelectExperience}
              />
            ))}
          </div>
        </section>
      )}

      {/* 4. IMMERSIVE LUXURY SHARING PANEL */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16 md:mt-24">
        <div className="relative py-12 px-6 md:px-12 bg-gradient-to-br from-brand-midnight to-stone-950 rounded-[2.5rem] border border-brand-gold/25 shadow-2xl overflow-hidden text-center space-y-8 select-none">
          {/* Subtle luxurious background radial highlight */}
          <div className="absolute inset-x-0 top-0 h-[1px] bg-gradient-to-r from-transparent via-brand-gold/30 to-transparent pointer-events-none" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(197,160,89,0.06),transparent_60%)] pointer-events-none" />

          <div className="max-w-2xl mx-auto space-y-3">
            <span className="text-[10px] md:text-xs font-mono font-bold tracking-widest text-brand-gold uppercase block">
              Faire découvrir l'Exceptionnel
            </span>
            <h3 className="font-serif text-2xl md:text-3xl font-extrabold text-[#E9E6D5] tracking-wide">
              Partager cette fabuleuse expérience
            </h3>
            <p className="text-xs md:text-sm text-stone-300 font-sans tracking-wide leading-relaxed font-light">
              Envoyez cette idée d'évasion d’exception à vos proches pour planifier ensemble vos prochains moments d’harmonie locale.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-xl mx-auto">
            {/* Copy link option card */}
            <div className="w-full relative">
              <button
                onClick={handleCopyLink}
                className="w-full flex items-center justify-between gap-3 px-5 py-4 bg-white/5 hover:bg-white/10 text-[#E9E6D5] rounded-2xl border border-white/10 hover:border-brand-gold/40 transition-all duration-300 shadow cursor-pointer group"
              >
                <div className="flex items-center gap-3 truncate text-left">
                  <div className="w-8 h-8 rounded-full bg-brand-gold/15 flex items-center justify-center text-brand-gold shrink-0">
                    <Link size={14} className="stroke-[2.5]" />
                  </div>
                  <span className="text-xs font-mono truncate max-w-[180px] sm:max-w-[240px]">
                    {shareUrl}
                  </span>
                </div>
                
                <span className="text-[10px] uppercase tracking-wider font-extrabold text-brand-gold group-hover:text-[#E9E6D5] shrink-0 transition-colors">
                  Copier
                </span>
              </button>

              {/* Toast confirmation feedback block */}
              {copySuccess && (
                <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-brand-gold text-brand-midnight text-[11px] font-sans font-bold uppercase tracking-widest shadow-xl py-2 px-4 rounded-xl border border-brand-gold/30 animate-scale-in z-25 flex items-center gap-1.5 whitespace-nowrap">
                  <span>✨ Lien copié dans le presse-papier !</span>
                </div>
              )}
            </div>

            {/* Social handles list links */}
            <div className="flex items-center gap-3 w-full sm:w-auto shrink-0 justify-center">
              
              <button
                onClick={shareOnFacebook}
                className="w-12 h-12 rounded-2xl bg-white/5 hover:bg-[#1877F2] text-[#E9E6D5] hover:text-white border border-white/10 hover:border-transparent flex items-center justify-center hover:scale-105 hover:-translate-y-0.5 transition-all duration-300 cursor-pointer shadow-lg"
                title="Partager sur Facebook"
              >
                <Facebook size={18} className="stroke-[1.8]" />
              </button>

              <button
                onClick={shareOnTwitter}
                className="w-12 h-12 rounded-2xl bg-white/5 hover:bg-[#1DA1F2] text-[#E9E6D5] hover:text-white border border-white/10 hover:border-transparent flex items-center justify-center hover:scale-105 hover:-translate-y-0.5 transition-all duration-300 cursor-pointer shadow-lg"
                title="Partager sur X (Twitter)"
              >
                <Twitter size={18} className="stroke-[1.8]" />
              </button>

              <button
                onClick={shareOnWhatsApp}
                className="w-12 h-12 rounded-2xl bg-white/5 hover:bg-[#25D366] text-[#E9E6D5] hover:text-white border border-white/10 hover:border-transparent flex items-center justify-center hover:scale-105 hover:-translate-y-0.5 transition-all duration-300 cursor-pointer shadow-lg"
                title="Partager sur WhatsApp"
              >
                <MessageCircle size={18} className="stroke-[1.8]" />
              </button>

            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
