import React, { useState, useRef } from 'react';
import { categories, experiences } from '../data/mockData';
import { Experience, CategoryId, ActivePage } from '../types';
import { LucideIcon } from '../components/LucideIcon';
import { ExperienceCard } from '../components/ExperienceCard';
import { InteractiveMap } from '../components/InteractiveMap';

interface HomeViewProps {
  onNavigate: (page: ActivePage) => void;
  onSelectExperience: (experience: Experience) => void;
  onSelectCategory: (catId: CategoryId) => void;
  favorites: string[];
  onToggleFavorite: (e: React.MouseEvent, id: string) => void;
  setSearchFilters: (filters: { city: string; category: string; date: string }) => void;
}

export function HomeView({
  onNavigate,
  onSelectExperience,
  onSelectCategory,
  favorites,
  onToggleFavorite,
  setSearchFilters
}: HomeViewProps) {
  const [searchCity, setSearchCity] = useState('');
  const [searchCategory, setSearchCategory] = useState('');
  const [searchDate, setSearchDate] = useState('');
  const [activeMapExp, setActiveMapExp] = useState<Experience | null>(null);

  // In-line interactive filters for today's experiences
  const [todayPriceFilter, setTodayPriceFilter] = useState<number>(200);
  const [todayDistanceFilter, setTodayDistanceFilter] = useState<number>(50);
  const [todayFreeOnly, setTodayFreeOnly] = useState<boolean>(false);

  // Map interactive filters (Defaults to today's experiences with sliders)
  const [mapPriceFilter, setMapPriceFilter] = useState<number>(200);
  const [mapDistanceFilter, setMapDistanceFilter] = useState<number>(50);
  const [mapTodayOnly, setMapTodayOnly] = useState<boolean>(true);

  const mapSectionRef = useRef<HTMLDivElement>(null);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchFilters({
      city: searchCity,
      category: searchCategory,
      date: searchDate
    });
    onNavigate('explorer');
  };

  const scrollToMap = () => {
    mapSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
    if (experiences.length > 0) {
      setActiveMapExp(experiences[0]);
    }
  };

  // Map Filterings
  const todayExps = experiences.filter(e => 
    e.isToday && 
    e.price <= todayPriceFilter && 
    e.distance <= todayDistanceFilter &&
    (!todayFreeOnly || e.price === 0)
  );

  const filteredMapExps = experiences.filter(e => {
    const matchesToday = !mapTodayOnly || e.isToday;
    const matchesPrice = e.price <= mapPriceFilter;
    const matchesDistance = e.distance <= mapDistanceFilter;
    return matchesToday && matchesPrice && matchesDistance;
  });
  const weekendExps = experiences.filter(e => e.isWeekend);
  const recommendedExps = experiences.filter(e => e.isRecommended);
  const freeExps = experiences.filter(e => e.price === 0);
  const nearbyExps = [...experiences].sort((a, b) => a.distance - b.distance);

  return (
    <div className="space-y-16 pb-24">
      
      {/* 1. HERO SECTION */}
      <section className="relative h-[90vh] md:h-[80vh] flex items-center justify-center bg-brand-midnight overflow-hidden">
        {/* Fullscreen background with rich overlay */}
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-70 scale-102 transition-transform duration-10000"
          style={{ backgroundImage: `url('https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1920&q=85')` }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-brand-midnight via-brand-midnight/40 to-brand-midnight/60" />

        <div className="relative z-10 max-w-5xl mx-auto px-4 text-center space-y-8 animate-fade-in">
          
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-400/20 border border-brand-gold/50 rounded-full">
            <span className="w-2 h-2 bg-brand-gold rounded-full animate-ping" />
            <span className="font-sans font-semibold text-[10px] uppercase tracking-widest text-[#E9E6D5]">
              L'art de vivre local, simplifié
            </span>
          </div>

          <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl font-extrabold text-[#E9E6D5] tracking-tight leading-none drop-shadow-sm">
            Que faire autour de vous <span className="text-brand-gold">aujourd'hui ?</span>
          </h1>
          
          <p className="font-sans text-stone-200 text-sm sm:text-base md:text-lg max-w-2xl mx-auto font-light leading-relaxed">
            Découvrez des ateliers confidentiels, des soins holistiques, des pépites culturelles et des sensations extérieures d’exception.
          </p>

          {/* Moteur de Recherche */}
          <form 
            onSubmit={handleSearchSubmit} 
            className="bg-white/95 backdrop-blur rounded-3xl p-4 sm:p-6 shadow-2xl border border-stone-200/80 max-w-4xl mx-auto grid grid-cols-1 sm:grid-cols-4 gap-3 items-center text-left"
          >
            {/* Ville */}
            <div className="space-y-1">
              <label className="block text-[9px] font-bold uppercase tracking-wider text-brand-green-dark p-0.5">Villes</label>
              <div className="flex items-center gap-2 border-b border-stone-100 pb-1.5 focus-within:border-brand-green-med transition-colors">
                <LucideIcon name="MapPin" size={14} className="text-brand-gold-dark" />
                <select 
                  value={searchCity} 
                  onChange={(e) => setSearchCity(e.target.value)}
                  className="bg-transparent w-full outline-none text-xs font-semibold text-stone-800"
                >
                  <option value="">Toute la France</option>
                  <option value="Paris">Paris</option>
                  <option value="Lyon">Lyon</option>
                  <option value="Marseille">Marseille</option>
                  <option value="Bordeaux">Bordeaux</option>
                  <option value="Nantes">Nantes</option>
                  <option value="Lille">Lille</option>
                </select>
              </div>
            </div>

            {/* Catégorie */}
            <div className="space-y-1">
              <label className="block text-[9px] font-bold uppercase tracking-wider text-brand-green-dark p-0.5">Expériences</label>
              <div className="flex items-center gap-2 border-b border-stone-100 pb-1.5 focus-within:border-brand-green-med transition-colors">
                <LucideIcon name="Compass" size={14} className="text-brand-gold-dark" />
                <select 
                  value={searchCategory} 
                  onChange={(e) => setSearchCategory(e.target.value)}
                  className="bg-transparent w-full outline-none text-xs font-semibold text-stone-800"
                >
                  <option value="">Tous les thèmes</option>
                  {categories.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Date */}
            <div className="space-y-1">
              <label className="block text-[9px] font-bold uppercase tracking-wider text-brand-green-dark p-0.5">Dates</label>
              <div className="flex items-center gap-2 border-b border-stone-100 pb-1.5 focus-within:border-brand-green-med transition-colors">
                <LucideIcon name="Calendar" size={14} className="text-brand-gold-dark" />
                <input 
                  type="date" 
                  value={searchDate}
                  onChange={(e) => setSearchDate(e.target.value)}
                  className="bg-transparent w-full outline-none text-xs font-semibold text-stone-800 focus:ring-0 [&::-webkit-calendar-picker-indicator]:opacity-70"
                />
              </div>
            </div>

            {/* Submit Button */}
            <div>
              <button 
                type="submit"
                className="w-full bg-brand-green-dark hover:bg-brand-green-med text-brand-cream py-3.5 px-4 rounded-2xl font-sans font-bold text-xs uppercase tracking-widest shadow-md transition-all duration-300 border border-brand-gold flex items-center justify-center gap-2 cursor-pointer hover:shadow-lg"
              >
                <LucideIcon name="Search" size={14} /> Rechercher
              </button>
            </div>
          </form>

          {/* Quick Geoloc around me button */}
          <div className="pt-2">
            <button 
              onClick={scrollToMap}
              className="inline-flex items-center gap-2 px-6 py-3 border border-[#E9E6D5]/40 hover:border-brand-gold bg-white/10 hover:bg-white/20 text-brand-cream hover:text-white rounded-full text-xs font-sans font-bold uppercase tracking-widest transition-all shadow duration-300 backdrop-blur cursor-pointer"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              Explorer autour de moi 🧭
            </button>
          </div>

        </div>
      </section>

      {/* 2. DYNAMIC HORIZONTAL SWIPE GRIDS SECTIONS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Row 1: Aujourd'hui */}
        <div>
          <div className="flex justify-between items-end mb-6">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-6 bg-red-500 rounded-full" />
                <h2 className="font-serif text-2xl font-bold tracking-wide text-brand-green-dark">Aujourd'hui</h2>
              </div>
              <p className="text-xs text-stone-500 font-sans mt-0.5">Sessions de dernière minute à vivre dans la journée.</p>
            </div>
            <button onClick={() => onNavigate('explorer')} className="text-xs font-semibold text-brand-green-med hover:text-brand-green-dark flex items-center gap-1 hover:underline">
              Tout voir <LucideIcon name="ChevronRight" size={14} />
            </button>
          </div>

          {/* Interactive Filters Area */}
          <div className="mb-6 px-5 py-4 bg-white/60 backdrop-blur-md rounded-2xl border border-stone-200/50 shadow-sm flex flex-col md:flex-row items-stretch md:items-center gap-4 sm:gap-6 justify-between transition-all">
            
            {/* Left header: Info Icon + text */}
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-brand-green-dark/10 flex items-center justify-center text-brand-green-dark shrink-0">
                <LucideIcon name="Filter" size={14} className="text-brand-green-dark" />
              </div>
              <div className="text-left">
                <h4 className="font-sans font-bold text-xs uppercase tracking-wider text-stone-800">
                  Filtres de l'instant
                </h4>
                <p className="text-[10px] text-stone-500 font-sans">
                  Ajustez selon vos envies immédiates
                </p>
              </div>
            </div>

            {/* Middle: Slider controls and Free toggle */}
            <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 flex-1 max-w-3xl items-stretch sm:items-center">
              
              {/* Slider 1: Price */}
              <div className="flex-1 space-y-1.5 text-left">
                <div className="flex justify-between items-center">
                  <span className="text-[11px] font-semibold text-stone-600 flex items-center gap-1">
                    <LucideIcon name="DollarSign" size={12} className="text-stone-400" />
                    Budget maximum
                  </span>
                  <span className="text-xs font-mono font-bold text-brand-green-dark">
                    {todayPriceFilter === 0 ? (
                      <span className="text-emerald-700 uppercase text-[9px] tracking-wider font-extrabold bg-emerald-50 px-2 py-0.5 rounded">Gratuit</span>
                    ) : todayPriceFilter === 200 ? (
                      'Illimité'
                    ) : (
                      `${todayPriceFilter} €`
                    )}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-[10px] text-stone-400 font-medium">0€</span>
                  <input
                    type="range"
                    min="0"
                    max="200"
                    step="5"
                    disabled={todayFreeOnly}
                    value={todayFreeOnly ? 0 : todayPriceFilter}
                    onChange={(e) => setTodayPriceFilter(Number(e.target.value))}
                    className="w-full h-1 bg-stone-200 rounded-lg appearance-none cursor-pointer focus:outline-none accent-brand-gold disabled:opacity-50"
                  />
                  <span className="text-[10px] text-stone-400 font-medium">200€+</span>
                </div>
              </div>

              {/* Slider 2: Distance */}
              <div className="flex-1 space-y-1.5 text-left">
                <div className="flex justify-between items-center">
                  <span className="text-[11px] font-semibold text-stone-600 flex items-center gap-1">
                    <LucideIcon name="Compass" size={12} className="text-stone-400" />
                    Distance maximale
                  </span>
                  <span className="text-xs font-mono font-bold text-brand-green-dark">
                    {todayDistanceFilter === 50 ? 'Illimité' : `${todayDistanceFilter} km`}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-[10px] text-stone-400 font-medium">1km</span>
                  <input
                    type="range"
                    min="1"
                    max="50"
                    step="1"
                    value={todayDistanceFilter}
                    onChange={(e) => setTodayDistanceFilter(Number(e.target.value))}
                    className="w-full h-1 bg-stone-200 rounded-lg appearance-none cursor-pointer focus:outline-none accent-brand-gold"
                  />
                  <span className="text-[10px] text-stone-400 font-medium">50km+</span>
                </div>
              </div>

              {/* Filter 3: Free Only */}
              <div className="sm:w-[150px] space-y-1.5 text-left shrink-0">
                <span className="text-[11px] font-semibold text-stone-600 flex items-center gap-1">
                  <LucideIcon name="Sparkles" size={12} className="text-emerald-500 animate-pulse" />
                  Tarif spécial
                </span>
                <button
                  type="button"
                  onClick={() => setTodayFreeOnly(!todayFreeOnly)}
                  className={`w-full flex items-center justify-between gap-2 px-3 py-1.5 rounded-xl text-xs font-sans font-bold transition-all border cursor-pointer select-none ${
                    todayFreeOnly
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-300 shadow-sm'
                      : 'bg-white text-stone-600 border-stone-200/80 hover:bg-stone-50'
                  }`}
                >
                  <span className="text-[11px] sm:text-xs">Gratuit uniquement</span>
                  <div className={`w-3.5 h-3.5 rounded-full flex items-center justify-center border transition-all ${
                    todayFreeOnly ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-stone-300'
                  }`}>
                    {todayFreeOnly && <LucideIcon name="Check" size={10} className="stroke-[3]" />}
                  </div>
                </button>
              </div>

            </div>

            {/* Right: Reset Button and filtered counts (only shown if filters are custom) */}
            <div className="flex items-center justify-end shrink-0 gap-3">
              <span className="text-[10px] sm:text-xs font-mono font-bold text-brand-green-dark bg-brand-green-dark/5 px-2.5 py-1 rounded-xl border border-brand-green-dark/10 select-none">
                {todayExps.length} {todayExps.length > 1 ? 'sessions' : 'session'}
              </span>
              {(todayPriceFilter < 200 || todayDistanceFilter < 50 || todayFreeOnly) ? (
                <button
                  onClick={() => {
                    setTodayPriceFilter(200);
                    setTodayDistanceFilter(50);
                    setTodayFreeOnly(false);
                  }}
                  className="inline-flex items-center gap-1 px-3 py-1.5 bg-stone-100 hover:bg-stone-200/80 rounded-xl text-[11px] font-sans font-bold text-stone-600 hover:text-stone-800 border border-stone-200 transition-all cursor-pointer shadow-sm animate-fade-in"
                >
                  <LucideIcon name="X" size={10} className="text-stone-400" />
                  Effacer
                </button>
              ) : (
                <span className="hidden md:inline-block text-[11px] text-stone-400 italic font-medium">
                  Aucun filtre actif
                </span>
              )}
            </div>

          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {todayExps.length === 0 ? (
              <div className="col-span-full py-14 px-6 rounded-[2rem] bg-[#E9E6D5]/10 border border-stone-200/80 text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-brand-cream/40 flex items-center justify-center text-brand-gold-dark mx-auto border border-brand-gold/15">
                  <LucideIcon name="Compass" size={20} />
                </div>
                <div className="space-y-1">
                  <p className="font-serif text-lg font-bold text-brand-green-dark">Aucune expérience trouvée</p>
                  <p className="text-xs text-stone-500 max-w-sm mx-auto font-sans">
                    Essayez d'ajuster le budget ou d'augmenter la distance pour découvrir d'autres sessions aujourd'hui.
                  </p>
                </div>
                <button
                  onClick={() => {
                    setTodayPriceFilter(200);
                    setTodayDistanceFilter(50);
                    setTodayFreeOnly(false);
                  }}
                  className="inline-flex items-center gap-1 px-5 py-2.5 bg-brand-green-dark hover:bg-brand-green-med text-brand-cream text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-md hover:shadow-lg border border-brand-gold cursor-pointer"
                >
                  Tout réinitialiser
                </button>
              </div>
            ) : (
              todayExps.slice(0, 4).map(exp => (
                <ExperienceCard 
                  key={exp.id} 
                  experience={exp} 
                  isFavorited={favorites.includes(exp.id)} 
                  onToggleFavorite={onToggleFavorite}
                  onClick={onSelectExperience}
                />
              ))
            )}
          </div>
        </div>

        {/* Row 2: Ce weekend */}
        <div>
          <div className="flex justify-between items-end mb-6">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-6 bg-indigo-500 rounded-full" />
                <h2 className="font-serif text-2xl font-bold tracking-wide text-brand-green-dark">Ce week-end</h2>
              </div>
              <p className="text-xs text-stone-500 font-sans mt-0.5">Planifiez des parenthèses inoubliables pour samedi & dimanche.</p>
            </div>
            <button onClick={() => { setSearchFilters({ city: '', category: '', date: '2026-05-23' }); onNavigate('explorer'); }} className="text-xs font-semibold text-brand-green-med hover:text-brand-green-dark flex items-center gap-1 hover:underline">
              Tout voir <LucideIcon name="ChevronRight" size={14} />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {weekendExps.slice(0, 4).map(exp => (
              <ExperienceCard 
                key={exp.id} 
                experience={exp} 
                isFavorited={favorites.includes(exp.id)} 
                onToggleFavorite={onToggleFavorite}
                onClick={onSelectExperience}
              />
            ))}
          </div>
        </div>

        {/* Row 3: Recommandé */}
        <div>
          <div className="flex justify-between items-end mb-6">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-6 bg-brand-gold rounded-full" />
                <h2 className="font-serif text-2xl font-bold tracking-wide text-brand-green-dark">Recommandé</h2>
              </div>
              <p className="text-xs text-stone-500 font-sans mt-0.5">Les expériences plébiscitées et d'excellence validées par notre communauté.</p>
            </div>
            <button onClick={() => onNavigate('explorer')} className="text-xs font-semibold text-brand-green-med hover:text-brand-green-dark flex items-center gap-1 hover:underline">
              Tout voir <LucideIcon name="ChevronRight" size={14} />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {recommendedExps.slice(0, 4).map(exp => (
              <ExperienceCard 
                key={exp.id} 
                experience={exp} 
                isFavorited={favorites.includes(exp.id)} 
                onToggleFavorite={onToggleFavorite}
                onClick={onSelectExperience}
              />
            ))}
          </div>
        </div>

      </section>

      {/* 3. INTERACTIVE MAP SECTION WITH DESKTOP DENSITY */}
      <section ref={mapSectionRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-6 bg-brand-green-dark rounded-full" />
              <h2 className="font-serif text-2xl font-bold tracking-wide text-brand-green-dark">Carte Interactive des Activités</h2>
            </div>
            <p className="text-xs text-stone-500 font-sans mt-0.5">Explorez géographiquement les expériences et partenaires à proximité.</p>
          </div>

          {/* Today Only Toggle pill */}
          <div className="flex items-center gap-2 bg-stone-100 p-1 rounded-xl self-start md:self-auto border border-stone-200/40">
            <button
              onClick={() => setMapTodayOnly(true)}
              className={`px-3 py-1.5 rounded-lg text-xs font-sans font-bold transition-all flex items-center gap-1 cursor-pointer ${
                mapTodayOnly 
                  ? 'bg-brand-green-dark text-brand-cream shadow-sm' 
                  : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
              Aujourd'hui
            </button>
            <button
              onClick={() => setMapTodayOnly(false)}
              className={`px-3 py-1.5 rounded-lg text-xs font-sans font-bold transition-all flex items-center gap-1 cursor-pointer ${
                !mapTodayOnly 
                  ? 'bg-brand-green-dark text-brand-cream shadow-sm' 
                  : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              Toutes les dates
            </button>
          </div>
        </div>

        {/* Map Filters Bar */}
        <div className="px-5 py-4 bg-white/70 backdrop-blur-md rounded-2xl border border-stone-200/50 shadow-sm flex flex-col lg:flex-row items-stretch lg:items-center gap-4 lg:gap-8 justify-between transition-all">
          {/* Left info segment */}
          <div className="flex items-center gap-2.5 shrink-0">
            <div className="w-8 h-8 rounded-full bg-brand-gold/15 flex items-center justify-center text-brand-gold-dark shrink-0">
              <LucideIcon name="MapPin" size={14} className="text-brand-gold-dark" />
            </div>
            <div className="text-left">
              <h4 className="font-sans font-bold text-xs uppercase tracking-wider text-stone-800">
                Filtres de la carte
              </h4>
              <p className="text-[10px] text-stone-500 font-sans">
                {mapTodayOnly ? "Filtré sur aujourd'hui" : "Toutes les sessions de la carte"}
              </p>
            </div>
          </div>

          {/* Core Controls */}
          <div className="flex flex-col sm:flex-row gap-4 sm:gap-8 flex-1 max-w-3xl">
            {/* Slider: Price */}
            <div className="flex-1 space-y-1.5 text-left">
              <div className="flex justify-between items-center">
                <span className="text-[11px] font-semibold text-stone-600 flex items-center gap-1">
                  <LucideIcon name="DollarSign" size={12} className="text-stone-400" />
                  Prix maximum
                </span>
                <span className="text-xs font-mono font-bold text-brand-green-dark">
                  {mapPriceFilter === 0 ? (
                    <span className="text-emerald-700 uppercase text-[9px] tracking-wider font-extrabold bg-emerald-50 px-2 py-0.5 rounded">Gratuit</span>
                  ) : mapPriceFilter === 200 ? (
                    'Illimité'
                  ) : (
                    `${mapPriceFilter} €`
                  )}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-[10px] text-stone-400 font-medium">0€</span>
                <input
                  type="range"
                  min="0"
                  max="200"
                  step="5"
                  value={mapPriceFilter}
                  onChange={(e) => setMapPriceFilter(Number(e.target.value))}
                  className="w-full h-1 bg-stone-200 rounded-lg appearance-none cursor-pointer focus:outline-none accent-brand-gold"
                />
                <span className="text-[10px] text-stone-400 font-medium">200€+</span>
              </div>
            </div>

            {/* Slider: Distance */}
            <div className="flex-1 space-y-1.5 text-left">
              <div className="flex justify-between items-center">
                <span className="text-[11px] font-semibold text-stone-600 flex items-center gap-1">
                  <LucideIcon name="Compass" size={12} className="text-stone-400" />
                  Distance maximum
                </span>
                <span className="text-xs font-mono font-bold text-brand-green-dark">
                  {mapDistanceFilter === 50 ? 'Illimité' : `${mapDistanceFilter} km`}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-[10px] text-stone-400 font-medium">1km</span>
                <input
                  type="range"
                  min="1"
                  max="50"
                  step="1"
                  value={mapDistanceFilter}
                  onChange={(e) => setMapDistanceFilter(Number(e.target.value))}
                  className="w-full h-1 bg-stone-200 rounded-lg appearance-none cursor-pointer focus:outline-none accent-brand-gold"
                />
                <span className="text-[10px] text-stone-400 font-medium">50km+</span>
              </div>
            </div>
          </div>

          {/* Right actions */}
          <div className="flex items-center justify-end shrink-0 gap-3">
            <span className="text-[10px] font-mono text-stone-500 bg-stone-100 px-2 py-1 rounded-lg">
              {filteredMapExps.length} {filteredMapExps.length > 1 ? 'activités' : 'activité'}
            </span>
            {(mapPriceFilter < 200 || mapDistanceFilter < 50 || !mapTodayOnly) ? (
              <button
                onClick={() => {
                  setMapPriceFilter(200);
                  setMapDistanceFilter(50);
                  setMapTodayOnly(true);
                }}
                className="inline-flex items-center gap-1 px-3 py-1.5 bg-stone-100 hover:bg-stone-200/80 rounded-xl text-[11px] font-sans font-bold text-stone-600 hover:text-stone-800 border border-stone-200 transition-all cursor-pointer shadow-sm shrink-0"
              >
                <LucideIcon name="X" size={10} className="text-stone-400" />
                Effacer
              </button>
            ) : null}
          </div>
        </div>
        
        <InteractiveMap 
          experiences={filteredMapExps} 
          selectedExperience={activeMapExp} 
          onSelectExperience={(exp) => {
            setActiveMapExp(exp);
            // Optionally auto detail
          }}
          className="h-[500px]"
        />
      </section>

      {/* Row 4: Gratuit & Autour de vous */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-2 gap-12 pt-4">
        
        {/* Row Left: Gratuit */}
        <div className="space-y-6">
          <div className="flex justify-between items-end">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-6 bg-emerald-500 rounded-full" />
                <h2 className="font-serif text-xl font-bold text-brand-green-dark">Sélection Gratuite</h2>
              </div>
              <p className="text-xs text-stone-500 font-sans mt-0.5">Des découvertes locales offertes gratuites et solidaires.</p>
            </div>
            <button onClick={() => onNavigate('explorer')} className="text-xs font-semibold text-brand-green-med hover:text-brand-green-dark flex items-center gap-0.5 hover:underline">
              Voir tout <LucideIcon name="ChevronRight" size={14} />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {freeExps.slice(0, 2).map(exp => (
              <ExperienceCard 
                key={exp.id} 
                experience={exp} 
                isFavorited={favorites.includes(exp.id)} 
                onToggleFavorite={onToggleFavorite}
                onClick={onSelectExperience}
              />
            ))}
          </div>
        </div>

        {/* Row Right: Autour de vous */}
        <div className="space-y-6">
          <div className="flex justify-between items-end">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-6 bg-sky-500 rounded-full" />
                <h2 className="font-serif text-xl font-bold text-brand-green-dark">Autour de vous 🧭</h2>
              </div>
              <p className="text-xs text-stone-500 font-sans mt-0.5">Triées par distance absolue de votre position GPS.</p>
            </div>
            <button onClick={scrollToMap} className="text-xs font-semibold text-brand-green-med hover:text-brand-green-dark flex items-center gap-0.5 hover:underline">
              Sur la carte <LucideIcon name="ChevronRight" size={14} />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {nearbyExps.slice(0, 2).map(exp => (
              <ExperienceCard 
                key={exp.id} 
                experience={exp} 
                isFavorited={favorites.includes(exp.id)} 
                onToggleFavorite={onToggleFavorite}
                onClick={onSelectExperience}
              />
            ))}
          </div>
        </div>

      </section>

      {/* 4. SECTION 7 SPHERES */}
      <section className="bg-brand-cream/30 py-20 border-t border-b border-stone-200/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-14">
          
          <div className="text-center space-y-3">
            <span className="text-[10px] sm:text-xs font-mono font-bold tracking-widest text-brand-gold-dark uppercase block">
              Catégories & Domaines d'exploration
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-extrabold tracking-wide text-brand-green-dark">
              Les 7 Grandes Sphères d'Harmonie
            </h2>
            <p className="font-sans text-stone-500 text-sm max-w-2xl mx-auto font-light leading-relaxed">
              Explorez le tissu d’expériences locales confidentielles et d’exception, classées par domaines d’éveil et de bien-être.
            </p>
            <div className="w-16 h-[2px] bg-brand-gold mx-auto" />
          </div>

          <div className="grid grid-cols-12 gap-6 md:gap-8">
            {categories.map((cat, idx) => {
              // Mathematical layout helper for the 7 items (3 in first row, 4 in second row on high resolution resolution)
              const colSpanClass = 
                idx < 3
                  ? "col-span-12 md:col-span-6 lg:col-span-4" 
                  : idx < 6
                    ? "col-span-12 md:col-span-6 lg:col-span-3"
                    : "col-span-12 md:col-span-12 lg:col-span-3";

              return (
                <div 
                  key={cat.id}
                  onClick={() => onSelectCategory(cat.id)}
                  className={`${colSpanClass} group relative h-[440px] rounded-[2.5rem] overflow-hidden border border-stone-200/70 shadow-lg cursor-pointer hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 ease-out`}
                >
                  {/* Immersive Image with smooth transition zoom */}
                  <div 
                    className="absolute inset-0 bg-cover bg-center brightness-[0.70] group-hover:brightness-[0.62] group-hover:scale-108 transition-all duration-1000 ease-out"
                    style={{ backgroundImage: `url('${cat.image}')` }}
                  />
                  
                  {/* Absolute subtle visual overlays for high contrast and readability */}
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/45 to-transparent duration-500" />
                  <div className="absolute inset-0 border border-white/10 rounded-[2.5rem] m-4 pointer-events-none group-hover:border-brand-gold/30 transition-colors duration-500" />

                  {/* Inside content structured layout alignment */}
                  <div className="absolute inset-0 p-8 flex flex-col justify-between text-[#E9E6D5] z-10">
                    
                    {/* Top segment: Custom Stylized Circle encapsulating the category's Lucide symbol */}
                    <div className="w-12 h-12 rounded-full bg-brand-green-dark/85 backdrop-blur-md border border-brand-gold/40 flex items-center justify-center text-[#E9E6D5] group-hover:scale-110 group-hover:bg-brand-green-dark group-hover:border-brand-gold transition-all duration-500 shadow-md">
                      <LucideIcon name={cat.icon} size={20} className="stroke-[1.8]" />
                    </div>

                    {/* Bottom segment: Text explanations & CTA button details */}
                    <div className="space-y-3">
                      <h3 className="font-serif text-2xl font-bold tracking-tight leading-snug drop-shadow-sm group-hover:text-white transition-colors duration-300">
                        {cat.name}
                      </h3>
                      <p className="text-[11.5px] text-stone-200/90 font-sans leading-relaxed line-clamp-3">
                        {cat.description}
                      </p>
                      
                      {/* Premium Interactive Hover CTA button element */}
                      <div className="pt-2 flex">
                        <div className="inline-flex items-center gap-2 text-brand-gold text-xs font-bold uppercase tracking-widest bg-white/10 group-hover:bg-brand-gold group-hover:text-brand-midnight group-hover:shadow px-5 py-2.5 rounded-full border border-brand-gold/40 group-hover:border-brand-gold transition-all duration-300">
                          <span>Découvrir</span>
                          <LucideIcon name="ArrowRight" size={13} className="group-hover:translate-x-1.5 transition-transform" />
                        </div>
                      </div>
                    </div>

                  </div>

                </div>
              );
            })}
          </div>

        </div>
      </section>

    </div>
  );
}
