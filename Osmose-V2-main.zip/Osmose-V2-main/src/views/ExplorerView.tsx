import React, { useState, useMemo } from 'react';
import { categories, experiences } from '../data/mockData';
import { Experience, CategoryId } from '../types';
import { LucideIcon } from '../components/LucideIcon';
import { ExperienceCard } from '../components/ExperienceCard';
import { InteractiveMap } from '../components/InteractiveMap';

interface ExplorerViewProps {
  onSelectExperience: (experience: Experience) => void;
  favorites: string[];
  onToggleFavorite: (e: React.MouseEvent, id: string) => void;
  initialFilters?: { city: string; category: string; date: string };
  onClearInitialFilters?: () => void;
}

export function ExplorerView({
  onSelectExperience,
  favorites,
  onToggleFavorite,
  initialFilters,
  onClearInitialFilters
}: ExplorerViewProps) {
  // Sticky Filter States
  const [selectedCity, setSelectedCity] = useState(initialFilters?.city || '');
  const [selectedCategory, setSelectedCategory] = useState<string>(initialFilters?.category || '');
  const [minPrice, setMinPrice] = useState<number>(0);
  const [maxPrice, setMaxPrice] = useState<number>(300);
  const [maxDistance, setMaxDistance] = useState<number>(50);
  const [selectedDate, setSelectedDate] = useState<string>(initialFilters?.date || '');
  const [searchKeyword, setSearchKeyword] = useState<string>('');

  // Splot layout views
  const [viewMode, setViewMode] = useState<'both' | 'list' | 'map'>('both');
  
  // Infinite scroll simulation state
  const [visibleCount, setVisibleCount] = useState(6);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);

  const handleResetFilters = () => {
    setSelectedCity('');
    setSelectedCategory('');
    setMinPrice(0);
    setMaxPrice(300);
    setMaxDistance(50);
    setSelectedDate('');
    setSearchKeyword('');
    if (onClearInitialFilters) {
      onClearInitialFilters();
    }
  };

  // Live client-side computing of query filters
  const filteredExperiences = useMemo(() => {
    return experiences.filter(exp => {
      // 1. Keyword search (case-insensitive)
      if (searchKeyword && !exp.title.toLowerCase().includes(searchKeyword.toLowerCase()) && !exp.description.toLowerCase().includes(searchKeyword.toLowerCase())) {
        return false;
      }
      // 2. City
      if (selectedCity && exp.city !== selectedCity) {
        return false;
      }
      // 3. Category
      if (selectedCategory && exp.category !== selectedCategory) {
        return false;
      }
      // 4. Price range limit
      if (exp.price < minPrice || exp.price > maxPrice) {
        return false;
      }
      // 5. Distance boundary
      if (exp.distance > maxDistance) {
        return false;
      }
      // 6. Selectable Date Matches
      if (selectedDate) {
        // Simple comparison: if selectedDate is "2026-05-23" and fits exp.date
        if (exp.date !== selectedDate) {
          return false;
        }
      }
      return true;
    });
  }, [selectedCity, selectedCategory, minPrice, maxPrice, maxDistance, selectedDate, searchKeyword]);

  // Handle paginate "Infinite Scroll" load more triggers
  const handleLoadMore = () => {
    setIsLoadingMore(true);
    setTimeout(() => {
      setVisibleCount(prev => prev + 3);
      setIsLoadingMore(false);
    }, 700);
  };

  const paginatedExperiences = filteredExperiences.slice(0, visibleCount);

  return (
    <div className="min-h-screen flex flex-col pt-4 pb-20">
      
      {/* Dynamic Header Filter bar (Sticky) */}
      <div className="sticky top-20 z-40 bg-stone-50/95 backdrop-blur-sm py-4 border-b border-stone-200/40 -mt-4 mb-6">
        <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8">
          <div className="bg-white border border-stone-200 shadow-sm rounded-2xl p-4 flex flex-col md:flex-row gap-4 items-center justify-between">
            
            {/* Quick Keyword search input */}
            <div className="relative w-full md:w-72">
              <input
                type="text"
                placeholder="Rechercher un cours, un lieu..."
                value={searchKeyword}
                onChange={(e) => setSearchKeyword(e.target.value)}
                className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-stone-200 focus:ring-2 focus:ring-brand-green-med outline-none transition-all placeholder:text-stone-400"
              />
              <LucideIcon name="Search" className="absolute left-3 top-2.5 text-stone-400" size={14} />
              {searchKeyword && (
                <button 
                  onClick={() => setSearchKeyword('')} 
                  className="absolute right-3 top-2.5 text-stone-400 hover:text-stone-600"
                >
                  <LucideIcon name="X" size={12} />
                </button>
              )}
            </div>

            {/* Quick category pills horizontal swipe scroll */}
            <div className="flex gap-2.5 overflow-x-auto w-full md:max-w-xl no-scrollbar py-0.5">
              <button
                onClick={() => setSelectedCategory('')}
                className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-full border shrink-0 transition-all ${
                  selectedCategory === '' 
                    ? 'bg-brand-green-dark text-white border-brand-green-dark shadow-sm' 
                    : 'bg-stone-50 text-stone-600 border-stone-200 hover:bg-stone-100'
                }`}
              >
                Tous
              </button>
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-full border shrink-0 transition-all ${
                    selectedCategory === cat.id 
                      ? 'bg-brand-green-dark text-white border-brand-green-dark shadow-sm' 
                      : 'bg-stone-50 text-stone-600 border-stone-200 hover:bg-stone-100'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>

            {/* Map Layout switcher */}
            <div className="flex gap-1 border border-stone-200 rounded-xl p-0.5 shrink-0 bg-stone-50">
              <button
                onClick={() => setViewMode('list')}
                className={`p-1.5 rounded-lg transition-all ${viewMode === 'list' ? 'bg-white shadow text-brand-green-dark' : 'text-stone-400 hover:text-stone-600'}`}
                title="Affichage Liste"
              >
                <LucideIcon name="List" size={16} />
              </button>
              <button
                onClick={() => setViewMode('both')}
                className={`hidden md:block p-1.5 rounded-lg transition-all ${viewMode === 'both' ? 'bg-white shadow text-brand-green-dark' : 'text-stone-400 hover:text-stone-600'}`}
                title="Double affichage"
              >
                <LucideIcon name="TrendingUp" size={16} />
              </button>
              <button
                onClick={() => setViewMode('map')}
                className={`p-1.5 rounded-lg transition-all ${viewMode === 'map' ? 'bg-white shadow text-brand-green-dark' : 'text-stone-400 hover:text-stone-600'}`}
                title="Cartographie"
              >
                <LucideIcon name="Map" size={16} />
              </button>
            </div>

          </div>
        </div>
      </div>

      {/* Main Split Interface Area */}
      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-6 flex-grow">
        
        {/* LEFT COLUMN: FILTERS (Sticky Panel in Grid) */}
        <div className="lg:col-span-3 space-y-6">
          <div className="bg-white border border-stone-200 rounded-2xl p-5 shadow-sm space-y-6 sticky top-[180px]">
            
            <div className="flex justify-between items-center pb-3 border-b border-stone-100">
              <h3 className="font-serif font-bold text-sm tracking-wider text-stone-800 flex items-center gap-2">
                <LucideIcon name="Filter" size={14} className="text-brand-green-med" />
                FILTRES DE RECHERCHE
              </h3>
              <button 
                onClick={handleResetFilters}
                className="text-[9px] font-bold uppercase tracking-wider text-stone-400 hover:text-brand-green-dark"
              >
                Réinitialiser
              </button>
            </div>

            {/* City */}
            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold uppercase tracking-wider text-stone-400">Ville</label>
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="w-full px-3 py-2 border border-stone-200 outline-none text-xs rounded-lg text-stone-700 bg-white"
              >
                <option value="">Partout en France</option>
                <option value="Paris">Paris (Île-de-France)</option>
                <option value="Lyon">Lyon (Rhône-Alpes)</option>
                <option value="Marseille">Marseille (PACA)</option>
                <option value="Bordeaux">Bordeaux (Aquitaine)</option>
                <option value="Nantes">Nantes (Pays de la Loire)</option>
                <option value="Lille">Lille (Nord)</option>
              </select>
            </div>

            {/* Date Picker filter */}
            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold uppercase tracking-wider text-stone-400">Date précise</label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full px-3 py-2 border border-stone-200 outline-none text-xs rounded-lg text-stone-700 bg-white"
              />
            </div>

            {/* Dynamic Slider Price filter (Range: Min & Max) */}
            <div className="space-y-3 bg-stone-50/50 p-3 rounded-xl border border-stone-200/55">
              <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider text-stone-600">
                <span className="flex items-center gap-1">
                  <LucideIcon name="Coins" size={12} className="text-brand-green-med" />
                  Gamme de Prix
                </span>
                <span className="text-brand-green-dark font-mono font-bold text-xs select-none">
                  {minPrice === 0 ? 'Gratuit' : `${minPrice}€`} - {maxPrice}€
                </span>
              </div>
              
              <div className="space-y-2">
                {/* Min Slider */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[8px] font-medium text-stone-400 uppercase tracking-wider">
                    <span>Prix Min</span>
                    <span>{minPrice} €</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="300"
                    step="5"
                    value={minPrice}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setMinPrice(Math.min(val, maxPrice));
                    }}
                    className="w-full accent-brand-green-dark h-1 bg-stone-200 rounded-lg appearance-none cursor-pointer"
                  />
                </div>

                {/* Max Slider */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[8px] font-medium text-stone-400 uppercase tracking-wider">
                    <span>Prix Max</span>
                    <span>{maxPrice} €</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="300"
                    step="5"
                    value={maxPrice}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setMaxPrice(Math.max(val, minPrice));
                    }}
                    className="w-full accent-brand-green-dark h-1 bg-stone-200 rounded-lg appearance-none cursor-pointer"
                  />
                </div>
              </div>
              
              <div className="flex justify-between text-[9px] text-stone-400 font-mono select-none">
                <span>0 € (Gratuit)</span>
                <span>300 € +</span>
              </div>
            </div>

            {/* Distance Slider filter */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider text-stone-400">
                <span>Distance Max</span>
                <span className="text-brand-green-dark font-mono font-bold text-xs">{maxDistance} km</span>
              </div>
              <input
                type="range"
                min="1"
                max="100"
                step="1"
                value={maxDistance}
                onChange={(e) => setMaxDistance(Number(e.target.value))}
                className="w-full accent-brand-green-dark"
              />
              <div className="flex justify-between text-[9px] text-stone-400 font-mono">
                <span>Moins d'un km</span>
                <span>100 km</span>
              </div>
            </div>

            {/* Badge Info Monétisation */}
            <div className="p-3 bg-amber-50/70 border border-brand-gold/30 rounded-xl space-y-1">
              <span className="text-[8px] font-bold uppercase tracking-wider text-brand-gold-dark block">⚡ OPTION PREMIUM</span>
              <p className="text-[10px] leading-tight text-stone-600">
                Les partenaires abonnés <strong>Osmose PRO / PREMIUM</strong> apparaissent en tête de liste des résultats de recherche.
              </p>
            </div>

          </div>
        </div>

        {/* RIGHT COLUMN: LISTINGS GRID AND INTERACTIVE STICKY MAP DUAL DISPLAY */}
        <div className={`lg:col-span-9 grid grid-cols-1 ${viewMode === 'both' ? 'md:grid-cols-12' : ''} gap-6`}>
          
          {/* Listings side */}
          <div className={`${viewMode === 'both' ? 'md:col-span-7' : viewMode === 'map' ? 'hidden' : 'w-full'} space-y-6`}>
            
            <div className="flex justify-between items-center">
              <div>
                <h2 className="font-serif text-lg font-bold text-stone-900 uppercase tracking-wide">
                  {filteredExperiences.length} {filteredExperiences.length > 1 ? 'EXPÉRIENCES TROUVÉES' : 'EXPÉRIENCE TROUVÉE'}
                </h2>
                <p className="text-[10px] text-stone-400 uppercase tracking-widest mt-0.5">Tri par pertinence sponsorisée</p>
              </div>
            </div>

            {/* No experiences matched query and prompt redirect */}
            {filteredExperiences.length === 0 ? (
              <div className="bg-white border border-stone-200 rounded-2xl p-12 text-center space-y-4">
                <div className="w-16 h-16 bg-stone-50 rounded-full flex items-center justify-center mx-auto text-stone-300">
                  <LucideIcon name="Compass" size={32} />
                </div>
                <div className="max-w-sm mx-auto space-y-1">
                  <h4 className="font-serif font-bold text-sm text-stone-900">Aucune activité trouvée</h4>
                  <p className="text-xs text-stone-500 leading-normal">
                    Nous n'avons pas trouvé de résultats correspondant à vos filtres actuels. Modifiez le budget ou changez de ville.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleResetFilters}
                  className="px-4 py-2 bg-brand-green-dark hover:bg-brand-green-med text-brand-cream font-sans font-bold text-[10px] uppercase tracking-widest rounded-full shadow-sm"
                >
                  Effacer les filtres
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {paginatedExperiences.map((exp) => (
                  <ExperienceCard
                    key={exp.id}
                    experience={exp}
                    isFavorited={favorites.includes(exp.id)}
                    onToggleFavorite={onToggleFavorite}
                    onClick={onSelectExperience}
                  />
                ))}
              </div>
            )}

            {/* PAGINATION / INFINITE SCROLL LOADER MOCK */}
            {filteredExperiences.length > visibleCount && (
              <div className="pt-6 text-center">
                <button
                  onClick={handleLoadMore}
                  disabled={isLoadingMore}
                  className="px-6 py-3 border-2 border-brand-green-dark text-brand-green-dark bg-white hover:bg-brand-green-dark hover:text-white rounded-full font-bold uppercase tracking-widest text-xs transition-all duration-300 flex items-center gap-2 mx-auto disabled:opacity-50"
                >
                  {isLoadingMore ? (
                    <>
                      <div className="w-4 h-4 border-2 border-stone-400 border-t-white rounded-full animate-spin" />
                      <span>Chargement...</span>
                    </>
                  ) : (
                    <span>Afficher plus d'expériences</span>
                  )}
                </button>
              </div>
            )}

          </div>

          {/* Sticky target Map container */}
          <div className={`${viewMode === 'both' ? 'md:col-span-5 relative' : viewMode === 'list' ? 'hidden' : 'w-full'} min-h-[450px]`}>
            <div className="sticky top-[180px]">
              <div className="flex items-center justify-between p-3 bg-brand-green-dark text-white rounded-t-2xl border-t border-brand-gold/20">
                <span className="font-serif font-bold text-xs tracking-wider">APERCU CARTOGRAPHIQUE</span>
                <span className="text-[9px] bg-brand-gold text-brand-green-dark px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">LIVE</span>
              </div>
              <InteractiveMap
                experiences={filteredExperiences}
                selectedExperience={null}
                onSelectExperience={onSelectExperience}
                className="h-[550px] !rounded-t-none"
              />
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
