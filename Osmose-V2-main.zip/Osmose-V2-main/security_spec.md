# Security Specification (TDD SPEC)

## 1. Data Invariants
- **Categories, Partners, Experiences, Articles**: Read-only for public/guests, write-only for authenticated sellers/admins.
- **Bookings & Notifications**: User-specific data. A user can only access (get, list, write) their own bookings and notifications (`userId == request.auth.uid`).

## 2. The "Dirty Dozen" Payloads

1. **Category Spoofing Write**: Non-authenticated or regular user tries to create/delete a category.
   - *Target*: `/categories/cat1`
   - *Payload*: `{ "id": "cat1", "name": "Fake Cat" }`
   - *Outcome*: `PERMISSION_DENIED`
2. **Category Ghost Fields Update**: Normal user tries to add extra fields to category.
   - *Target*: `/categories/cat1`
   - *Payload*: `{ "name": "Name", "malicious_ghost_field": true }`
   - *Outcome*: `PERMISSION_DENIED`
3. **Become Partner Identity Spoofing**: Signed-in user tries to register a partner page with another user's ownerId / email.
   - *Target*: `/partners/partner1`
   - *Payload*: `{ "id": "partner1", "name": "Malicious Partner", "email": "admin@google.com", "userId": "attacker_uid" }` (pretending to be someone else)
   - *Outcome*: `PERMISSION_DENIED`
4. **Partner Privilege Escalation**: User tries to update partner premium flag or rating.
   - *Target*: `/partners/p1`
   - *Payload*: `{ "premium": true, "rating": 5.0 }`
   - *Outcome*: `PERMISSION_DENIED`
5. **Unauthorized Experience Creation**: Creating an experience with a partnerId not owned by the user.
   - *Target*: `/experiences/exp1`
   - *Payload*: `{ "id": "exp1", "title": "Fake", "partnerId": "p1" }`
   - *Outcome*: `PERMISSION_DENIED`
6. **Experience Value Poisoning**: Updating an experience's price to an unreasonable payload (like a negative or 1MB string).
   - *Target*: `/experiences/e1`
   - *Payload*: `{ "price": -500 }` or `{ "price": "1MB_string" }`
   - *Outcome*: `PERMISSION_DENIED`
7. **Article Modification**: Regular user tries to publish/modify articles.
   - *Target*: `/articles/a1`
   - *Payload*: `{ "title": "Hacked blog" }`
   - *Outcome*: `PERMISSION_DENIED`
8. **Booking Hijack**: User retrieves bookings belonging to another user.
   - *Target*: `/bookings/b-001` (owned by `anotherUserSub`)
   - *Outcome*: `PERMISSION_DENIED`
9. **Booking Spoofing (Create)**: Creating a booking with `userId` representing another user's UID to charge or spam them.
   - *Target*: `/bookings/new-booking`
   - *Payload*: `{ "userId": "victim_uid", "experienceId": "e1" }`
   - *Outcome*: `PERMISSION_DENIED`
10. **Booking Status Shortcut**: Normal user bypasses checkout or cancels booking arbitrarily without proper verification, or sets status directly to 'completed' without payment.
    - *Target*: `/bookings/b-001`
    - *Payload*: `{ "status": "completed" }`
    - *Outcome*: `PERMISSION_DENIED`
11. **Notification Blanket Read**: User listing all notifications of all users in the system.
    - *Target*: `/notifications` (without user filter)
    - *Outcome*: `PERMISSION_DENIED`
12. **Notification Poisoning**: User creating a fake read notification to standard users.
    - *Target*: `/notifications/notif1`
    - *Payload*: `{ "userId": "victim_uid", "title": "Hacked", "read": false }`
    - *Outcome*: `PERMISSION_DENIED`
